Antara North Star agent
=======================
What it does: looks on this computer for AI agents, AI apps people use (ChatGPT, Copilot, Claude, Cursor and similar), coding assistants, command line AI tools, local models, keys left in files and similar risks, once a day. It lists names only. It never reads what anyone typed into an AI tool.
What it sends to your portal: findings (what, how serious, why, what to do) and the list of AI agents found.
What it never sends: the files themselves, the keys themselves, or anything you type.
Reads only. It changes nothing on this computer.

Install:
  Windows (admin PowerShell, or Intune script):  powershell -ExecutionPolicy Bypass -File install.ps1 -Token <token>
  Mac or Linux:                                 sudo ./install.sh <token>
Get a token from the portal: Add computers.
Remove:  node agent.js uninstall   (then ask your administrator to revoke the computer in the portal)
Logs:    agent.log in the settings folder shown by "node agent.js status".
