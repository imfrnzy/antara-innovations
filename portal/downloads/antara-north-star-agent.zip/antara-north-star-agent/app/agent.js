'use strict';
/* Antara North Star endpoint agent.
   Runs on a laptop or server. Reads only. Raw evidence stays in memory on this machine and is never written to disk or sent.
   Only findings (what, how serious, why, fix) and the list of AI agents found go to the portal.

   node agent.js enrol <token> [--api URL]   register this computer with the organisation
   node agent.js run                         scan now and send findings
   node agent.js install                     enrol must be done first; schedules a daily scan
   node agent.js uninstall                   removes the schedule and the saved credentials
   node agent.js status                      shows what this agent is set up to do
*/
const fs = require('fs'), path = require('path'), os = require('os'), https = require('https'), http = require('http'), tls = require('tls'), cp = require('child_process'), crypto = require('crypto');
const AF = require('./engine.js'), C = require('./collector.js');
const VERSION = '0.3.0';
const DEFAULT_API = 'https://oxmoenclvifxhgwsxfop.supabase.co/functions/v1/ns-agent';
const argv = process.argv.slice(2), cmd = argv[0] || 'status';
const flag = n => { const i = argv.indexOf('--' + n); return i >= 0 ? argv[i + 1] : null; };
const sha = s => crypto.createHash('sha256').update(s).digest('hex');

/* ---------- where things live ---------- */
const isSystem = (() => {
  try {
    if (process.platform === 'win32') return /\$$/.test(process.env.USERNAME || '') || argv.includes('--system');
    return (process.getuid && process.getuid() === 0) || argv.includes('--system');
  } catch (e) { return false; }
})();
function cfgDir() {
  if (process.env.NS_CONFIG_DIR) return process.env.NS_CONFIG_DIR;
  if (process.platform === 'win32') return path.join(isSystem ? (process.env.ProgramData || 'C:\\ProgramData') : (process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local')), 'AntaraNorthStar');
  if (process.platform === 'darwin') return isSystem ? '/Library/Application Support/AntaraNorthStar' : path.join(os.homedir(), 'Library', 'Application Support', 'AntaraNorthStar');
  return isSystem ? '/var/lib/antara-north-star' : path.join(os.homedir(), '.config', 'antara-north-star');
}
const CFG = () => path.join(cfgDir(), 'agent.json'), LOG = () => path.join(cfgDir(), 'agent.log');
function log(m) { const line = new Date().toISOString() + '  ' + m; console.log(line); try { fs.mkdirSync(cfgDir(), { recursive: true }); fs.appendFileSync(LOG(), line + '\n'); const st = fs.statSync(LOG()); if (st.size > 1048576) fs.writeFileSync(LOG(), fs.readFileSync(LOG(), 'utf8').slice(-300000)); } catch (e) { } }
function loadCfg() { try { return JSON.parse(fs.readFileSync(CFG(), 'utf8')); } catch (e) { return null; } }
function saveCfg(c) { fs.mkdirSync(cfgDir(), { recursive: true }); fs.writeFileSync(CFG(), JSON.stringify(c, null, 1), { mode: 0o600 }); try { fs.chmodSync(CFG(), 0o600); } catch (e) { } }

/* ---------- talking to the portal (with company proxy support) ---------- */
function post(api, body, proxy) {
  return new Promise((resolve, reject) => {
    const u = new URL(api), data = Buffer.from(JSON.stringify(body));
    const px = proxy || process.env.HTTPS_PROXY || process.env.https_proxy || '';
    const go = agent => {
      const rq = https.request({ host: u.hostname, port: u.port || 443, path: u.pathname + u.search, method: 'POST', agent, headers: { 'content-type': 'application/json', 'content-length': data.length, 'user-agent': 'antara-north-star-agent/' + VERSION }, timeout: 120000 }, rs => {
        const ch = []; rs.on('data', d => ch.push(d)); rs.on('end', () => { let j = null; try { j = JSON.parse(Buffer.concat(ch).toString('utf8')); } catch (e) { } resolve({ status: rs.statusCode, body: j }); });
      });
      rq.on('error', reject); rq.on('timeout', () => { rq.destroy(new Error('timed out')); }); rq.end(data);
    };
    if (!px) return go(undefined);
    const p = new URL(px), hdr = { host: u.hostname + ':443' };
    if (p.username) hdr['proxy-authorization'] = 'Basic ' + Buffer.from(decodeURIComponent(p.username) + ':' + decodeURIComponent(p.password)).toString('base64');
    const cr = http.request({ host: p.hostname, port: p.port || 80, method: 'CONNECT', path: u.hostname + ':443', headers: hdr, timeout: 30000 });
    cr.on('connect', (res, sock) => {
      if (res.statusCode !== 200) return reject(new Error('proxy refused the connection (' + res.statusCode + ')'));
      const agent = new https.Agent({ keepAlive: false }); agent.createConnection = () => tls.connect({ socket: sock, servername: u.hostname });
      go(agent);
    });
    cr.on('error', reject); cr.on('timeout', () => cr.destroy(new Error('proxy timed out'))); cr.end();
  });
}

/* ---------- what to look at ---------- */
function homes() {
  const out = [];
  if (!isSystem) return [os.homedir()];
  const base = process.platform === 'win32' ? 'C:\\Users' : process.platform === 'darwin' ? '/Users' : '/home';
  try { for (const n of fs.readdirSync(base)) { if (/^(public|default|default user|all users|shared|guest)$/i.test(n)) continue; const p = path.join(base, n); try { if (fs.statSync(p).isDirectory()) out.push(p); } catch (e) { } } } catch (e) { }
  return out;
}
function scopeRoots() {
  const names = ['Desktop', 'Documents', 'Downloads', 'Projects', 'projects', 'repos', 'source', 'src', 'code', 'dev', 'work', 'Work', 'GitHub', 'github', 'OneDrive'];
  const roots = [];
  for (const h of homes()) for (const n of names) { const p = path.join(h, n); try { if (fs.statSync(p).isDirectory()) roots.push(p); } catch (e) { } }
  return roots;
}

/* ---------- scan: runs the collector in memory, then the checks ---------- */
async function scan(cfg) {
  const t0 = Date.now(), files = [], agents = [];
  const roots = (cfg.roots && cfg.roots.length) ? cfg.roots : scopeRoots();
  for (const m of C.MODULES.filter(m => ['files', 'localhost'].includes(m.id))) {
    const ctx = {
      scope: { roots, includeHidden: false, maxFileMB: 50 }, secrets: {}, log: x => log(String(x)), stopped: () => false, progress: () => { },
      addEvidence: (name, text) => { files.push({ name, text }); },
      addAgents: a => { for (const x of a) agents.push(x); }
    };
    try { await m.fn(ctx); } catch (e) { log(m.id + ' failed: ' + e.message); }
  }
  if (agents.length) files.push({ name: 'collected-estate-agent.json', text: JSON.stringify({ agents }) });
  const r = AF.run({ files, overrides: { org: { name: cfg.org || 'organisation' } }, workers: {}, sample: false, said: null, params: {} });
  const total = Object.values(r.results).reduce((n, m) => n + Object.keys(m.workers).length, 0);
  const ran = Object.values(r.results).reduce((n, m) => n + Object.values(m.workers).filter(w => w.status === 'ran' || w.status === 'ok' || w.status === 'done' || w.findings).length, 0);
  const seenKeys = new Set();
  const A = new Map((r.ledger.agents || []).map(a => [a.id, a]));
  const cases = r.ledger.cases || [];
  const cur = String((r.ledger.prices && r.ledger.prices.currency) || '').slice(0, 3).toUpperCase();
  const days = Math.max(1, (r.ledger.window && r.ledger.window.days) || 30);
  const costBy = {}; (r.ledger.runs || []).forEach(u => { if (u.cost != null && u.agent) costBy[u.agent] = (costBy[u.agent] || 0) + u.cost; });
  const CAT = { attack_paths: 'security', injection_paths: 'security', access_keys: 'security', blast_radius: 'security',
    human_gate: 'compliance', model_register: 'compliance', sector_rules: 'compliance', policy_drift: 'compliance', trace_integrity: 'compliance', link_rules: 'compliance',
    ai_inventory: 'governance', owner_chain: 'governance', pyramid_review: 'governance', model_finder: 'governance',
    spend_usage: 'commercial', cost_per_run: 'commercial', token_waste: 'commercial', model_fit: 'commercial', outcome_cost: 'commercial', overlap_finder: 'commercial', case_vs_actual: 'commercial' };
  const r2 = x => (x == null || isNaN(x)) ? null : Math.round(x * 100) / 100;
  const waste = f => { const m = f.measure || {}; switch (f.worker) {
    case 'token_waste': return [r2(m.cost), 'Paid to answer the same input ' + m.repeats + ' times'];
    case 'model_fit': return [r2(m.now - m.alt), 'Could run on a cheaper model for about ' + r2(m.alt) + ' instead of ' + r2(m.now)];
    case 'spend_usage': return [r2(m.spend), 'Paying for overlapping tools'];
    case 'outcome_cost': return [null, 'Paying people to review costs ' + r2(m.review) + ' against ' + r2(m.model) + ' for the model'];
    case 'cost_per_run': return [null, 'Cost per run is now ' + (m.late && m.early ? r2(m.late / m.early) : '?') + ' times what it was'];
    default: return [null, '']; } };
  const findings = r.findings.filter(f => f.severity !== 'rejected').map(f => {
    const ev = (f.evidence || []).map(e => (e.t || '') + ':' + (e.id || '')).sort().join(',');
    let key = (f.worker || 'check') + '|' + sha(ev + '|' + (f.worker || '')).slice(0, 12), n = 1; while (seenKeys.has(key)) key = (f.worker || 'check') + '|' + sha(ev + '|' + (n++)).slice(0, 12); seenKeys.add(key);
    const ids = []; (f.evidence || []).forEach(e => { if (e.t === 'agent') ids.push(e.id); else if (e.t === 'link') String(e.id).split('>').forEach(x => ids.push(x)); });
    const refs = Array.from(new Set(ids)).filter(id => A.has(id));
    const w = waste(f);
    return { key, module: f.module, check_id: f.worker, category: CAT[f.worker] || 'governance', severity: /is known for only/.test(f.title) ? 'info' : f.severity, title: f.title,
      detail: [f.claim, f.why ? 'Why it matters: ' + f.why : '', f.fix ? 'What to do: ' + f.fix : ''].filter(Boolean).join(' '),
      subject: (f.evidence && f.evidence[0] && f.evidence[0].id) || '', agent_refs: refs, waste: w[0], waste_note: w[1], currency: cur };
  });
  const outAgents = (r.ledger.agents || []).map(a => {
    const cs = cases.filter(c => (c.agent_ids || []).includes(a.id)), c0 = cs[0];
    return { name: a.name || a.id, agent_ref: a.id, platform: a.platform || a.dept || '', model: a.model || '', tool_count: (a.tools || []).length, credential_count: (a.credentials || []).length, source: (a.sources && a.sources[0]) || 'files',
      dept: a.dept || '', owner: a.owner || '', tier: a.tier || '', benefit_pm: cs.length ? cs.reduce((n, c) => n + (c.benefit_pm || 0), 0) : null, run_cost_pm: costBy[a.id] != null ? r2(costBy[a.id] / days * 30) : null,
      case_name: c0 ? c0.name : '', payback_months: c0 ? c0.payback_months : null, build_cost: cs.length ? cs.reduce((n, c) => n + (c.build_cost || 0), 0) : null, run_count: a.run_count || 0, currency: cur };
  });
  return { findings, agents: outAgents, scan: { duration_ms: Date.now() - t0, checks_run: ran || total, checks_total: total }, filesSeen: files.length };
}

/* ---------- commands ---------- */
async function enrol() {
  const token = argv[1]; if (!token || token.startsWith('--')) { console.error('Usage: agent.js enrol <token>'); process.exit(2); }
  const api = flag('api') || DEFAULT_API;
  const r = await post(api, { action: 'enrol', token, hostname: os.hostname(), os: os.platform() + ' ' + os.release(), agent_version: VERSION }, flag('proxy'));
  if (!r.body || !r.body.ok) { console.error('Enrolment failed: ' + ((r.body && r.body.error) || ('HTTP ' + r.status))); process.exit(1); }
  saveCfg({ api, device_id: r.body.device_id, secret: r.body.secret, org: r.body.org, proxy: flag('proxy') || '', roots: [], enrolled: new Date().toISOString() });
  log('Enrolled with ' + r.body.org + '. This computer is now known to the portal.');
}
async function run() {
  const cfg = loadCfg(); if (!cfg) { console.error('Not enrolled yet. Run: agent.js enrol <token>'); process.exit(2); }
  log('Scan started (' + (isSystem ? 'whole computer' : 'this user') + ').');
  const s = await scan(cfg);
  log('Scan finished: ' + s.findings.length + ' findings, ' + s.agents.length + ' agents, ' + Math.round(s.scan.duration_ms / 1000) + ' s. Sending findings only.');
  if (process.env.NS_DRYRUN_OUT) { fs.writeFileSync(process.env.NS_DRYRUN_OUT, JSON.stringify({ hostname: os.hostname(), scan: s.scan, findings: s.findings, agents: s.agents }, null, 1)); log('Dry run: wrote the report to a file, sent nothing.'); return; }
  const r = await post(cfg.api, { action: 'report', device_id: cfg.device_id, secret: cfg.secret, hostname: os.hostname(), os: os.platform() + ' ' + os.release(), agent_version: VERSION, scan: s.scan, findings: s.findings, agents: s.agents }, cfg.proxy);
  if (!r.body || !r.body.ok) { log('Send failed: ' + ((r.body && r.body.error) || ('HTTP ' + r.status))); process.exit(1); }
  log('Portal accepted the report. ' + r.body.findings + ' findings, ' + r.body.agents + ' agents, ' + r.body.resolved + ' marked fixed.');
}
function install() {
  const cfg = loadCfg(); if (!cfg) { console.error('Enrol first.'); process.exit(2); }
  const node = process.execPath, me = path.resolve(__filename), hh = 9 + Math.floor(Math.random() * 8), mm = Math.floor(Math.random() * 60);
  const t = String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0');
  if (process.platform === 'win32') {
    const args = ['/Create', '/TN', 'AntaraNorthStar', '/TR', '"' + node + '" "' + me + '" run', '/SC', 'DAILY', '/ST', t, '/F'].concat(isSystem ? ['/RU', 'SYSTEM', '/RL', 'HIGHEST'] : []);
    const r = cp.spawnSync('schtasks', args, { encoding: 'utf8' }); if (r.status !== 0) { console.error(r.stdout + r.stderr); process.exit(1); }
  } else if (process.platform === 'darwin') {
    const label = 'com.antara.northstar', plist = (isSystem ? '/Library/LaunchDaemons/' : path.join(os.homedir(), 'Library/LaunchAgents/')) + label + '.plist';
    fs.mkdirSync(path.dirname(plist), { recursive: true });
    fs.writeFileSync(plist, `<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>Label</key><string>${label}</string><key>ProgramArguments</key><array><string>${node}</string><string>${me}</string><string>run</string></array><key>StartCalendarInterval</key><dict><key>Hour</key><integer>${hh}</integer><key>Minute</key><integer>${mm}</integer></dict><key>StandardOutPath</key><string>${path.join(cfgDir(), 'launchd.log')}</string><key>StandardErrorPath</key><string>${path.join(cfgDir(), 'launchd.log')}</string></dict></plist>`);
    cp.spawnSync('launchctl', ['unload', plist]); const r = cp.spawnSync('launchctl', ['load', plist], { encoding: 'utf8' }); if (r.status !== 0) { console.error(r.stderr); process.exit(1); }
  } else {
    const line = `${mm} ${hh} * * * ${isSystem ? 'root ' : ''}"${node}" "${me}" run >> "${path.join(cfgDir(), 'cron.log')}" 2>&1`;
    if (isSystem && fs.existsSync('/etc/cron.d')) fs.writeFileSync('/etc/cron.d/antara-north-star', line + '\n');
    else { const cur = (cp.spawnSync('crontab', ['-l'], { encoding: 'utf8' }).stdout || '').split('\n').filter(l => l && !l.includes('antara') && !l.includes(me)); cur.push(line); const r = cp.spawnSync('crontab', ['-'], { input: cur.join('\n') + '\n', encoding: 'utf8' }); if (r.status !== 0) { console.error('Could not set a schedule: ' + r.stderr); process.exit(1); } }
  }
  log('Daily scan scheduled for about ' + t + ' local time.');
}
function uninstall() {
  if (process.platform === 'win32') cp.spawnSync('schtasks', ['/Delete', '/TN', 'AntaraNorthStar', '/F']);
  else if (process.platform === 'darwin') { const plist = (isSystem ? '/Library/LaunchDaemons/' : path.join(os.homedir(), 'Library/LaunchAgents/')) + 'com.antara.northstar.plist'; cp.spawnSync('launchctl', ['unload', plist]); try { fs.unlinkSync(plist); } catch (e) { } }
  else { try { fs.unlinkSync('/etc/cron.d/antara-north-star'); } catch (e) { } const cur = (cp.spawnSync('crontab', ['-l'], { encoding: 'utf8' }).stdout || '').split('\n').filter(l => l && !l.includes('antara')); cp.spawnSync('crontab', ['-'], { input: cur.join('\n') + (cur.length ? '\n' : ''), encoding: 'utf8' }); }
  try { fs.unlinkSync(CFG()); } catch (e) { }
  console.log('Schedule and saved credentials removed. Ask the portal administrator to revoke this computer there as well.');
}
function status() {
  const c = loadCfg(); console.log('Antara North Star agent ' + VERSION); console.log('Settings folder: ' + cfgDir());
  if (!c) return console.log('Not enrolled.');
  console.log('Enrolled with: ' + c.org + '\nComputer id: ' + c.device_id + '\nFolders scanned: ' + (scopeRoots().join(', ') || '(none found)') + '\nWhat is sent: findings and the list of AI agents found. Never the files themselves.');
}

(async () => {
  try { await ({ enrol, run, install, uninstall, status }[cmd] || status)(); }
  catch (e) { console.error('Failed: ' + e.message); process.exit(1); }
})();
