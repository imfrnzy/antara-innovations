'use strict';
/* Antara North Star collector. Read-only: lists, reads and probes. Writes only into its own evidence folder.
   Every module is async, gets a ctx, and reports what it did through ctx.log / ctx.progress. */
const fs = require('fs'), path = require('path'), os = require('os'), net = require('net'), http = require('http'), https = require('https'), cp = require('child_process'), crypto = require('crypto');
const AF = require('./engine.js');

const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const slug = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const KEEP_KINDS = new Set(['estate', 'inventory', 'runs', 'otel', 'trace_jsonl', 'n8n', 'mcp', 'prices', 'policy', 'cases', 'outcomes', 'expenses', 'extensions', 'people']);
exports.KEEP_KINDS = KEEP_KINDS;

/* ---------- known things ---------- */
const FRAMEWORKS = [
  ['langgraph', /\blanggraph\b/i], ['langchain', /\blangchain\b|@langchain\//i], ['crewai', /\bcrewai\b/i], ['autogen', /\bautogen\b|\bag2\b/i],
  ['semantic-kernel', /semantic[_-]kernel/i], ['llamaindex', /llama[_-]index/i], ['haystack', /\bhaystack\b/i], ['openai-agents', /openai[_-]agents|from agents import/i],
  ['pydantic-ai', /pydantic[_-]ai/i], ['smolagents', /smolagents/i], ['mastra', /@mastra\//i], ['litellm', /\blitellm\b/i],
  ['openai-sdk', /\bimport openai\b|from openai import|require\(['"]openai['"]\)|from ['"]openai['"]|"openai"\s*:/i],
  ['anthropic-sdk', /\bimport anthropic\b|from anthropic import|@anthropic-ai\/sdk|"anthropic"\s*:/i],
  ['google-genai', /google\.generativeai|google-genai|vertexai|@google\/generative-ai|@google\/genai/i],
  ['bedrock', /bedrock-runtime|bedrock_runtime|@aws-sdk\/client-bedrock/i], ['ollama', /\bollama\b/i], ['vllm', /\bvllm\b/i],
  ['transformers', /from transformers import|"@huggingface\/transformers"|"@xenova\/transformers"/i], ['mcp', /modelcontextprotocol|from mcp import|fastmcp/i]
];
const MODEL_RE = /\b(gpt-[0-9][a-z0-9.\-]*|o[134](?:-mini|-pro)?|claude-[a-z0-9.\-]+|gemini-[a-z0-9.\-]+|llama-?[0-9][a-z0-9.:\-]*|mistral-[a-z0-9.\-]+|mixtral-[a-z0-9.\-]+|qwen[0-9a-z.:\-]*|deepseek-[a-z0-9.\-]+|command-r[a-z0-9\-+]*|gemma[0-9a-z.:\-]*|phi-?[0-9][a-z0-9.\-]*)\b/gi;
const SECRET_RES = [
  ['openai-key', /\bsk-(?:proj-)?[A-Za-z0-9_\-]{32,}\b/g], ['anthropic-key', /\bsk-ant-[A-Za-z0-9_\-]{20,}\b/g], ['aws-key', /\bAKIA[0-9A-Z]{16}\b/g],
  ['google-key', /\bAIza[0-9A-Za-z_\-]{35}\b/g], ['slack-token', /\bxox[baprs]-[A-Za-z0-9\-]{10,}\b/g], ['github-token', /\bghp_[A-Za-z0-9]{30,}\b/g], ['huggingface-token', /\bhf_[A-Za-z0-9]{30,}\b/g]
];
const TOOL_FN_RE = /(?:@tool[^\n]*\n\s*(?:async\s+)?def\s+(\w+))|(?:def\s+((?:send|delete|remove|pay|transfer|refund|approve|execute|run|write|post|create|update|drop|deploy|email|sms|charge|book|cancel)_\w+))|(?:function\s+((?:send|delete|remove|pay|transfer|refund|approve|execute|run|write|post|create|update|deploy|email|charge|cancel)[A-Z_]\w*))/g;
const CODE_EXT = new Set(['.py', '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.ipynb', '.yml', '.yaml', '.toml', '.txt', '.cfg', '.ini', '.env', '.sh', '.ps1', '.go', '.java', '.cs', '.rb', '.php', '.md']);
const MARKERS = new Set(['requirements.txt', 'package.json', 'pyproject.toml', 'pipfile', 'dockerfile', 'docker-compose.yml', 'docker-compose.yaml', 'compose.yml', 'compose.yaml', 'go.mod', 'pom.xml', 'build.gradle']);
const SKIP_DIRS = new Set(['node_modules', '.git', '__pycache__', '.venv', 'venv', 'site-packages', '$recycle.bin', 'system volume information', 'windows', 'program files', 'program files (x86)', 'programdata', 'proc', 'sys', 'dev', 'snap', 'library', '.cache', '.npm', 'dist-packages']);
const IMAGES = [['ollama', /ollama/i, 'Ollama'], ['n8n', /n8nio|n8n/i, 'n8n'], ['flowise', /flowise/i, 'Flowise'], ['langflow', /langflow/i, 'Langflow'], ['dify', /langgenius|dify/i, 'Dify'], ['open-webui', /open-webui/i, 'Open WebUI'], ['litellm', /litellm/i, 'LiteLLM'], ['vllm', /vllm/i, 'vLLM'], ['langfuse', /langfuse/i, 'Langfuse'], ['qdrant', /qdrant/i, 'Qdrant'], ['chroma', /chroma/i, 'Chroma'], ['weaviate', /weaviate/i, 'Weaviate'], ['tgi', /text-generation-inference/i, 'Text Generation Inference'], ['localai', /localai/i, 'LocalAI']];

/* ---------- ports and fingerprints ---------- */
const LIVE_PORTS = [22, 80, 135, 443, 445, 3389, 8080];
const AGENT_PORTS = [80, 443, 1234, 3000, 3001, 4000, 4200, 5000, 5001, 5678, 6333, 6334, 7860, 8000, 8001, 8008, 8080, 8081, 8088, 8188, 8501, 8888, 9091, 9200, 11434, 18789];
const SIGS = [
  { id: 'ollama', label: 'Ollama', path: '/api/tags', test: (b, h) => { const j = jparse(b); return j && Array.isArray(j.models) ? { models: j.models.map(m => m.name || m.model) } : null; } },
  { id: 'openai-compatible', label: 'OpenAI-compatible model server (vLLM, LiteLLM, LM Studio, LocalAI or similar)', path: '/v1/models', test: b => { const j = jparse(b); return j && Array.isArray(j.data) && j.data.length && j.data[0].id ? { models: j.data.map(m => m.id) } : null; } },
  { id: 'n8n', label: 'n8n workflow server', path: '/healthz', test: b => (jparse(b) || {}).status === 'ok' ? {} : null, ports: [5678, 80, 443] },
  { id: 'flowise', label: 'Flowise', path: '/api/v1/ping', test: b => /pong/i.test(b) ? {} : null },
  { id: 'open-webui', label: 'Open WebUI', path: '/api/config', test: b => /open webui/i.test(b) ? {} : null },
  { id: 'langflow', label: 'Langflow', path: '/health', test: b => /"status"\s*:\s*"ok"/.test(b) ? {} : null, ports: [7860] },
  { id: 'langfuse', label: 'Langfuse', path: '/api/public/health', test: b => /OK/.test(b) && /status/i.test(b) ? {} : null, ports: [3000] },
  { id: 'jupyter', label: 'Jupyter server', path: '/api', test: b => { const j = jparse(b); return j && j.version ? {} : null; }, ports: [8888] },
  { id: 'qdrant', label: 'Qdrant vector database', path: '/', test: b => /qdrant/i.test(b) ? {} : null, ports: [6333] },
  { id: 'chroma', label: 'Chroma vector database', path: '/api/v1/heartbeat', test: b => /heartbeat/i.test(b) ? {} : null, ports: [8000] },
  { id: 'weaviate', label: 'Weaviate vector database', path: '/v1/meta', test: b => { const j = jparse(b); return j && j.version && j.hostname ? {} : null; }, ports: [8080] },
  { id: 'comfyui', label: 'ComfyUI', path: '/system_stats', test: b => /comfyui|devices/i.test(b) ? {} : null, ports: [8188] },
  { id: 'streamlit', label: 'Streamlit app', path: '/_stcore/health', test: b => /^ok$/i.test(b.trim()) ? {} : null, ports: [8501] },
  { id: 'gradio', label: 'Gradio app', path: '/config', test: b => { const j = jparse(b); return j && j.components ? {} : null; }, ports: [7860] }
];
function jparse(s) { try { return JSON.parse(s); } catch (e) { return null; } }

/* ---------- helpers ---------- */
function cidr(spec, maxHosts) {
  spec = String(spec).trim(); if (!spec) return [];
  const m = spec.match(/^(\d+\.\d+\.\d+\.\d+)(?:\/(\d+))?$/);
  if (!m) return [spec]; // hostname
  const parts = m[1].split('.').map(Number); if (parts.some(p => p > 255)) return [];
  const bits = m[2] == null ? 32 : Number(m[2]); if (bits < 8 || bits > 32) return [];
  const ip = ((parts[0] << 24) >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3];
  const size = Math.pow(2, 32 - bits), base = Math.floor(ip / size) * size, out = [];
  const lo = bits >= 31 ? 0 : 1, hi = bits >= 31 ? size : size - 1;
  for (let i = lo; i < hi && out.length < (maxHosts || 70000); i++) { const v = base + i; out.push([(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255].join('.')); }
  return out;
}
exports.cidr = cidr;
function localSubnets() {
  const out = []; const ifs = os.networkInterfaces();
  for (const k of Object.keys(ifs)) for (const a of ifs[k] || []) if (a.family === 'IPv4' && !a.internal && a.cidr) { const p = a.cidr.split('/'); const b = Math.max(16, Number(p[1])); const ip = p[0].split('.').map(Number); const n = Math.pow(2, 32 - b); const v = ((ip[0] << 24) >>> 0) + (ip[1] << 16) + (ip[2] << 8) + ip[3]; const base = Math.floor(v / n) * n; out.push([(base >>> 24) & 255, (base >>> 16) & 255, (base >>> 8) & 255, base & 255].join('.') + '/' + b); }
  return Array.from(new Set(out));
}
exports.localSubnets = localSubnets;
function tcp(host, port, ms) {
  return new Promise(res => { const s = new net.Socket(); let done = false; const end = r => { if (!done) { done = true; s.destroy(); res(r); } }; s.setTimeout(ms); s.once('connect', () => end(true)); s.once('timeout', () => end(false)); s.once('error', () => end(false)); try { s.connect(port, host); } catch (e) { end(false); } });
}
function get(host, port, p, ms, headers) {
  return new Promise(res => {
    const mod = (port === 443 || port === 8443) ? https : http;
    const rq = mod.request({ host, port, path: p, method: 'GET', timeout: ms, rejectUnauthorized: false, headers: Object.assign({ 'user-agent': 'antara-north-star-collector/0.2', accept: '*/*' }, headers || {}) }, r => {
      let b = ''; r.setEncoding('utf8'); r.on('data', d => { if (b.length < 65536) b += d; }); r.on('end', () => res({ status: r.statusCode, body: b, headers: r.headers })); r.on('error', () => res(null));
    });
    rq.on('timeout', () => { rq.destroy(); res(null); }); rq.on('error', () => res(null)); rq.end();
  });
}
async function pool(items, n, fn, stop) {
  let i = 0; const run = async () => { while (i < items.length && !stop()) { const k = i++; await fn(items[k], k); } };
  await Promise.all(Array.from({ length: Math.max(1, n) }, run));
}
const rel = (root, f) => path.relative(root, f).split(path.sep).join('/');
const projName = d => { const b = path.basename(d); return b && b !== '.' ? b : path.basename(path.dirname(d)) || 'project'; };

/* ---------- module: files (code, configs, logs, exports) ---------- */
exports.files = async function (ctx) {
  const roots = (ctx.scope.roots || []).map(r => String(r).trim()).filter(Boolean);
  if (!roots.length) { ctx.log('files: no folders given, skipped'); return { skipped: true }; }
  const maxFiles = ctx.scope.maxFiles || 3000000, maxBytes = (ctx.scope.maxFileMB || 400) * 1048576;
  const stat = { dirs: 0, files: 0, read: 0, evidence: 0, projects: 0, secrets: 0 };
  const projects = new Map(); const seenHash = new Set();
  const projOf = (dir, root) => { let d = dir; while (d.length >= root.length) { if (projects.has(d) && projects.get(d).marker) return d; if (d === root) break; const up = path.dirname(d); if (up === d) break; d = up; } return dir; };
  const markerDirs = new Map();
  const t0 = Date.now(); let lastTick = 0;
  const tick = () => { const now = Date.now(); if (now - lastTick > 700) { lastTick = now; ctx.progress({ pct: null, note: stat.files + ' files seen, ' + stat.evidence + ' evidence files kept, ' + stat.projects + ' agent projects', rate: Math.round(stat.files / ((now - t0) / 1000 || 1)) }); } };
  async function walk(dir, root, depth) {
    if (ctx.stopped() || depth > 14 || stat.files > maxFiles) return;
    let ents; try { ents = await fs.promises.readdir(dir, { withFileTypes: true }); } catch (e) { return; }
    stat.dirs++;
    // markers first so project dirs are known before their files
    for (const e of ents) if (e.isFile() && MARKERS.has(e.name.toLowerCase())) markerDirs.set(dir, true);
    for (const e of ents) {
      if (ctx.stopped()) return;
      const full = path.join(dir, e.name);
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) { if (SKIP_DIRS.has(e.name.toLowerCase()) && !(ctx.scope.includeHidden)) continue; await walk(full, root, depth + 1); continue; }
      if (!e.isFile()) continue;
      stat.files++; tick();
      const ext = path.extname(e.name).toLowerCase(), lname = e.name.toLowerCase();
      const isEnv = lname === '.env' || lname.startsWith('.env.') || lname.endsWith('.env');
      const isStruct = ext === '.json' || ext === '.jsonl' || ext === '.ndjson' || ext === '.csv';
      const isCode = CODE_EXT.has(ext) || isEnv || MARKERS.has(lname);
      if (!isStruct && !isCode) continue;
      let st; try { st = await fs.promises.stat(full); } catch (e2) { continue; }
      if (st.size > maxBytes || st.size === 0) continue;
      if (isStruct) {
        if (st.size > 200 * 1048576) { ctx.log('files: skipped very large data file ' + full + ' (' + Math.round(st.size / 1048576) + ' MB), give it through the drop folder if it matters'); continue; }
        let text; try { text = await fs.promises.readFile(full, 'utf8'); } catch (e3) { continue; }
        stat.read++;
        const r = AF.REG.reader.fn({ name: e.name, text });
        if (KEEP_KINDS.has(r.kind) && r.records !== 0) {
          const h = sha(text); if (seenHash.has(h)) continue; seenHash.add(h);
          let nm = e.name; if (r.kind === 'mcp') nm = slug(projName(dir)) + '.mcp.json'; else if (r.kind === 'n8n' || r.kind === 'trace_jsonl') nm = slug(projName(dir)) + '.' + e.name;
          ctx.addEvidence('found-' + h.slice(0, 6) + '-' + nm, text, { from: full, kind: r.kind, records: r.records }); stat.evidence++;
        }
        if (r.kind === 'doc' || r.kind === 'n8n' || r.kind === 'mcp' || r.kind === 'estate') scanText(text, full, dir, root, true);
        continue;
      }
      if (st.size > 2 * 1048576) continue;
      let text; try { text = await fs.promises.readFile(full, 'utf8'); } catch (e4) { continue; }
      stat.read++; scanText(text, full, dir, root, false);
    }
  }
  function scanText(text, full, dir, root, structured) {
    const pd = markerDirs.has(dir) ? dir : projOf(dir, root);
    let p = projects.get(pd); if (!p) { p = { dir: pd, frameworks: new Set(), models: new Set(), tools: new Set(), creds: new Set(), envNames: new Set(), files: 0, images: new Set(), exposedHint: false }; projects.set(pd, p); }
    p.marker = markerDirs.has(pd); p.files++;
    for (const [id, re] of SECRET_RES) { let m; re.lastIndex = 0; while ((m = re.exec(text)) && p.creds.size < 30) { p.creds.add(id + ':' + sha(m[0]).slice(0, 8)); stat.secrets++; } }
    const base = path.basename(full).toLowerCase();
    if (base === '.env' || base.startsWith('.env.') || base.endsWith('.env')) { for (const line of text.split(/\r?\n/)) { const m = line.match(/^\s*(?:export\s+)?([A-Z][A-Z0-9_]*(?:API_KEY|TOKEN|SECRET|PASSWORD)[A-Z0-9_]*)\s*=\s*(.+)$/); if (m && m[2].trim() && !/^['"]?(your|xxx|changeme|<)/i.test(m[2].trim())) { p.creds.add('env:' + m[1] + ':' + sha(m[2].trim()).slice(0, 8)); p.envNames.add(m[1]); } } }
    if (structured) return;
    for (const [id, re] of FRAMEWORKS) if (re.test(text)) p.frameworks.add(id);
    if (/image\s*:|^FROM\s/im.test(text)) for (const [id, re, label] of IMAGES) if (re.test(text)) p.images.add(label);
    let m; MODEL_RE.lastIndex = 0; while ((m = MODEL_RE.exec(text)) && p.models.size < 12) p.models.add(m[1].toLowerCase());
    TOOL_FN_RE.lastIndex = 0; while ((m = TOOL_FN_RE.exec(text)) && p.tools.size < 40) p.tools.add(m[1] || m[2] || m[3]);
  }
  for (const root of roots) { if (!fs.existsSync(root)) { ctx.log('files: folder not found: ' + root); continue; } ctx.log('files: walking ' + root); await walk(path.resolve(root), path.resolve(root), 0); }
  const agents = [], summary = [];
  for (const p of projects.values()) {
    const ai = p.frameworks.size > 0 || p.images.size > 0 || (p.models.size > 0 && p.creds.size > 0);
    if (!ai) continue;
    const models = Array.from(p.models), fw = Array.from(p.frameworks).concat(Array.from(p.images));
    agents.push({ name: projName(p.dir), platform: fw.join(', ') || 'code', model: models[0] || null, tools: Array.from(p.tools), credentials: Array.from(p.creds) });
    summary.push({ project: projName(p.dir), path: p.dir, frameworks: fw, models, tools: Array.from(p.tools), credential_fingerprints: Array.from(p.creds).length, env_variable_names: Array.from(p.envNames) });
  }
  if (summary.length) ctx.addEvidence('code-scan-' + Date.now() + '.json', JSON.stringify({ collector: 'files', projects: summary }, null, 1), { kind: 'doc' });
  stat.projects = agents.length;
  ctx.addAgents(agents, 'files');
  ctx.progress({ pct: 100, note: stat.files + ' files seen, ' + stat.evidence + ' evidence files kept, ' + agents.length + ' agent projects found' });
  return stat;
};

/* ---------- module: this computer ---------- */
function sh(cmd, args, ms) { return new Promise(res => { try { cp.execFile(cmd, args, { timeout: ms || 15000, maxBuffer: 16 * 1048576, windowsHide: true }, (e, out) => res(e ? '' : String(out))); } catch (e) { res(''); } }); }
exports.localhost = async function (ctx) {
  const found = [];
  let procs = '';
  if (process.platform === 'win32') procs = await sh('powershell', ['-NoProfile', '-Command', 'Get-CimInstance Win32_Process | ForEach-Object { $_.Name + " " + $_.CommandLine }'], 30000);
  else procs = await sh('ps', ['-eo', 'comm,args'], 15000);
  const PROC = [['ollama', /\bollama\b/i, 'Ollama'], ['n8n', /\bn8n\b/i, 'n8n'], ['node-red', /node-red/i, 'Node-RED'], ['flowise', /flowise/i, 'Flowise'], ['langflow', /langflow/i, 'Langflow'], ['vllm', /\bvllm\b/i, 'vLLM'], ['litellm', /litellm/i, 'LiteLLM'], ['jupyter', /jupyter/i, 'Jupyter'], ['streamlit', /streamlit/i, 'Streamlit app'], ['mcp', /mcp[-_ ]server|fastmcp|modelcontextprotocol/i, 'MCP server'], ['langgraph', /langgraph/i, 'LangGraph server'], ['agent', /(crewai|autogen|smolagents)/i, 'agent framework process']];
  for (const line of procs.split(/\r?\n/)) for (const [id, re, label] of PROC) if (re.test(line) && !/grep|powershell|Get-CimInstance/i.test(line)) { if (!found.find(f => f.id === id)) found.push({ id, label, line: line.slice(0, 160) }); }
  const docker = await sh('docker', ['ps', '--format', '{{.Names}}|{{.Image}}|{{.Ports}}'], 15000);
  for (const l of docker.split(/\r?\n/).filter(Boolean)) { const [name, image] = l.split('|'); for (const [id, re, label] of IMAGES) if (re.test(image) || re.test(name)) found.push({ id: 'docker-' + id, label: label + ' (container ' + name + ')', line: l }); }
  const envNames = Object.keys(process.env).filter(k => /(OPENAI|ANTHROPIC|GEMINI|COHERE|MISTRAL|HUGGING|AZURE_OPENAI|GROQ|XAI)[A-Z_]*(KEY|TOKEN)/i.test(k));
  const agents = found.map(f => ({ name: 'this-computer-' + f.id, platform: f.label, tools: [] }));
  ctx.addAgents(agents, 'localhost');
  ctx.addEvidence('this-computer-' + Date.now() + '.json', JSON.stringify({ collector: 'localhost', host: os.hostname(), platform: process.platform, found: found.map(f => ({ id: f.id, label: f.label })), api_key_variable_names: envNames }, null, 1), { kind: 'doc' });
  ctx.progress({ pct: 100, note: found.length + ' agent-related processes or containers, ' + envNames.length + ' API key variable names (names only)' });
  return { found: found.length };
};

/* ---------- module: network ---------- */
exports.network = async function (ctx) {
  const specs = (ctx.scope.ranges || []).concat(ctx.scope.hosts || []).map(s => String(s).trim()).filter(Boolean);
  if (!specs.length) { ctx.log('network: nothing to look at, skipped'); return { skipped: true }; }
  const hosts = Array.from(new Set(specs.flatMap(s => cidr(s, 70000))));
  const conc = ctx.scope.concurrency || 200, tmo = ctx.scope.timeoutMs || 800;
  const extra = (ctx.scope.extraPorts || []).map(Number).filter(p => p > 0 && p < 65536);
  const ports = Array.from(new Set(AGENT_PORTS.concat(extra)));
  ctx.log('network: ' + hosts.length + ' addresses, stage 1 finds machines that answer, stage 2 looks for agent platforms');
  const live = new Map(); let done = 0; const t0 = Date.now();
  const stage1 = hosts.length <= 512 ? null : LIVE_PORTS.concat([11434, 5678, 3000, 8000, 7860, 6333, 4000, 8501]);
  if (!stage1) { for (const h of hosts) live.set(h, new Set()); ctx.log('network: ' + hosts.length + ' addresses is a small list, checking every address directly'); }
  else {
    const total = hosts.length * stage1.length;
    await pool(hosts.flatMap(h => stage1.map(p => [h, p])), conc, async ([h, p]) => { if (await tcp(h, p, tmo)) { if (!live.has(h)) live.set(h, new Set()); live.get(h).add(p); } done++; if (done % 200 === 0) ctx.progress({ pct: Math.round(done / total * 50), note: 'stage 1: ' + done + ' of ' + total + ' probes, ' + live.size + ' machines answering' }); }, ctx.stopped);
    ctx.log('network: ' + live.size + ' machines answered');
  }
  const open = []; const jobs = []; for (const h of live.keys()) for (const p of ports) jobs.push([h, p]);
  let d2 = 0;
  await pool(jobs, conc, async ([h, p]) => { if (await tcp(h, p, tmo)) open.push([h, p]); d2++; if (d2 % 200 === 0) ctx.progress({ pct: 50 + Math.round(d2 / (jobs.length || 1) * 35), note: 'stage 2: ' + d2 + ' of ' + jobs.length + ' probes, ' + open.length + ' open ports' }); }, ctx.stopped);
  const findings = []; let d3 = 0;
  await pool(open, 20, async ([h, p]) => {
    for (const sig of SIGS) {
      if (sig.ports && !sig.ports.includes(p)) continue;
      const r = await get(h, p, sig.path, 2500); d3++;
      if (r && r.status && r.status < 500 && r.body != null) {
        const hit = sig.test(r.body, r.headers);
        if (hit) { findings.push({ host: h, port: p, id: sig.id, label: sig.label, models: hit.models || [], open_without_sign_in: r.status === 200 }); break; }
      }
    }
  }, ctx.stopped);
  const agents = findings.map(f => ({ name: f.id + '-' + f.host.replace(/\./g, '-') + '-' + f.port, platform: f.label, model: f.models[0] || null, tools: f.models.length > 1 ? f.models.slice(1, 12) : [], inputs: f.open_without_sign_in ? 'public' : 'internal'}));
  ctx.addAgents(agents, 'network');
  ctx.addEvidence('network-scan-' + Date.now() + '.json', JSON.stringify({ collector: 'network', addresses_checked: hosts.length, machines_answering: live.size, open_ports: open.length, agent_platforms: findings, seconds: Math.round((Date.now() - t0) / 1000) }, null, 1), { kind: 'doc' });
  ctx.progress({ pct: 100, note: live.size + ' machines answered, ' + findings.length + ' agent platforms identified' });
  return { machines: live.size, platforms: findings.length };
};

/* ---------- module: pulls (the client's own APIs, read-only GET) ---------- */
exports.pulls = async function (ctx) {
  const pulls = (ctx.scope.pulls || []).filter(p => p && p.url);
  if (!pulls.length) { ctx.log('pulls: none given, skipped'); return { skipped: true }; }
  let ok = 0, i = 0;
  for (const p of pulls) {
    if (ctx.stopped()) break; i++;
    try {
      const u = new URL(p.url); const hdr = ctx.secrets[p.name] || {};
      const r = await new Promise(res => { const mod = u.protocol === 'https:' ? https : http; const rq = mod.request({ host: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80), path: u.pathname + u.search, method: 'GET', headers: Object.assign({ accept: 'application/json', 'user-agent': 'antara-north-star-collector/0.2' }, hdr), timeout: 60000, rejectUnauthorized: false }, rs => { const chunks = []; let n = 0; rs.on('data', d => { n += d.length; if (n < 300 * 1048576) chunks.push(d); }); rs.on('end', () => res({ status: rs.statusCode, body: Buffer.concat(chunks).toString('utf8') })); }); rq.on('error', e => res({ error: e.message })); rq.on('timeout', () => { rq.destroy(); res({ error: 'timed out' }); }); rq.end(); });
      if (r.error || r.status >= 400) { ctx.log('pulls: ' + p.name + ' failed: ' + (r.error || 'HTTP ' + r.status)); continue; }
      const name = slug(p.name || 'pull') + (p.saveAs ? '' : '.json'); ctx.addEvidence(p.saveAs || name, r.body, { from: p.url, kind: 'pull' }); ok++;
    } catch (e) { ctx.log('pulls: ' + p.name + ' failed: ' + e.message); }
    ctx.progress({ pct: Math.round(i / pulls.length * 100), note: i + ' of ' + pulls.length + ' pulled' });
  }
  return { ok };
};

exports.MODULES = [
  { id: 'files', label: 'Folders: code, configs, logs, exports', fn: exports.files, blurb: 'Reads the folders you list. Finds agent projects, model names, tool names, keys left in files (only a fingerprint is kept, never the key), n8n and MCP files, activity logs, price lists and any export it recognises.' },
  { id: 'localhost', label: 'This computer', fn: exports.localhost, blurb: 'Lists agent-related programs and containers running here, and the names of API key settings (names only).' },
  { id: 'network', label: 'Network: find agent platforms', fn: exports.network, blurb: 'Looks at the address ranges you list. Finds machines, then asks known agent platforms who they are. Reads only. Notes which ones answer without a sign-in.' },
  { id: 'pulls', label: "The client's own APIs", fn: exports.pulls, blurb: 'Reads from web addresses you give it, using a read-only key the client supplies. Anything it gets is saved as evidence.' }
];

/* rough time estimate, in seconds, shown before starting. Real progress replaces it once the run starts. */
exports.estimate = scope => {
  const out = {};
  const hosts = Array.from(new Set((scope.ranges || []).concat(scope.hosts || []).flatMap(s => cidr(s, 70000))));
  if (hosts.length) { const conc = scope.concurrency || 200, tmo = (scope.timeoutMs || 800) / 1000; const s1 = hosts.length <= 512 ? 0 : hosts.length * (LIVE_PORTS.length + 8) / conc * tmo; const s2 = (hosts.length <= 512 ? hosts.length : Math.max(5, hosts.length * 0.08)) * AGENT_PORTS.length / conc * tmo; out.network = { low: Math.round(s1 * 0.15 + 20), high: Math.round(s1 + s2 + 60), hosts: hosts.length }; }
  if ((scope.roots || []).length) out.files = { low: 60 * scope.roots.length, high: 3600 * scope.roots.length, note: 'depends on how many files; the page shows the real speed after a minute' };
  out.localhost = { low: 5, high: 40 }; if ((scope.pulls || []).length) out.pulls = { low: 5, high: 300 };
  return out;
};
