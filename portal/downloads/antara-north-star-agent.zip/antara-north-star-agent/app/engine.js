"use strict";
var AF = {};

/* ---- core.js ---- */
(function(AF){
/* Antara North Star - core: utilities, hash chain, registry, call gate.
   Offline. No network calls anywhere in this file. */
'use strict';

AF.NAME = 'Antara North Star';
AF.NAME_NOTE = 'Soundings, Sentinel, Keel, Reckoning';
AF.VERSION = '0.1.0';

/* ---------- utilities ---------- */
const U = AF.U = {};
U.slug = s => String(s == null ? '' : s).toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
U.num = v => {
  if (typeof v === 'number') return isFinite(v) ? v : null;
  if (v == null || v === '') return null;
  const n = parseFloat(String(v).replace(/[£$€,\s]/g, ''));
  return isFinite(n) ? n : null;
};
U.ms = ts => { const t = Date.parse(ts); return isFinite(t) ? t : null; };
U.day = ms => Math.floor(ms / 86400000);
U.iso = ms => new Date(ms).toISOString().slice(0, 10);
U.uniq = a => Array.from(new Set(a));
U.sum = a => a.reduce((s, x) => s + (x || 0), 0);
U.mean = a => a.length ? U.sum(a) / a.length : 0;
U.quantile = (a, q) => {
  if (!a.length) return 0;
  const s = a.slice().sort((x, y) => x - y);
  const pos = (s.length - 1) * q, lo = Math.floor(pos), hi = Math.ceil(pos);
  return s[lo] + (s[hi] - s[lo]) * (pos - lo);
};
U.median = a => U.quantile(a, 0.5);
U.pct = (n, d) => d ? Math.round((n / d) * 1000) / 10 : 0;
U.round = (x, p) => { const f = Math.pow(10, p == null ? 2 : p); return Math.round(x * f) / f; };
U.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
U.deepFreeze = o => {
  if (o && typeof o === 'object' && !Object.isFrozen(o)) {
    Object.freeze(o);
    for (const k of Object.keys(o)) U.deepFreeze(o[k]);
  }
  return o;
};
U.groupBy = (arr, fn) => { const m = new Map(); for (const x of arr) { const k = fn(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); } return m; };
U.prng = seed => { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };

/* sha-256, synchronous, no dependencies (cross-checked against Node crypto in tests) */
U.sha256 = (() => {
  const K = [], H0 = [];
  const isPrime = n => { for (let i = 2; i * i <= n; i++) if (n % i === 0) return false; return true; };
  const frac = x => (x - Math.floor(x)) * 4294967296 | 0;
  for (let n = 2, c = 0; c < 64; n++) if (isPrime(n)) { K.push(frac(Math.cbrt(n))); if (c < 8) H0.push(frac(Math.sqrt(n))); c++; }
  const enc = new TextEncoder();
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  return str => {
    const bytes = enc.encode(String(str)), l = bytes.length;
    const total = ((l + 9 + 63) >> 6) << 6;
    const buf = new Uint8Array(total); buf.set(bytes); buf[l] = 0x80;
    const dv = new DataView(buf.buffer);
    dv.setUint32(total - 8, Math.floor((l * 8) / 4294967296)); dv.setUint32(total - 4, (l * 8) >>> 0);
    const h = H0.slice(), w = new Array(64);
    for (let o = 0; o < total; o += 64) {
      for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      let [a, b, c, d, e, f, g, hh] = h;
      for (let i = 0; i < 64; i++) {
        const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25), ch = (e & f) ^ (~e & g);
        const t1 = (hh + S1 + ch + K[i] + w[i]) | 0;
        const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + mj) | 0;
        hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + b) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
      h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
    }
    return h.map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
  };
})();

/* ---------- defaults the engine uses when the customer has not said ---------- */
AF.DEFAULTS = {
  maxDepth: 3, maxFanout: 8,
  irreversibleRequiresApproval: true,
  minReviewMs: 4000, fastShareFlag: 0.2, reviewerDailyMax: 120,
  maxPriceAgeDays: 90, retireWarnDays: 180,
  inactiveDays: 45, unusedToolDays: 60,
  monoShare: 0.7, overlapThreshold: 0.6,
  volumeShort: 0.5, costHigh: 1.3, coverageOk: 0.8,
  reviewMinutesPerApproval: null, reviewCostPerHour: null
};

/* ---------- registry: every agent is declared here, with what it may call ---------- */
const TIER_DEPTH = { supervisor: 0, lead: 1, worker: 2, task: 3 };
const HARD_DEPTH = 3, HARD_FANOUT = 8;
AF.TIER_DEPTH = TIER_DEPTH; AF.HARD_DEPTH = HARD_DEPTH; AF.HARD_FANOUT = HARD_FANOUT;
AF.REG = {};
AF.define = spec => {
  if (!(spec.tier in TIER_DEPTH)) throw new Error('unknown tier ' + spec.tier);
  const s = Object.assign({ may_call: [], reads: [], writes: [], authority: 'read', needs: [], module: null, version: '0.1.0' }, spec);
  if (s.may_call.length > HARD_FANOUT) throw new Error(s.id + ' exceeds fan-out ' + HARD_FANOUT);
  AF.REG[s.id] = s;
  return s;
};

/* Static audit of the agent estate this tool is made of. The product governs itself by its own rules. */
AF.checkRegistry = () => {
  const problems = [];
  for (const a of Object.values(AF.REG)) {
    if (a.authority !== 'read') problems.push(a.id + ': authority must be read-only');
    if (a.may_call.length > HARD_FANOUT) problems.push(a.id + ': fan-out ' + a.may_call.length);
    for (const c of a.may_call) {
      const t = AF.REG[c];
      if (!t) { problems.push(a.id + ' -> ' + c + ': callee not registered'); continue; }
      if (TIER_DEPTH[t.tier] !== TIER_DEPTH[a.tier] + 1) problems.push(a.id + ' -> ' + c + ': must call exactly one tier down');
      if (TIER_DEPTH[t.tier] > HARD_DEPTH) problems.push(a.id + ' -> ' + c + ': beyond depth cap');
    }
  }
  return problems;
};

/* ---------- the gate: all agent calls go through here ---------- */
class GateError extends Error { constructor(m, why) { super(m); this.why = why; } }
AF.GateError = GateError;

AF.Gate = class Gate {
  constructor(caps) {
    caps = caps || {};
    this.maxCalls = caps.maxCalls || 200000;
    this.maxMs = caps.maxMs || 120000;
    this.started = Date.now();
    this.calls = 0;
    this.fan = new Map();
    this.trace = [];
    this.prev = 'GENESIS';
    this.denied = [];
  }
  stamp(entry) {
    const body = JSON.stringify(entry);
    const hash = U.sha256(this.prev + body);
    const rec = Object.assign({}, entry, { prev: this.prev, hash });
    this.prev = hash;
    this.trace.push(rec);
    return rec;
  }
  static sig(o) {
    if (o == null) return 'null';
    if (Array.isArray(o)) return 'array:' + o.length;
    if (typeof o !== 'object') return typeof o;
    return Object.keys(o).sort().map(k => k + (Array.isArray(o[k]) ? '[' + o[k].length + ']' : '')).join(',');
  }
  deny(caller, callee, why) {
    const rec = this.stamp({ seq: this.trace.length, caller, callee, status: 'denied', why });
    this.denied.push(rec);
    throw new GateError(caller + ' -> ' + callee + ' denied: ' + why, why);
  }
  call(caller, callee, args) {
    const c = AF.REG[caller], t = AF.REG[callee];
    if (!c) this.deny(caller, callee, 'caller not registered');
    if (!t) this.deny(caller, callee, 'callee not registered');
    if (!c.may_call.includes(callee)) this.deny(caller, callee, 'not in caller manifest');
    if (TIER_DEPTH[t.tier] > HARD_DEPTH) this.deny(caller, callee, 'depth cap ' + HARD_DEPTH);
    if (TIER_DEPTH[t.tier] !== TIER_DEPTH[c.tier] + 1) this.deny(caller, callee, 'must call exactly one tier down');
    const set = this.fan.get(caller) || new Set();
    if (!set.has(callee) && set.size >= HARD_FANOUT) this.deny(caller, callee, 'fan-out cap ' + HARD_FANOUT);
    if (this.calls >= this.maxCalls) this.deny(caller, callee, 'call budget ' + this.maxCalls);
    if (Date.now() - this.started > this.maxMs) this.deny(caller, callee, 'time budget');
    set.add(callee); this.fan.set(caller, set);
    this.calls++;
    const t0 = Date.now();
    let res, status = 'ok', err = null;
    try {
      res = t.fn(args, { call: (next, a) => this.call(callee, next, a), id: callee });
    } catch (e) {
      if (e instanceof GateError) throw e;
      status = 'error'; err = String(e && e.message || e);
    }
    const entry = { seq: this.trace.length, caller, callee, depth: TIER_DEPTH[t.tier], status, args: Gate.sig(args), result: Gate.sig(res) };
    if (err) entry.error = err;
    const rec = this.stamp(entry);
    rec.ms = Date.now() - t0; // timing is kept outside the hashed body so runs reproduce
    if (status === 'error') return { error: err };
    return res;
  }
};

/* Recompute the chain over any trace. Returns { ok, brokenAt } */
AF.verifyChain = trace => {
  let prev = 'GENESIS';
  for (let i = 0; i < trace.length; i++) {
    const r = trace[i];
    const body = {}; for (const k of Object.keys(r)) if (k !== 'prev' && k !== 'hash' && k !== 'ms') body[k] = r[k];
    if (r.prev !== prev || U.sha256(prev + JSON.stringify(body)) !== r.hash) return { ok: false, brokenAt: i };
    prev = r.hash;
  }
  return { ok: true, head: prev, length: trace.length };
};

})(AF);

/* ---- intake.js ---- */
(function(AF){
/* Intake: the shared task agents, the evidence loader, and the intake lead. */
'use strict';
const U = AF.U;

/* ========== task agents (depth 3). Pure functions, no side effects, no network. ========== */

function parseCSV(text) {
  const rows = []; let row = [], cur = '', q = false;
  text = String(text).replace(/^﻿/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some(x => x !== '')) rows.push(row); row = []; }
    else cur += c;
  }
  row.push(cur); if (row.some(x => x !== '')) rows.push(row);
  if (!rows.length) return [];
  const head = rows[0].map(h => h.trim());
  return rows.slice(1).map(r => { const o = {}; head.forEach((h, i) => { o[h] = (r[i] || '').trim(); }); return o; });
}
AF.parseCSV = parseCSV;

const lc = o => { const r = {}; for (const k of Object.keys(o)) r[k.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')] = o[k]; return r; };
const pick = (o, keys) => { for (const k of keys) if (o[k] != null && o[k] !== '') return o[k]; return null; };
const yes = v => /^(y|yes|true|1)$/i.test(String(v == null ? '' : v).trim());
const list = v => Array.isArray(v) ? v.map(String) : (v == null || v === '' ? [] : String(v).split(/[;,|]/).map(s => s.trim()).filter(Boolean));

function attrsOf(span) {
  const a = span.attributes || {};
  if (Array.isArray(a)) { const o = {}; for (const kv of a) { const v = kv.value || {}; o[kv.key] = v.stringValue != null ? v.stringValue : v.intValue != null ? Number(v.intValue) : v.doubleValue != null ? v.doubleValue : v.boolValue; } return o; }
  return a;
}

AF.define({
  id: 'reader', tier: 'task', purpose: 'Parse one file into typed records. Never decides anything.', reads: ['file text'], writes: ['records'],
  fn: ({ name, text }) => {
    const lname = String(name).toLowerCase();
    const ext = (lname.match(/\.([a-z0-9]+)$/) || [])[1] || '';
    const out = (kind, data, evidence, note) => ({ kind, data, evidence: evidence || 'declared', note: note || '', records: Array.isArray(data) ? data.length : (data && typeof data === 'object' ? Object.keys(data).length : 0) });
    try {
      if (ext === 'csv') {
        const rows = parseCSV(text); const h = rows.length ? Object.keys(lc(rows[0])) : [];
        if (h.includes('item_id') && h.includes('decision')) return out('drill_responses', rows.map(lc), 'observed');
        if (h.includes('agent') && (h.includes('owner') || h.includes('systems'))) return out('inventory', rows.map(lc), 'declared');
        if (h.includes('description') && h.includes('amount')) return out('expenses', rows.map(lc), 'observed');
        if (h.includes('extension') && h.includes('users')) return out('extensions', rows.map(lc), 'observed');
        if (h.includes('person') || (h.includes('name') && h.includes('left'))) return out('people', rows.map(lc), 'declared');
        return out('doc', [], 'declared', 'CSV not recognised, kept as an unscored document');
      }
      if (ext === 'jsonl' || ext === 'ndjson') {
        const recs = String(text).split(/\r?\n/).filter(l => l.trim()).map(l => JSON.parse(l));
        if (recs.length && recs[0].agent !== undefined) return out('runs', recs, 'observed');
        if (recs.length && (recs[0].tool !== undefined || recs[0].session !== undefined)) return out('trace_jsonl', recs, 'observed', 'tool-call trace without agent name, agent taken from file name (inferred)');
        return out('doc', [], 'declared', 'JSONL not recognised');
      }
      if (ext === 'json') {
        const j = JSON.parse(text);
        if (j.resourceSpans) {
          const spans = [];
          for (const rs of j.resourceSpans) { for (const s of (rs.spans || [])) spans.push(s); for (const ss of (rs.scopeSpans || [])) for (const s of (ss.spans || [])) spans.push(s); }
          return out('otel', spans.map(s => ({ s, a: attrsOf(s) })), 'observed');
        }
        if (Array.isArray(j.agents) && !j.nodes) return out('estate', j, 'declared');
        if (j.models && (j.as_of || j.asOf)) return out('prices', j, 'declared');
        if (Array.isArray(j.cases)) return out('cases', j.cases, 'declared');
        if (Array.isArray(j.outcomes)) return out('outcomes', j.outcomes, 'declared');
        if (Array.isArray(j.people)) return out('people', j.people.map(lc), 'declared');
        if (Array.isArray(j.items) && Array.isArray(j.key)) return out('drill_key', j, 'declared');
        if (j.approved_models || j.link_rules || j.max_depth || j.min_review_ms !== undefined || j.irreversible_requires_approval !== undefined || j.policy) return out('policy', j.policy || j, 'declared');
        if (Array.isArray(j.nodes)) return out('n8n', j, 'declared');
        if (j.mcpServers) return out('mcp', j, 'declared');
        return out('doc', [], 'declared', 'JSON not recognised, kept as an unscored document');
      }
      return out('doc', [], 'declared', 'text document kept, not scored');
    } catch (e) {
      return { kind: 'error', data: null, evidence: 'unknown', records: 0, note: 'could not parse: ' + e.message };
    }
  }
});

AF.define({
  id: 'resolver', tier: 'task', purpose: 'Match names to known entities. Reports how sure it is.', reads: ['names', 'known entities'], writes: ['matches'],
  fn: ({ names, known, aliases }) => {
    const idx = new Map(known.map(k => [U.slug(k.name), k.id])); for (const k of known) idx.set(k.id, k.id);
    const al = aliases || {};
    const map = {};
    for (const n of names) {
      const s = U.slug(n);
      if (!s) { map[n] = { id: null, method: 'none' }; continue; }
      if (idx.has(s)) { map[n] = { id: idx.get(s), method: 'exact' }; continue; }
      if (al[s] && idx.has(al[s])) { map[n] = { id: idx.get(al[s]), method: 'alias' }; continue; }
      let best = null;
      for (const [k, id] of idx) if (k.length >= 5 && s.length >= 5 && (k.includes(s) || s.includes(k))) { best = id; break; }
      map[n] = best ? { id: best, method: 'fuzzy' } : { id: null, method: 'none' };
    }
    return { map };
  }
});

AF.define({
  id: 'stamper', tier: 'task', purpose: 'Hash a payload and link it into a chain.', reads: ['payload'], writes: ['hash'],
  fn: ({ payload, prev }) => ({ hash: U.sha256((prev || 'GENESIS') + (typeof payload === 'string' ? payload : JSON.stringify(payload))) })
});

AF.define({
  id: 'redactor', tier: 'task', purpose: 'Mask personal data before it is stored.', reads: ['text'], writes: ['masked text'],
  fn: ({ values }) => ({
    values: values.map(v => String(v == null ? '' : v)
      .replace(/([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})/g, '$1***@$2')
      .replace(/\b(sk|pk|key|tok)[-_][A-Za-z0-9]{12,}\b/gi, '[secret masked]')
      .replace(/\b[A-F0-9]{32,}\b/g, '[hex masked]'))
  })
});

AF.define({
  id: 'patternMatch', tier: 'task', purpose: 'Test strings against named patterns.', reads: ['strings', 'patterns'], writes: ['matches'],
  fn: ({ values, rules }) => {
    const res = rules.map(r => ({ id: r.id, re: new RegExp(r.re, r.flags || 'i') }));
    return { hits: values.map(v => res.filter(r => r.re.test(String(v == null ? '' : v))).map(r => r.id)) };
  }
});

AF.define({
  id: 'counter', tier: 'task', purpose: 'Group, count, sum and take quantiles. Arithmetic only.', reads: ['records'], writes: ['numbers'],
  fn: ({ items, key, sums, quantiles }) => {
    const m = new Map();
    for (const it of items) {
      const k = key ? (Array.isArray(key) ? key.map(f => it[f]).join('|') : it[key]) : 'all';
      let g = m.get(k); if (!g) { g = { key: k, count: 0, sums: {}, vals: {} }; m.set(k, g); }
      g.count++;
      for (const f of (sums || [])) { const v = it[f]; if (typeof v === 'number') g.sums[f] = (g.sums[f] || 0) + v; }
      for (const f of (quantiles || [])) { const v = it[f]; if (typeof v === 'number') (g.vals[f] = g.vals[f] || []).push(v); }
    }
    const groups = Array.from(m.values()).map(g => {
      const q = {}; for (const f of Object.keys(g.vals)) q[f] = { n: g.vals[f].length, mean: U.mean(g.vals[f]), median: U.median(g.vals[f]), p95: U.quantile(g.vals[f], 0.95), min: g.vals[f].reduce((a, b) => Math.min(a, b), Infinity), max: g.vals[f].reduce((a, b) => Math.max(a, b), -Infinity) };
      return { key: g.key, count: g.count, sums: g.sums, q };
    });
    return { groups, total: items.length };
  }
});

AF.define({
  id: 'priceLookup', tier: 'task', purpose: 'Price token counts from a dated price table. Refuses to invent a price.', reads: ['price table', 'token counts'], writes: ['costs'],
  fn: ({ prices, items }) => {
    const models = (prices && prices.models) || {};
    return {
      costs: items.map(it => {
        const p = models[it.model];
        if (!p) return { cost: null, priced: false };
        return { cost: ((it.inTok || 0) * (p.in || 0) + (it.outTok || 0) * (p.out || 0)) / 1e6, priced: true };
      })
    };
  }
});

AF.define({
  id: 'chainer', tier: 'task', purpose: 'Walk a graph: what is reachable from where, by what path, and which loops exist.', reads: ['edges'], writes: ['reach'],
  fn: ({ edges, starts }) => {
    const adj = new Map();
    for (const e of edges) { if (!adj.has(e.from)) adj.set(e.from, []); adj.get(e.from).push(e.to); }
    const reach = {}, cyclic = [];
    for (const s of starts) {
      const depth = { [s]: 0 }, parent = {}, q = [s]; let back = false;
      for (let i = 0; i < q.length; i++) {
        for (const n of (adj.get(q[i]) || [])) {
          if (n === s) back = true;
          if (!(n in depth)) { depth[n] = depth[q[i]] + 1; parent[n] = q[i]; q.push(n); }
        }
      }
      reach[s] = { nodes: q.slice(1), depth, parent };
      if (back) cyclic.push(s);
    }
    return { reach, cyclic };
  }
});
AF.runsOf = (L, id) => L.runsBy.get(id) || [];
AF.pathTo = (reach, s, t) => { const r = reach[s]; if (!r || !(t in r.depth)) return null; const p = [t]; while (p[0] !== s) p.unshift(r.parent[p[0]]); return p; };

/* ========== the evidence loader (worker, depth 2) ========== */

const IRREV = { id: 'irreversible', re: '(^|[_\\-. ])(send|delete|remove|pay|payment|refund|transfer|approve|issue|publish|deploy|update|write|submit|drop|cancel|post|sign)([_\\-. ]|$)' };
const UNTRUSTED = { id: 'untrusted', re: '(read_email|inbox|fetch|browse|web|scrape|read_url|download|ticket|inbound|webhook|search_web|enquiry|enquiries)' };
const VENDORS = [
  { id: 'chatgpt', re: 'openai|chatgpt', cat: 'chat assistant' }, { id: 'claude', re: 'anthropic|claude\\.ai', cat: 'chat assistant' },
  { id: 'gemini', re: 'gemini|google ai', cat: 'chat assistant' }, { id: 'copilot', re: 'copilot', cat: 'chat assistant' },
  { id: 'otter', re: 'otter\\.ai', cat: 'meeting notetaker' }, { id: 'fireflies', re: 'fireflies', cat: 'meeting notetaker' },
  { id: 'fathom', re: 'fathom', cat: 'meeting notetaker' }, { id: 'read-ai', re: 'read\\.ai', cat: 'meeting notetaker' },
  { id: 'grammarly', re: 'grammarly', cat: 'writing assistant' }, { id: 'jasper', re: 'jasper', cat: 'writing assistant' },
  { id: 'cursor', re: 'cursor', cat: 'coding assistant' }, { id: 'github-copilot', re: 'github copilot', cat: 'coding assistant' },
  { id: 'midjourney', re: 'midjourney', cat: 'image generator' }, { id: 'perplexity', re: 'perplexity', cat: 'search assistant' }
];
AF.VENDORS = VENDORS;

AF.define({
  id: 'evidence_loader', tier: 'worker', module: 'intake', purpose: 'Turn raw files into one normalised evidence ledger, and say how each fact is known.',
  may_call: ['reader', 'resolver', 'stamper', 'redactor', 'patternMatch', 'counter', 'priceLookup', 'chainer'],
  fn: ({ files, overrides }, ctx) => {
    overrides = overrides || {};
    const L = {
      org: {}, policy: {}, agents: [], links: [], tools: {}, runs: [], prices: null, cases: [], outcomes: [], people: [], peopleKnown: false,
      expenses: [], extensions: [], drill: { key: null, responses: null }, sources: [], docs: [], notes: [], pricesStale: false, asOf: null
    };
    const raw = { estateAgents: [], inventory: [], n8n: [], mcp: [], runs: [], otel: [], trace: [], links: [], tools: [] };
    let prev = 'GENESIS';

    for (const f of files) {
      const r = ctx.call('reader', { name: f.name, text: f.text });
      const st = ctx.call('stamper', { payload: f.text, prev: null });
      L.sources.push({ name: f.name, kind: r.kind, records: r.records, evidence: r.evidence, note: r.note, hash: st.hash });
      switch (r.kind) {
        case 'estate': {
          const e = r.data; if (e.org) Object.assign(L.org, e.org);
          raw.estateAgents.push(...e.agents); if (e.links) raw.links.push(...e.links);
          if (Array.isArray(e.tools)) raw.tools.push(...e.tools); break;
        }
        case 'inventory': raw.inventory.push(...r.data); break;
        case 'n8n': raw.n8n.push({ file: f.name, wf: r.data }); break;
        case 'mcp': raw.mcp.push({ file: f.name, cfg: r.data }); break;
        case 'runs': for (const x of r.data) raw.runs.push({ x, src: f.name }); break;
        case 'otel': for (const x of r.data) raw.otel.push({ x, src: f.name }); break;
        case 'trace_jsonl': for (const x of r.data) raw.trace.push({ x, src: f.name }); break;
        case 'prices': L.prices = r.data; break;
        case 'policy': Object.assign(L.policy, r.data); break;
        case 'cases': L.cases.push(...r.data); break;
        case 'outcomes': L.outcomes.push(...r.data); break;
        case 'people': L.people.push(...r.data); L.peopleKnown = true; break;
        case 'expenses': for (const x of r.data) L.expenses.push(x); break;
        case 'extensions': L.extensions.push(...r.data); break;
        case 'drill_key': L.drill.key = r.data; break;
        case 'drill_responses': L.drill.responses = r.data; break;
        case 'doc': L.docs.push({ name: f.name, chars: f.text.length }); break;
        case 'error': L.notes.push(f.name + ': ' + r.note); break;
      }
    }
    // org and policy: file values, then the person's own overrides on top
    Object.assign(L.org, overrides.org || {});
    const pol = {}; for (const k of Object.keys(L.policy)) pol[k.replace(/_([a-z])/g, (_, c) => c.toUpperCase())] = L.policy[k];
    L.policy = Object.assign({}, AF.DEFAULTS, pol, overrides.policy || {});
    if (L.prices) { L.prices = Object.assign({}, L.prices, { as_of: L.prices.as_of || L.prices.asOf }); }

    /* ----- agents ----- */
    const byId = new Map();
    const add = (a, ev, src) => {
      const id = a.id ? U.slug(a.id) : U.slug(a.name);
      if (!id) return;
      let cur = byId.get(id);
      if (!cur) { cur = { id, name: a.name || a.id, tier: 'unknown', parent: null, purpose: '', model: null, provider: null, owner: null, dept: null, platform: null, tools: [], data: [], inputs: null, version: null, approved_version: null, approved_at: null, status: 'active', credentials: [], complexity: null, case_id: null, created: null, external: false, endpoint: null, risk: null, validated_at: null, known_security: null, approved: null, shadow: false, kind: null, sources: [] }; byId.set(id, cur); }
      for (const k of Object.keys(a)) { if (a[k] !== undefined && a[k] !== null && a[k] !== '' && k in cur && k !== 'id' && k !== 'sources' && k !== 'shadow') { cur[k] = a[k]; } }
      if (a.name) cur.name = a.name;
      cur.sources.push(src); return cur;
    };
    for (const row of raw.inventory) {
      const name = row.agent; if (!name) continue;
      const kn = row.known_to_security, ap = row.approved;
      add({ name, owner: row.owner || null, dept: row.department || null, tools: list(row.systems), known_security: kn === '' || kn == null ? null : yes(kn), approved: ap === '' || ap == null ? null : yes(ap) }, 'declared', 'inventory');
    }
    for (const a of raw.estateAgents) { const x = Object.assign({}, a); if (x.parent) x.parent = U.slug(x.parent); add(x, 'declared', 'estate'); }
    for (const w of raw.n8n) {
      const nodes = w.wf.nodes || [];
      const hasWebhook = nodes.some(n => /webhook/i.test(n.type));
      add({ name: w.wf.name || w.file, platform: 'n8n', inputs: hasWebhook ? 'public' : 'internal', tools: nodes.map(n => n.name + ' (' + String(n.type).split('.').pop() + ')') }, 'declared', 'n8n:' + w.file);
    }
    for (const m of raw.mcp) {
      const nm = m.file.replace(/\.mcp\.json$|\.json$/i, '');
      add({ name: nm, tools: Object.keys(m.cfg.mcpServers || {}) }, 'declared', 'mcp:' + m.file);
    }
    L.agents = Array.from(byId.values());
    const known = () => L.agents.map(a => ({ id: a.id, name: a.name }));

    /* ----- runs ----- */
    const rawRuns = [];
    for (const { x, src } of raw.runs) {
      const o = lc(x);
      rawRuns.push({ agentName: pick(o, ['agent', 'agent_name']), ts: pick(o, ['ts', 'timestamp', 'time']), model: pick(o, ['model']), version: pick(o, ['version', 'agent_version']), inTok: U.num(pick(o, ['in_tokens', 'input_tokens', 'prompt_tokens'])), outTok: U.num(pick(o, ['out_tokens', 'output_tokens', 'completion_tokens'])), cost_obs: U.num(pick(o, ['cost', 'cost_usd', 'cost_gbp'])), outcome: pick(o, ['outcome', 'status']) || 'ok', trace: pick(o, ['trace_id', 'trace', 'session']), span: pick(o, ['span_id', 'span']), parentSpan: pick(o, ['parent_span', 'parent_span_id']), parentAgentName: pick(o, ['parent_agent']), tool: pick(o, ['tool', 'action']), irreversible: o.irreversible == null ? null : yes(o.irreversible), approvedBy: pick(o, ['approved_by', 'approver']), approvalMs: U.num(pick(o, ['approval_ms'])), inputHash: pick(o, ['input_hash']), durMs: U.num(pick(o, ['dur_ms', 'duration_ms'])), src, basis: 'observed' });
    }
    for (const { x, src } of raw.otel) {
      const a = x.a, s = x.s;
      const ts = s.start_time || s.startTime || (s.startTimeUnixNano ? new Date(Number(s.startTimeUnixNano) / 1e6).toISOString() : null);
      rawRuns.push({ agentName: a['gen_ai.agent.name'] || a['agent.name'] || null, ts, model: a['gen_ai.request.model'] || a['gen_ai.response.model'] || null, version: a['gen_ai.agent.version'] || null, inTok: U.num(a['gen_ai.usage.input_tokens']), outTok: U.num(a['gen_ai.usage.output_tokens']), cost_obs: null, outcome: s.status && s.status.code === 2 ? 'error' : 'ok', trace: s.trace_id || s.traceId, span: s.span_id || s.spanId, parentSpan: s.parent_span_id || s.parentSpanId || null, parentAgentName: null, tool: a['gen_ai.tool.name'] || null, irreversible: null, approvedBy: a['approved_by'] || null, approvalMs: U.num(a['approval_ms']), inputHash: null, durMs: null, src, basis: 'observed' });
    }
    for (const { x, src } of raw.trace) {
      const stem = src.replace(/\.[a-z0-9]+$/i, '').replace(/[-_]?trace$/i, '').replace(/[-_]/g, ' ');
      rawRuns.push({ agentName: stem, ts: x.timestamp || x.ts, model: null, version: null, inTok: null, outTok: null, cost_obs: null, outcome: /^error/i.test(String(x.result || '')) ? 'error' : 'ok', trace: x.session, span: null, parentSpan: null, parentAgentName: null, tool: x.tool, irreversible: null, approvedBy: x.approved_by || null, approvalMs: null, inputHash: null, durMs: null, src, basis: 'inferred' });
    }

    // resolve names -> ids; unknown names become shadow agents (seen in activity, not in any register)
    const names = U.uniq(rawRuns.flatMap(r => [r.agentName, r.parentAgentName]).filter(Boolean));
    const aliases = overrides.aliases || {};
    const rs = ctx.call('resolver', { names, known: known(), aliases });
    for (const n of names) {
      if (!rs.map[n].id) { const a = add({ name: n }, 'observed', 'runs'); a.shadow = true; a.tier = 'unknown'; rs.map[n] = { id: a.id, method: 'new' }; }
    }
    L.agents = Array.from(byId.values());
    const fuzzy = names.filter(n => rs.map[n].method === 'fuzzy');
    if (fuzzy.length) L.notes.push('Matched by similar name (check): ' + fuzzy.slice(0, 5).join(', '));

    // tool classes
    const toolNames = U.uniq([].concat(rawRuns.map(r => r.tool).filter(Boolean), L.agents.flatMap(a => a.tools), raw.tools.map(t => t.name)));
    const pm = ctx.call('patternMatch', { values: toolNames, rules: [IRREV, UNTRUSTED] });
    toolNames.forEach((t, i) => { L.tools[t] = { irreversible: pm.hits[i].includes('irreversible'), untrusted: pm.hits[i].includes('untrusted'), basis: 'inferred' }; });
    for (const t of raw.tools) L.tools[t.name] = { irreversible: !!t.irreversible, untrusted: !!t.reads_untrusted, basis: 'declared' };

    // runs: ids, times, irreversibility, price
    const pos = [];
    for (const r of rawRuns) {
      const t = U.ms(r.ts); if (t == null) { L.notes.push('A run without a readable time was skipped.'); continue; }
      pos.push(Object.assign(r, { t, agent: r.agentName ? rs.map[r.agentName].id : null, parentAgentDirect: r.parentAgentName ? rs.map[r.parentAgentName].id : null }));
    }
    // span -> agent map for parent resolution
    const spanAgent = new Map(); for (const r of pos) if (r.span) spanAgent.set(r.trace + '/' + r.span, r.agent);
    for (const r of pos) {
      r.parentAgent = r.parentAgentDirect || (r.parentSpan ? (spanAgent.get(r.trace + '/' + r.parentSpan) || null) : null);
      if (r.parentAgent === r.agent) r.parentAgent = null;
      if (r.irreversible == null) { r.irreversible = !!(r.tool && L.tools[r.tool] && L.tools[r.tool].irreversible); r.irrBasis = 'inferred'; } else r.irrBasis = 'observed';
      r.untrusted = !!(r.tool && L.tools[r.tool] && L.tools[r.tool].untrusted);
    }
    const pr = ctx.call('priceLookup', { prices: L.prices, items: pos.map(r => ({ model: r.model, inTok: r.inTok, outTok: r.outTok })) });
    pos.forEach((r, i) => { r.cost_calc = pr.costs[i].cost; r.priced = pr.costs[i].priced && r.inTok != null; r.cost = r.cost_obs != null ? r.cost_obs : (r.priced ? r.cost_calc : null); r.id = i; });
    pos.sort((a, b) => a.t - b.t); pos.forEach((r, i) => { r.id = i; });
    L.runs = pos;

    /* ----- time frame: the report is "as of" the data, never the system clock, so it reproduces ----- */
    const lastT = pos.length ? pos[pos.length - 1].t : null, firstT = pos.length ? pos[0].t : null;
    const orgAsOf = L.org.as_of || L.org.asOf;
    L.asOf = U.ms(orgAsOf) != null ? U.ms(orgAsOf) : (lastT != null ? U.day(lastT) * 86400000 : null);
    L.window = { first: firstT, last: lastT, days: firstT != null ? Math.max(1, (lastT - firstT) / 86400000) : 0 };
    if (L.prices && L.asOf != null && U.ms(L.prices.as_of) != null) {
      L.prices.ageDays = Math.floor((L.asOf - U.ms(L.prices.as_of)) / 86400000);
      L.pricesStale = L.prices.ageDays > L.policy.maxPriceAgeDays;
    }

    /* ----- people (masked) ----- */
    L.people = L.people.map(p => ({ id: p.id || U.slug(p.name || p.person), name: p.name || p.person, left: p.left || p.left_on || null }));

    /* ----- expenses: classify and mask ----- */
    if (L.expenses.length) {
      const m = ctx.call('patternMatch', { values: L.expenses.map(e => e.description), rules: VENDORS.map(v => ({ id: v.id, re: v.re })) });
      const holders = ctx.call('redactor', { values: L.expenses.map(e => e.cardholder || e.holder || '') });
      L.expenses = L.expenses.map((e, i) => {
        const vid = m.hits[i][0] || null, v = VENDORS.find(x => x.id === vid);
        return { date: e.date, holder: holders.values[i], dept: e.department || e.dept || null, desc: e.description, amount: U.num(e.amount), vendor: vid, category: v ? v.cat : null };
      }).filter(e => e.amount != null);
    }

    /* ----- cases: stay as the customer gave them; source marked original or reconstructed ----- */
    L.cases = L.cases.map(c => ({ id: c.id, name: c.name || c.id, agent_ids: (c.agent_ids || c.agents || []).map(U.slug), benefit_pm: U.num(c.claimed_benefit_per_month), runs_pm: U.num(c.assumed_runs_per_month), cost_per_run: U.num(c.assumed_cost_per_run), payback_months: U.num(c.payback_months), start: c.start || null, owner: c.owner || null, build_cost: U.num(c.build_cost), source: c.source === 'reconstructed' ? 'reconstructed' : 'original' }));
    L.outcomes = L.outcomes.map(o => ({ case_id: o.case_id || null, agent: o.agent ? U.slug(o.agent) : null, month: o.month, benefit: U.num(o.benefit) }));

    /* ----- observed links from calls between agents ----- */
    const declared = new Map();
    for (const l of raw.links) declared.set(U.slug(l.from) + '>' + U.slug(l.to), { from: U.slug(l.from), to: U.slug(l.to), kind: l.kind || 'calls', basis: 'declared', external: !!l.external });
    for (const a of L.agents) if (a.parent) { const k = a.parent + '>' + a.id; if (!declared.has(k)) declared.set(k, { from: a.parent, to: a.id, kind: 'delegates', basis: 'declared', external: false }); }
    const links = new Map(declared);
    const obs = new Map();
    for (const r of pos) if (r.parentAgent && r.agent) { const k = r.parentAgent + '>' + r.agent; obs.set(k, (obs.get(k) || 0) + 1); }
    for (const [k, n] of obs) {
      const [f, t] = k.split('>');
      if (links.has(k)) { const l = links.get(k); links.set(k, Object.assign({}, l, { basis: 'both', calls: n })); }
      else links.set(k, { from: f, to: t, kind: 'calls', basis: 'observed', external: false, calls: n });
    }
    L.links = Array.from(links.values());
    for (const l of L.links) { for (const e of [l.from, l.to]) if (!byId.has(e)) { const a = add({ name: e }, 'declared', 'link'); a.shadow = false; a.stub = true; } }
    L.agents = Array.from(byId.values());
    for (const l of L.links) { const t = byId.get(l.to); if (t && t.external) l.external = true; if (t && l.external) t.external = true; }

    /* ----- derived facts per agent. Computed here once, shown to workers read-only. ----- */
    const runsBy = U.groupBy(pos, r => r.agent);
    L.runsBy = runsBy;
    const policy = L.policy;
    for (const a of L.agents) {
      const rr = runsBy.get(a.id) || [];
      a.run_count = rr.length;
      a.first_run = rr.length ? rr[0].t : null; a.last_run = rr.length ? rr[rr.length - 1].t : null;
      a.observed_models = U.uniq(rr.map(r => r.model).filter(Boolean));
      a.versions_seen = U.uniq(rr.map(r => r.version).filter(Boolean));
      a.tools_used = U.uniq(rr.map(r => r.tool).filter(Boolean));
      const allTools = U.uniq(a.tools.concat(a.tools_used));
      a.irreversible_tools = allTools.filter(t => L.tools[t] && L.tools[t].irreversible);
      a.untrusted_tools = allTools.filter(t => L.tools[t] && L.tools[t].untrusted);
      a.exposed = a.inputs === 'public' || a.untrusted_tools.length > 0;
      a.idle_days = a.last_run != null && L.asOf != null ? Math.floor((L.asOf - a.last_run) / 86400000) : null;
      a.zombie = a.status === 'active' && pos.length > 0 && !a.stub && (a.run_count === 0 ? a.sources.some(x => x === 'estate' || x === 'inventory' || /^(n8n|mcp)/.test(x)) : a.idle_days > policy.inactiveDays);
      const person = L.people.find(p => (a.owner && (U.slug(p.name) === U.slug(String(a.owner).replace(/\s*\(.*\)\s*$/, '')) || p.id === U.slug(a.owner))));
      a.owner_left = !!(person && person.left && L.asOf != null && U.ms(person.left) != null && U.ms(person.left) <= L.asOf);
      a.owner_unknown_person = L.peopleKnown && !!a.owner && !person;
      a.has_case = !!(a.case_id || L.cases.some(c => c.agent_ids.includes(a.id)));
      a.model_mismatch = !!(a.model && a.observed_models.length && !a.observed_models.includes(a.model));
      a.version_drift = !!(a.approved_version && a.versions_seen.some(v => v !== a.approved_version));
    }
    L.sourcesHash = ctx.call('stamper', { payload: L.sources.map(s => s.hash).join('|'), prev: null }).hash;
    return { ledger: L };
  }
});

AF.define({
  id: 'intake', tier: 'lead', module: 'intake', purpose: 'Bring the customer evidence in and say how well it covers the estate.', may_call: ['evidence_loader'],
  fn: (args, ctx) => ctx.call('evidence_loader', args)
});

})(AF);

/* ---- workers_a.js ---- */
(function(AF){
/* Workers, part A: Discover and Secure. Each worker reads the frozen ledger and returns findings.
   Findings carry a declarative 'recheck' so the independent verifier can recompute them. */
'use strict';
const U = AF.U;
const F = o => Object.assign({ severity: 'medium', basis: 'observed', evidence: [], measure: {}, why: '', fix: '', recheck: null }, o);
const real = L => L.agents.filter(a => !a.stub);
const empty = v => v == null || v === '' || (Array.isArray(v) && v.length === 0);
const hasRuns = L => L.runs.length > 0;
const need = (key, critical, test, why, hint) => ({ key, critical, test, why, hint });
const needAgents = need('agents', true, L => real(L).length > 0, 'There is no list of agents to assess.', 'estate.json (agents[]), or an agent inventory CSV, or n8n / MCP config files');
const needRuns = (critical, why) => need('runs', critical, L => hasRuns(L), why || 'Activity records are needed to see what agents actually did.', 'runs.jsonl, OpenTelemetry spans (JSON) or tool-call trace logs');
AF.W = (id, module, purpose, may_call, needs, fn) => AF.define({ id, tier: 'worker', module, purpose, may_call, needs, fn });
AF.F = F; AF.empty = empty;

const mod = (id, cap) => id.slice(0, cap);

/* ============================== DISCOVER ============================== */

AF.W('ai_inventory', 'discover', 'List every agent from every source and show which ones no register knows about.', ['counter'], [needAgents, needRuns(false, 'Without activity records the tool cannot find agents that are running but unregistered.')],
  ({ ledger: L }, ctx) => {
    const A = real(L), out = [];
    const bySrc = ctx.call('counter', { items: A.map(a => ({ s: a.shadow ? 'activity only (not in any register)' : a.sources[0] })), key: 's' });
    const shadow = A.filter(a => a.shadow);
    if (shadow.length) out.push(F({
      title: shadow.length + ' agent' + (shadow.length > 1 ? 's' : '') + ' running that no register lists', severity: shadow.some(a => a.irreversible_tools.length) ? 'high' : 'medium', basis: 'observed',
      claim: 'These agents appear in activity records but in no inventory: ' + shadow.map(a => a.name).join(', ') + '.',
      evidence: shadow.slice(0, 10).map(a => ({ t: 'agent', id: a.id })), measure: { count: shadow.length },
      why: 'An agent nobody has listed has no owner, no review and no budget.', fix: 'Find who built each one, give it an owner, then register it or switch it off.',
      recheck: { kind: 'count', set: 'agents', where: [['shadow', '=', true]], expect: shadow.length }
    }));
    if (hasRuns(L)) {
      const unseen = A.filter(a => !a.shadow && a.run_count === 0);
      if (unseen.length) out.push(F({
        title: unseen.length + ' registered agent' + (unseen.length > 1 ? 's' : '') + ' with no recorded activity', severity: 'low', basis: 'observed',
        claim: 'Listed but never seen in the activity records: ' + unseen.slice(0, 8).map(a => a.name).join(', ') + (unseen.length > 8 ? ', and more' : '') + '.',
        evidence: unseen.slice(0, 10).map(a => ({ t: 'agent', id: a.id })), measure: { count: unseen.length },
        why: 'Either these are dormant (and may still hold access), or the activity records do not cover them.', fix: 'Confirm which. Retire the dormant ones, extend logging for the rest.',
        recheck: { kind: 'count', set: 'agents', where: [['shadow', '!=', true], ['stub', '!=', true], ['run_count', '=', 0]], expect: unseen.length }
      }));
    }
    const unknownSec = A.filter(a => a.known_security === false);
    if (unknownSec.length) out.push(F({
      title: unknownSec.length + ' agent' + (unknownSec.length > 1 ? 's' : '') + ' the security team does not know about', severity: 'medium', basis: 'declared',
      claim: 'Inventory says these are unknown to security: ' + unknownSec.map(a => a.name).join(', ') + '.',
      evidence: unknownSec.map(a => ({ t: 'agent', id: a.id })), measure: { count: unknownSec.length },
      why: 'Security cannot protect what it has not been told about.', fix: 'Brief security and add each to their asset list.',
      recheck: { kind: 'count', set: 'agents', where: [['known_security', '=', false]], expect: unknownSec.length }
    }));
    const unapp = A.filter(a => a.approved === false && !a.shadow);
    if (unapp.length) out.push(F({
      title: unapp.length + ' agent' + (unapp.length > 1 ? 's' : '') + ' marked as not approved', severity: unapp.some(a => a.irreversible_tools.length) ? 'high' : 'medium', basis: 'declared',
      claim: 'Not approved: ' + unapp.map(a => a.name).join(', ') + '.',
      evidence: unapp.map(a => ({ t: 'agent', id: a.id })), measure: { count: unapp.length },
      why: 'An unapproved agent is either a policy breach or a gap in the approval record.', fix: 'Approve it properly or stop it.',
      recheck: { kind: 'count', set: 'agents', where: [['approved', '=', false], ['shadow', '!=', true]], expect: unapp.length }
    }));
    return { findings: out, metrics: { total: A.length, shadow: shadow.length, bySource: bySrc.groups.map(g => ({ source: g.key, count: g.count })), activityShare: A.length ? U.pct(A.filter(a => a.run_count > 0).length, A.length) : 0 } };
  });

AF.W('model_finder', 'discover', 'Find which models each agent really uses, and where that differs from what was written down.', ['counter'], [needAgents, needRuns(false, 'Without activity records only declared models are known.')],
  ({ ledger: L }, ctx) => {
    const A = real(L), out = [];
    const runsM = L.runs.filter(r => r.model);
    const g = ctx.call('counter', { items: runsM.map(r => ({ model: r.model, agent: r.agent })), key: 'model' });
    const total = runsM.length;
    const models = g.groups.map(x => ({ model: x.key, runs: x.count, share: U.pct(x.count, total), agents: U.uniq(runsM.filter(r => r.model === x.key).map(r => r.agent)).length })).sort((a, b) => b.runs - a.runs);
    const mm = A.filter(a => a.model_mismatch);
    if (mm.length) out.push(F({
      title: mm.length + ' agent' + (mm.length > 1 ? 's' : '') + ' using a different model from the one declared', severity: 'medium', basis: 'observed',
      claim: mm.map(a => a.name + ' says ' + a.model + ' but runs ' + a.observed_models.join(' / ')).join('; ') + '.',
      evidence: mm.map(a => ({ t: 'agent', id: a.id })), measure: { count: mm.length },
      why: 'The register is wrong about what is running. Approval, pricing and risk tier all depend on the model.', fix: 'Correct the register, then check whether the approval still covers the model actually used.',
      recheck: { kind: 'count', set: 'agents', where: [['model_mismatch', '=', true]], expect: mm.length }
    }));
    const undecl = A.filter(a => !a.model && a.observed_models.length);
    if (undecl.length) out.push(F({
      title: undecl.length + ' agent' + (undecl.length > 1 ? 's' : '') + ' with a model in use but none on record', severity: 'low', basis: 'observed',
      claim: 'No declared model: ' + undecl.slice(0, 8).map(a => a.name).join(', ') + '.', evidence: undecl.slice(0, 10).map(a => ({ t: 'agent', id: a.id })), measure: { count: undecl.length },
      why: 'You cannot govern a model nobody wrote down.', fix: 'Record the model for each agent.',
      recheck: { kind: 'count', set: 'agents', where: [['model', 'empty'], ['stub', '!=', true], ['observed_models', 'nonempty']], expect: undecl.length }
    }));
    return { findings: out, metrics: { models, undeclared: undecl.length, mismatched: mm.length } };
  });

AF.W('spend_usage', 'discover', 'Add up what is being spent: model calls from the activity records and AI subscriptions from expenses.', ['counter'],
  [need('spend', true, L => L.runs.some(r => r.cost != null) || L.expenses.length > 0, 'There is no cost or expense data to total.', 'runs with token counts and a price table, or an expenses CSV')],
  ({ ledger: L }, ctx) => {
    const out = [], metrics = {};
    const pr = L.runs.filter(r => r.cost != null);
    if (pr.length) {
      const g = ctx.call('counter', { items: pr.map(r => ({ agent: r.agent, model: r.model || 'unknown', cost: r.cost, inTok: r.inTok || 0, outTok: r.outTok || 0 })), key: 'agent', sums: ['cost', 'inTok', 'outTok'] });
      const total = U.sum(g.groups.map(x => x.sums.cost));
      const top = g.groups.slice().sort((a, b) => b.sums.cost - a.sums.cost);
      metrics.total_cost = U.round(total, 2); metrics.priced_runs = pr.length; metrics.window_days = U.round(L.window.days, 1);
      metrics.by_agent = top.slice(0, 10).map(x => ({ agent: x.key, cost: U.round(x.sums.cost, 2), runs: x.count, share: U.pct(x.sums.cost, total) }));
      metrics.tokens_in = U.sum(g.groups.map(x => x.sums.inTok)); metrics.tokens_out = U.sum(g.groups.map(x => x.sums.outTok));
      if (top.length >= 3) {
        const t3 = top.slice(0, 3), sh = U.pct(U.sum(t3.map(x => x.sums.cost)), total);
        if (sh >= 60) out.push(F({
          title: 'Three agents account for ' + sh + '% of model spend', severity: 'info', basis: L.pricesStale ? 'inferred' : 'observed',
          claim: t3.map(x => x.key + ' £' + U.round(x.sums.cost, 2)).join(', ') + ' of £' + U.round(total, 2) + ' in the window.',
          evidence: t3.map(x => ({ t: 'agent', id: x.key })), measure: { share: sh },
          why: 'Spend is concentrated, so these are where cost and model choice matter most.', fix: 'Review these first.',
          recheck: { kind: 'sum', set: 'runs', field: 'cost', where: [['agent', 'in', t3.map(x => x.key)]], expect: U.sum(t3.map(x => x.sums.cost)), tol: 1e-6 }
        }));
      }
    }
    if (L.expenses.length) {
      const ai = L.expenses.filter(e => e.vendor);
      metrics.ai_subscription_spend = U.round(U.sum(ai.map(e => e.amount)), 2); metrics.ai_subscription_lines = ai.length;
      const cats = U.groupBy(ai, e => e.category);
      for (const [cat, rows] of cats) {
        const vendors = U.uniq(rows.map(e => e.vendor));
        if (vendors.length >= 2) {
          const holders = U.uniq(rows.map(e => e.holder)).length;
          out.push(F({
            title: vendors.length + ' separate ' + cat + ' tools being paid for', severity: 'medium', basis: 'observed',
            claim: vendors.join(', ') + ' across ' + holders + ' people, £' + U.round(U.sum(rows.map(e => e.amount)), 2) + ' in the expense records.',
            evidence: vendors.map(v => ({ t: 'expense_vendor', id: v })), measure: { vendors: vendors.length, spend: U.round(U.sum(rows.map(e => e.amount)), 2) },
            why: 'Several tools doing the same job means duplicate cost and several places where company data goes.', fix: 'Pick one, move people over, cancel the rest.',
            recheck: { kind: 'distinct', set: 'expenses', field: 'vendor', where: [['category', '=', cat]], expect: vendors.length }
          }));
        }
      }
    }
    return { findings: out, metrics };
  });

AF.W('coverage_gaps', 'discover', 'Show how much of the estate each fact is actually known for, so "cannot tell" is visible instead of hidden.', [], [needAgents],
  ({ ledger: L }) => {
    const A = real(L), out = [], cov = [];
    const fields = [['owner', 'Named owner', 'high'], ['model', 'Model', 'medium'], ['version', 'Version', 'medium'], ['purpose', 'Purpose', 'low'], ['tools', 'Tools', 'medium']];
    for (const [f, label, sev] of fields) {
      const known = A.filter(a => !empty(a[f])).length;
      cov.push({ field: label, known, total: A.length, share: U.pct(known, A.length) });
      if (A.length && known / A.length < L.policy.coverageOk) out.push(F({
        title: label + ' is known for only ' + known + ' of ' + A.length + ' agents', severity: sev, basis: 'observed',
        claim: label + ' is missing for ' + (A.length - known) + ' agents, so any check that depends on it cannot be completed for them.',
        evidence: A.filter(a => empty(a[f])).slice(0, 10).map(a => ({ t: 'agent', id: a.id })), measure: { known, total: A.length },
        why: 'Where a fact is unknown the report has to say "cannot tell". Unknown is not the same as fine.', fix: 'Fill it in, or provide the activity records that show it.',
        recheck: { kind: 'count', set: 'agents', where: [['stub', '!=', true], [f, 'empty']], expect: A.length - known }
      }));
    }
    const noRuns = A.filter(a => a.run_count === 0).length;
    cov.push({ field: 'Activity records', known: A.length - noRuns, total: A.length, share: U.pct(A.length - noRuns, A.length) });
    return { findings: out, metrics: { coverage: cov } };
  });

/* ============================== SECURE ============================== */

AF.W('attack_paths', 'secure', 'Find routes from outside input to an irreversible action, directly or through other agents.', ['chainer'], [needAgents],
  ({ ledger: L }, ctx) => {
    const A = real(L), out = [];
    const ex = A.filter(a => a.inputs === 'public');
    const unappr = id => AF.runsOf(L, id).filter(r => r.irreversible && !r.approvedBy).length;
    const ch = ctx.call('chainer', { edges: L.links, starts: ex.map(a => a.id) });
    for (const e of ex) {
      if (e.irreversible_tools.length) {
        const n = unappr(e.id);
        if (n > 0) out.push(F({
          title: e.name + ' takes public input and acts without approval', severity: 'high', basis: 'observed',
          claim: e.name + ' accepts public input, can use ' + e.irreversible_tools.join(', ') + ', and did so ' + n + ' time' + (n > 1 ? 's' : '') + ' with no approval record.',
          evidence: [{ t: 'agent', id: e.id }], measure: { unapproved: n },
          why: 'Anyone who can send it a message can steer an action nobody checks.', fix: 'Put a human approval in front of the irreversible tools, or remove public input.',
          recheck: { kind: 'count', set: 'runs', where: [['agent', '=', e.id], ['irreversible', '=', true], ['approvedBy', 'empty']], expect: n }
        }));
      }
      for (const t of ch.reach[e.id].nodes) {
        const ta = A.find(a => a.id === t); if (!ta || !ta.irreversible_tools.length) continue;
        const n = unappr(t), path = AF.pathTo(ch.reach, e.id, t);
        out.push(F({
          title: 'Public input reaches ' + ta.name + ' through ' + (path.length - 2 || 'no') + ' other agent' + (path.length - 2 === 1 ? '' : 's'), severity: n > 0 ? 'high' : 'medium', basis: 'observed',
          claim: path.join(' -> ') + '. ' + ta.name + ' can use ' + ta.irreversible_tools.join(', ') + (n > 0 ? ' and has acted ' + n + ' times with no approval record.' : ' (its actions do carry approvals).'),
          evidence: path.map(id => ({ t: 'agent', id })), measure: { hops: path.length - 1, unapproved: n },
          why: 'An instruction can travel along the chain, so the weakest gate decides the outcome.', fix: 'Gate the irreversible step, and cut or constrain the link that carries untrusted content.',
          recheck: { kind: 'path', from: e.id, to: t, expect: true }
        }));
      }
    }
    return { findings: out.slice(0, 20), metrics: { exposed: ex.length, paths: out.length } };
  });

AF.W('injection_paths', 'secure', 'Find agents that read content anyone can write and can also take irreversible actions.', ['chainer'], [needAgents],
  ({ ledger: L }, ctx) => {
    const A = real(L), out = [];
    const rd = A.filter(a => a.untrusted_tools.length);
    const unappr = id => AF.runsOf(L, id).filter(r => r.irreversible && !r.approvedBy).length;
    for (const a of rd.filter(a => a.irreversible_tools.length)) {
      const n = unappr(a.id);
      out.push(F({
        title: a.name + ' reads untrusted content and can act on it', severity: n > 0 ? 'high' : 'medium', basis: 'inferred',
        claim: 'It reads via ' + a.untrusted_tools.join(', ') + ' and can use ' + a.irreversible_tools.join(', ') + (n > 0 ? '; ' + n + ' such actions have no approval record.' : '; actions are approved.'),
        evidence: [{ t: 'agent', id: a.id }], measure: { unapproved: n },
        why: 'Text inside an email, ticket or web page can contain instructions. If the same agent can act, the text can steer it.', fix: 'Separate reading from acting, or require approval on the action.',
        recheck: { kind: 'count', set: 'agents', where: [['id', '=', a.id], ['untrusted_tools', 'nonempty'], ['irreversible_tools', 'nonempty']], expect: 1 }
      }));
    }
    const ch = ctx.call('chainer', { edges: L.links, starts: rd.map(a => a.id) });
    for (const r of rd) for (const t of ch.reach[r.id].nodes) {
      const ta = A.find(a => a.id === t); if (!ta || !ta.irreversible_tools.length || r.irreversible_tools.length) continue;
      const path = AF.pathTo(ch.reach, r.id, t);
      out.push(F({
        title: r.name + ' reads untrusted content and passes work to ' + ta.name, severity: 'medium', basis: 'inferred',
        claim: path.join(' -> ') + '; ' + ta.name + ' can use ' + ta.irreversible_tools.join(', ') + '.', evidence: path.map(id => ({ t: 'agent', id })), measure: { hops: path.length - 1 },
        why: 'Content-borne instructions can ride along the handover.', fix: 'Treat everything passed down the chain as untrusted, and gate the action.',
        recheck: { kind: 'path', from: r.id, to: t, expect: true }
      }));
    }
    return { findings: out.slice(0, 20), metrics: { readers_of_untrusted: rd.length } };
  });

AF.W('access_keys', 'secure', 'Check credentials and permissions: shared keys, keys with no owner, unused access, forgotten agents holding live keys.', [], [needAgents],
  ({ ledger: L }) => {
    const A = real(L), out = [];
    const cred = new Map();
    for (const a of A) for (const c of a.credentials || []) { if (!cred.has(c)) cred.set(c, []); cred.get(c).push(a); }
    for (const [c, ags] of cred) if (ags.length >= 2) {
      const broad = /admin|root|owner|prod|full/i.test(c);
      out.push(F({
        title: 'Credential "' + c + '" is shared by ' + ags.length + ' agents', severity: ags.length >= 3 || broad ? 'high' : 'medium', basis: 'declared',
        claim: ags.map(a => a.name).join(', ') + ' all use it' + (broad ? ' (the name suggests broad access)' : '') + '.',
        evidence: ags.map(a => ({ t: 'agent', id: a.id })), measure: { agents: ags.length },
        why: 'If one agent is tricked or leaks the key, every agent using it is exposed, and logs cannot tell them apart.', fix: 'Give each agent its own credential with only the access it needs.',
        recheck: { kind: 'count', set: 'agents', where: [['credentials', 'includes', c]], expect: ags.length }
      }));
    }
    const unowned = A.filter(a => !empty(a.credentials) && empty(a.owner));
    if (unowned.length) out.push(F({
      title: unowned.length + ' agent' + (unowned.length > 1 ? 's' : '') + ' hold credentials with no owner', severity: 'high', basis: 'declared',
      claim: unowned.map(a => a.name).join(', ') + '.', evidence: unowned.map(a => ({ t: 'agent', id: a.id })), measure: { count: unowned.length },
      why: 'Nobody is accountable for the access, so nobody will rotate or remove it.', fix: 'Name an owner for each credential.',
      recheck: { kind: 'count', set: 'agents', where: [['stub', '!=', true], ['credentials', 'nonempty'], ['owner', 'empty']], expect: unowned.length }
    }));
    const zom = A.filter(a => a.zombie && !empty(a.credentials));
    if (zom.length) out.push(F({
      title: zom.length + ' idle agent' + (zom.length > 1 ? 's' : '') + ' still holding live credentials', severity: 'high', basis: 'observed',
      claim: zom.map(a => a.name + (a.idle_days != null ? ' (idle ' + a.idle_days + ' days)' : ' (no activity recorded)')).join(', ') + '.',
      evidence: zom.map(a => ({ t: 'agent', id: a.id })), measure: { count: zom.length },
      why: 'A forgotten agent with access is an open door nobody watches.', fix: 'Revoke the credentials now, then decide whether the agent should exist.',
      recheck: { kind: 'count', set: 'agents', where: [['zombie', '=', true], ['credentials', 'nonempty']], expect: zom.length }
    }));
    const metrics = { credentials: cred.size };
    if (hasRuns(L)) {
      if (L.window.days >= L.policy.unusedToolDays) {
        let declared = 0, unused = 0;
        for (const a of A) { if (!a.run_count) continue; for (const t of a.tools) { declared++; if (!a.tools_used.includes(t)) unused++; } }
        metrics.unused_tools = unused; metrics.declared_tools = declared;
        if (declared >= 5 && unused / declared >= 0.3) out.push(F({
          title: U.pct(unused, declared) + '% of declared tool access was never used in the window', severity: 'medium', basis: 'observed',
          claim: unused + ' of ' + declared + ' declared tools were not used by their agents in ' + Math.round(L.window.days) + ' days of activity.',
          evidence: [], measure: { unused, declared },
          why: 'Access that is never used is risk with no benefit.', fix: 'Remove access that has not been used, and add it back only when needed.',
          recheck: { kind: 'unused_share', expect: unused / declared }
        }));
      } else metrics.unused_tools_note = 'Activity window is shorter than ' + L.policy.unusedToolDays + ' days, so unused access cannot be judged.';
    }
    const ext = L.extensions.filter(e => /all websites/i.test(e.permissions || '') && /gpt|\bai\b|assistant|copilot|notetak|summar/i.test(e.extension || ''));
    if (ext.length) out.push(F({
      title: ext.length + ' AI browser extension' + (ext.length > 1 ? 's' : '') + ' can read every website', severity: 'medium', basis: 'observed',
      claim: ext.map(e => e.extension + ' (' + e.users + ' users)').join('; ') + '.', evidence: ext.map(e => ({ t: 'extension', id: e.extension })), measure: { count: ext.length },
      why: 'They can see anything on screen, including customer and internal systems.', fix: 'Block or approve each one explicitly.',
      recheck: { kind: 'count', set: 'extensions', where: [['permissions', 'contains', 'all websites']], expect: L.extensions.filter(e => /all websites/i.test(e.permissions || '')).length, note: 'counts all-websites extensions before the AI-name filter' }
    }));
    return { findings: out, metrics };
  });

AF.W('trace_integrity', 'secure', 'Test whether anyone could reconstruct what an agent did and which version did it.', ['counter'], [needRuns(true, 'There are no activity records to test.')],
  ({ ledger: L }) => {
    const R = L.runs, out = [];
    const share = f => U.pct(R.filter(f).length, R.length);
    const withModel = R.filter(r => r.inTok != null || r.model);
    const m = { runs: R.length, with_trace: share(r => !!r.trace), with_version: share(r => !!r.version), with_model: U.pct(withModel.filter(r => r.model).length, withModel.length || 1) };
    const irr = R.filter(r => r.irreversible);
    m.irreversible_runs = irr.length;
    m.irreversible_reconstructable = irr.length ? U.pct(irr.filter(r => r.trace && r.version).length, irr.length) : null;
    const missV = R.filter(r => !r.version).length, missT = R.filter(r => !r.trace).length;
    if (R.length && missV / R.length > 0.05) out.push(F({
      title: missV + ' of ' + R.length + ' recorded runs do not say which version ran', severity: irr.length && irr.some(r => !r.version) ? 'high' : 'medium', basis: 'observed',
      claim: U.pct(missV, R.length) + '% of runs have no version.', evidence: [], measure: { missing: missV, total: R.length },
      why: 'If something goes wrong you cannot say which version of the agent did it.', fix: 'Log the agent version on every run.',
      recheck: { kind: 'ratio', num: { set: 'runs', where: [['version', 'empty']] }, den: { set: 'runs', where: [] }, expect: missV / R.length, tol: 1e-9 }
    }));
    if (R.length && missT / R.length > 0.05) out.push(F({
      title: missT + ' of ' + R.length + ' recorded runs carry no trace id', severity: 'medium', basis: 'observed',
      claim: U.pct(missT, R.length) + '% of runs cannot be tied to a chain of steps.', evidence: [], measure: { missing: missT, total: R.length },
      why: 'Without a trace id a multi-step action cannot be followed from start to finish.', fix: 'Pass one trace id through every step.',
      recheck: { kind: 'ratio', num: { set: 'runs', where: [['trace', 'empty']] }, den: { set: 'runs', where: [] }, expect: missT / R.length, tol: 1e-9 }
    }));
    const irrNoV = irr.filter(r => !r.version).length;
    m.irreversible_without_version = irrNoV;
    if (irrNoV > 0) out.push(F({
      title: irrNoV + ' of ' + irr.length + ' irreversible actions cannot be tied to an agent version', severity: 'high', basis: irr.some(r => r.irrBasis === 'inferred') ? 'inferred' : 'observed',
      claim: 'These actions were taken, are recorded, and nobody could say which version of the agent took them.', evidence: U.uniq(irr.filter(r => !r.version).map(r => r.agent)).slice(0, 8).map(id => ({ t: 'agent', id })), measure: { missing: irrNoV, total: irr.length },
      why: 'For the actions that matter most, a later investigation would hit a dead end.', fix: 'Make version and trace id mandatory on any run that can change something.',
      recheck: { kind: 'count', set: 'runs', where: [['irreversible', '=', true], ['version', 'empty']], expect: irrNoV }
    }));
    const spans = R.filter(r => r.span).map(r => r.trace + '/' + r.span), dup = spans.length - U.uniq(spans).length;
    m.duplicate_spans = dup;
    if (dup > 0) out.push(F({
      title: dup + ' duplicate span ids in the activity records', severity: 'low', basis: 'observed', claim: 'The same span appears more than once, so records may be double-counted or replayed.', evidence: [], measure: { duplicates: dup },
      why: 'Duplicates inflate counts and can hide tampering.', fix: 'Check the export or collector for repeats.', recheck: { kind: 'distinct_gap', set: 'runs', expect: dup }
    }));
    return { findings: out, metrics: m };
  });

AF.W('blast_radius', 'secure', 'For each agent, how far could a failure travel: other agents, systems, irreversible actions.', ['chainer'], [needAgents],
  ({ ledger: L }, ctx) => {
    const A = real(L), out = [];
    const ch = ctx.call('chainer', { edges: L.links, starts: A.map(a => a.id) });
    const rows = A.map(a => {
      const reachIds = ch.reach[a.id].nodes, nodes = reachIds.map(id => A.find(x => x.id === id)).filter(Boolean);
      const irr = U.uniq(nodes.flatMap(n => n.irreversible_tools).concat(a.irreversible_tools));
      const sys = U.uniq(nodes.flatMap(n => n.data || []).concat(a.data || []));
      return { id: a.id, name: a.name, reach: reachIds.length, irreversible: irr.length, systems: sys.length, score: reachIds.length + irr.length * 2 + sys.length };
    }).sort((x, y) => y.score - x.score);
    for (const r of rows.slice(0, 3)) if (r.reach >= 3 || r.irreversible >= 3) out.push(F({
      title: r.name + ' can affect ' + r.reach + ' other agents and ' + r.irreversible + ' kinds of irreversible action', severity: r.reach >= 5 ? 'high' : 'medium', basis: 'inferred',
      claim: 'Following links from ' + r.name + ' reaches ' + r.reach + ' agents, ' + r.irreversible + ' irreversible tools and ' + r.systems + ' named data systems.',
      evidence: [{ t: 'agent', id: r.id }], measure: r,
      why: 'If this agent is wrong or compromised, this is how much can go with it.', fix: 'Cut links it does not need, and put a gate where the chain reaches an irreversible tool.',
      recheck: { kind: 'reach_count', from: r.id, expect: r.reach }
    }));
    return { findings: out, metrics: { top: rows.slice(0, 8) } };
  });

})(AF);

/* ---- workers_b.js ---- */
(function(AF){
/* Workers, part B: Govern and Economics, plus the module leads. */
'use strict';
const U = AF.U, F = AF.F, empty = AF.empty;
const real = L => L.agents.filter(a => !a.stub);
const hasRuns = L => L.runs.length > 0;
const need = (key, critical, test, why, hint) => ({ key, critical, test, why, hint });
const needAgents = need('agents', true, L => real(L).length > 0, 'There is no list of agents to assess.', 'estate.json (agents[]), or an agent inventory CSV, or n8n / MCP config files');
const needRuns = (critical, why) => need('runs', critical, L => hasRuns(L), why || 'Activity records are needed to see what agents actually did.', 'runs.jsonl, OpenTelemetry spans (JSON) or tool-call trace logs');
const needPrices = need('prices', true, L => !!(L.prices && L.prices.models && Object.keys(L.prices.models).length), 'Cost needs a dated price table. The tool will not guess prices.', 'prices.json: { as_of, source, currency, models: { name: { in, out, tier } } } (per million tokens)');
const needProfile = need('profile', false, L => !!(L.org && L.org.size && L.org.sector), 'Organisation size and sector let the tool judge whether the agent structure fits.', 'Fill in the profile box, or put org.size and org.sector in estate.json');
const money = x => '£' + U.round(x, 2).toLocaleString('en-GB');

/* ============================== GOVERN ============================== */

const BANDS = [
  { id: 'micro', label: 'up to 10 people', max: 10, depth: 2, orch: 1 },
  { id: 'small', label: '11 to 250 people', max: 250, depth: 3, orch: 4 },
  { id: 'mid', label: '251 to 5,000 people', max: 5000, depth: 3, orch: 12 },
  { id: 'large', label: 'over 5,000 people', max: 1e12, depth: 3, orch: 40 }
];
AF.BANDS = BANDS;
const DOMAIN_NOTE = {
  legal: 'Legal work: keep a human sign-off before any client-facing output, and keep matters separate so one client\'s material cannot reach another.',
  financial: 'Financial work: keep a human sign-off before any payment or customer-affecting decision, and a named owner per model.',
  healthcare: 'Healthcare work: keep clinical decisions with a person, and keep full records of what the agent saw and said.',
  public: 'Public sector: keep records of every automated decision and a route for people to challenge them.',
  general: 'General work: a small number of orchestrators with a clear owner each, and approval in front of anything irreversible.'
};

AF.W('pyramid_review', 'govern', 'Check the shape of the agent hierarchy against the size and sector of the organisation. This is Antara guidance, a heuristic, not a standard.', ['chainer', 'counter'], [needAgents, needProfile],
  ({ ledger: L }, ctx) => {
    const A = real(L), out = [], P = L.policy;
    const orch = A.filter(a => a.tier === 'orchestrator');
    const tiers = ctx.call('counter', { items: A.map(a => ({ t: a.tier })), key: 't' }).groups.map(g => ({ tier: g.key, count: g.count }));
    const starts = (orch.length ? orch : A.filter(a => L.links.some(l => l.from === a.id) && !L.links.some(l => l.to === a.id))).map(a => a.id);
    const ch = ctx.call('chainer', { edges: L.links, starts });
    let maxD = 0, deepRoot = null;
    for (const s of starts) for (const d of Object.values(ch.reach[s].depth)) if (d > maxD) { maxD = d; deepRoot = s; }
    const metrics = { tiers, orchestrators: orch.length, max_depth: maxD, deepest_root: deepRoot };
    const band = L.org && L.org.size ? BANDS.find(b => Number(L.org.size) <= b.max) : null;
    if (band) { metrics.band = band.id; metrics.band_label = band.label; metrics.guidance = { max_depth: band.depth, max_orchestrators: band.orch, note: DOMAIN_NOTE[L.org.sector] || DOMAIN_NOTE.general }; }
    if (maxD > P.maxDepth) {
      const deepest = Object.keys(ch.reach[deepRoot].depth).filter(k => ch.reach[deepRoot].depth[k] === maxD)[0];
      out.push(F({
        title: 'Agents hand work down ' + maxD + ' levels, past your limit of ' + P.maxDepth, severity: 'medium', basis: 'observed',
        claim: 'From ' + deepRoot + ' the chain runs ' + AF.pathTo(ch.reach, deepRoot, deepest).join(' -> ') + '.', evidence: AF.pathTo(ch.reach, deepRoot, deepest).map(id => ({ t: 'agent', id })), measure: { depth: maxD, limit: P.maxDepth },
        why: 'Each extra level adds delay, cost and a place where intent can drift, and fewer people can explain what happened.', fix: 'Flatten the chain, or raise the limit on purpose and record why.',
        recheck: { kind: 'depth_from', from: deepRoot, expect: maxD }
      }));
    }
    for (const o of orch) {
      const n = L.links.filter(l => l.from === o.id).length;
      if (n > P.maxFanout) out.push(F({
        title: o.name + ' directly manages ' + n + ' agents, past your limit of ' + P.maxFanout, severity: 'medium', basis: 'observed',
        claim: n + ' outgoing links.', evidence: [{ t: 'agent', id: o.id }], measure: { fanout: n, limit: P.maxFanout },
        why: 'Past a handful of reports an orchestrator cannot be checked properly by the person who owns it.', fix: 'Split by function and add a layer, or retire agents it does not need.',
        recheck: { kind: 'count', set: 'links', where: [['from', '=', o.id]], expect: n }
      }));
      else if (n === 0 && A.length > 3) out.push(F({
        title: o.name + ' is an orchestrator with nothing to orchestrate', severity: 'low', basis: 'observed', claim: 'No outgoing links.', evidence: [{ t: 'agent', id: o.id }], measure: {},
        why: 'A layer that does nothing still costs money and review time.', fix: 'Remove it or attach the agents it was meant to run.',
        recheck: { kind: 'count', set: 'links', where: [['from', '=', o.id]], expect: 0 }
      }));
    }
    const orphans = A.filter(a => (a.tier === 'worker' || a.tier === 'task') && empty(a.parent) && !a.external);
    if (orphans.length) out.push(F({
      title: orphans.length + ' worker' + (orphans.length > 1 ? 's' : '') + ' with no orchestrator above them', severity: 'medium', basis: 'declared',
      claim: orphans.map(a => a.name).join(', ') + '.', evidence: orphans.map(a => ({ t: 'agent', id: a.id })), measure: { count: orphans.length },
      why: 'Nothing supervises them, and nobody sees their work in the context of a larger process.', fix: 'Place each under an orchestrator that someone owns, or document why it stands alone.',
      recheck: { kind: 'count', set: 'agents', where: [['tier', 'in', ['worker', 'task']], ['parent', 'empty'], ['external', '!=', true], ['stub', '!=', true]], expect: orphans.length }
    }));
    if (band) {
      if (orch.length > band.orch || (maxD > band.depth && maxD <= P.maxDepth)) out.push(F({
        title: 'More structure than an organisation of ' + band.label + ' usually needs', severity: 'low', basis: 'inferred',
        claim: orch.length + ' orchestrators and depth ' + maxD + '. Antara guidance for this size is up to ' + band.orch + ' orchestrators and depth ' + band.depth + '.',
        evidence: [], measure: { orchestrators: orch.length, depth: maxD, band: band.id },
        why: 'Small organisations pay for layers they cannot staff to review. This is a rule of thumb, so treat it as a prompt to ask why, not a verdict.', fix: 'Check each layer has a named owner and a reason to exist.',
        recheck: { kind: 'count', set: 'agents', where: [['tier', '=', 'orchestrator']], expect: orch.length }
      }));
      if ((band.id === 'mid' || band.id === 'large') && A.length >= 30 && orch.length === 0) out.push(F({
        title: A.length + ' agents with no orchestrator layer for an organisation of ' + band.label, severity: 'medium', basis: 'inferred',
        claim: 'A flat estate of this size usually has no one place to apply rules, budgets or review. Antara guidance, a heuristic.', evidence: [], measure: { agents: A.length },
        why: 'Without a layer above the workers, every rule has to be applied agent by agent.', fix: 'Group by function and give each group an orchestrator with an owner.',
        recheck: { kind: 'count', set: 'agents', where: [['tier', '=', 'orchestrator']], expect: 0 }
      }));
    }
    return { findings: out, metrics };
  });

const selMatch = (sel, a) => {
  if (!sel || sel === '*') return true;
  const [k, v] = String(sel).split(':');
  if (k === 'tier') return a.tier === v;
  if (k === 'agent') return a.id === U.slug(v);
  if (k === 'dept') return U.slug(a.dept) === U.slug(v);
  if (k === 'external') return !!a.external;
  return false;
};

AF.W('link_rules', 'govern', 'Check agent-to-agent communication against your link rules, and list links that nobody declared or that leave the organisation.', ['chainer'], [need('links', true, L => L.links.length > 0, 'No agent-to-agent links are known.', 'estate.json links[] or parent fields, or activity records with parent agent / parent span'), need('rules', false, L => !empty(L.policy.linkRules), 'Without link rules the tool can only list links, not judge them.', 'policy.json: link_rules: [{ from: "tier:worker", to: "tier:orchestrator", allow: false }]')],
  ({ ledger: L }, ctx) => {
    const A = new Map(L.agents.map(a => [a.id, a])), out = [];
    const undecl = L.links.filter(l => l.basis === 'observed');
    if (undecl.length) out.push(F({
      title: undecl.length + ' agent-to-agent link' + (undecl.length > 1 ? 's' : '') + ' seen in use but never declared', severity: 'medium', basis: 'observed',
      claim: undecl.slice(0, 6).map(l => l.from + ' -> ' + l.to + (l.calls ? ' (' + l.calls + ' calls)' : '')).join('; ') + (undecl.length > 6 ? '; and more' : '') + '.',
      evidence: undecl.slice(0, 10).map(l => ({ t: 'link', id: l.from + '>' + l.to })), measure: { count: undecl.length },
      why: 'Communication nobody approved is communication nobody is checking.', fix: 'Decide for each: declare and own it, or block it.',
      recheck: { kind: 'count', set: 'links', where: [['basis', '=', 'observed']], expect: undecl.length }
    }));
    const rules = L.policy.linkRules || [];
    const denied = [];
    for (const l of L.links) {
      const f = A.get(l.from), t = A.get(l.to); if (!f || !t) continue;
      for (const r of rules) if (selMatch(r.from, f) && selMatch(r.to, t)) { if (r.allow === false) denied.push({ l, r }); break; }
    }
    if (denied.length) out.push(F({
      title: denied.length + ' link' + (denied.length > 1 ? 's' : '') + ' that your own rules forbid', severity: denied.some(d => d.l.basis !== 'declared') ? 'high' : 'medium', basis: 'observed',
      claim: denied.slice(0, 6).map(d => d.l.from + ' -> ' + d.l.to + ' (rule: ' + d.r.from + ' to ' + d.r.to + ' not allowed' + (d.l.calls ? ', ' + d.l.calls + ' calls seen' : '') + ')').join('; ') + '.',
      evidence: denied.slice(0, 10).map(d => ({ t: 'link', id: d.l.from + '>' + d.l.to })), measure: { count: denied.length },
      why: 'The rule exists, the traffic exists, and the two disagree.', fix: 'Stop the traffic or change the rule on purpose.',
      recheck: { kind: 'links_denied', rules, expect: denied.length }
    }));
    const ext = L.links.filter(l => l.external);
    if (ext.length) out.push(F({
      title: ext.length + ' link' + (ext.length > 1 ? 's' : '') + ' to agents outside the organisation', severity: 'medium', basis: 'declared',
      claim: ext.map(l => l.from + ' -> ' + l.to + (l.calls ? ' (' + l.calls + ' calls)' : '')).join('; ') + '.', evidence: ext.map(l => ({ t: 'link', id: l.from + '>' + l.to })), measure: { count: ext.length },
      why: 'Work and data cross a boundary you do not govern. Who is accountable if the other side is wrong?', fix: 'Keep a register of outside links with an owner, a contract reference and what data may cross.',
      recheck: { kind: 'count', set: 'links', where: [['external', '=', true]], expect: ext.length }
    }));
    const ids = U.uniq(L.links.map(l => l.from));
    const ch = ctx.call('chainer', { edges: L.links, starts: ids });
    for (const c of ch.cyclic.slice(0, 3)) out.push(F({
      title: c + ' can end up calling itself through other agents', severity: 'medium', basis: 'inferred', claim: 'A loop exists in the links through ' + c + '.', evidence: [{ t: 'agent', id: c }], measure: {},
      why: 'Loops are how costs and errors run away.', fix: 'Break the loop or add a hard limit on repeats.', recheck: { kind: 'cycle', from: c }
    }));
    return { findings: out, metrics: { links: L.links.length, declared: L.links.filter(l => l.basis !== 'observed').length, observed_only: undecl.length, external: ext.length, rules: rules.length } };
  });

AF.W('model_register', 'govern', 'Check models in use against the approved list per risk tier, models about to be retired, and dependence on a single model.', ['counter'], [needAgents, need('approved', false, L => !!L.policy.approvedModels, 'Without an approved-model list per risk tier the tool cannot say which models are allowed.', 'policy.json: approved_models: { low: [...], medium: [...], high: [...] } and risk on each agent'), need('retire', false, L => !!(L.prices && L.prices.retire), 'Retirement dates let the tool warn before a model disappears.', 'prices.json: retire: { "model-name": "2027-02-01" }')],
  ({ ledger: L }, ctx) => {
    const A = real(L), out = [], P = L.policy;
    const am = P.approvedModels;
    if (am) for (const a of A) {
      const tier = a.risk || 'medium', ok = am[tier]; if (!ok || !a.run_count) continue;
      const bad = a.observed_models.filter(m => !ok.includes(m)); if (!bad.length) continue;
      const n = AF.runsOf(L, a.id).filter(r => r.model && !ok.includes(r.model)).length;
      out.push(F({
        title: a.name + ' runs on a model not approved for ' + tier + ' risk', severity: tier === 'high' ? 'high' : 'medium', basis: 'observed',
        claim: bad.join(', ') + ' in ' + n + ' runs. Approved for ' + tier + ': ' + ok.join(', ') + '.', evidence: [{ t: 'agent', id: a.id }], measure: { runs: n, risk: tier },
        why: 'The approval list is the control. Runs outside it are outside governance.', fix: 'Move the agent to an approved model or approve the model on the record.',
        recheck: { kind: 'count', set: 'runs', where: [['agent', '=', a.id], ['model', 'nonempty'], ['model', 'notin', ok]], expect: n }
      }));
    }
    if (L.prices && L.prices.retire && L.asOf != null) for (const [m, d] of Object.entries(L.prices.retire)) {
      const days = Math.floor((U.ms(d) - L.asOf) / 86400000); if (!isFinite(days) || days > P.retireWarnDays) continue;
      const users = A.filter(a => a.observed_models.includes(m) || a.model === m);
      if (!users.length) continue;
      out.push(F({
        title: m + ' is ' + (days < 0 ? 'already retired' : 'retired in ' + days + ' days') + ' and ' + users.length + ' agent' + (users.length > 1 ? 's' : '') + ' depend on it', severity: days <= 90 ? 'high' : 'medium', basis: 'declared',
        claim: users.map(a => a.name).join(', ') + '. Retirement date from your price table: ' + d + '.', evidence: users.map(a => ({ t: 'agent', id: a.id })), measure: { days, agents: users.length },
        why: 'When a model goes, the agent stops or silently moves to another one, and nobody has tested the result.', fix: 'Choose and test a replacement now, then record the change.',
        recheck: [{ kind: 'count', set: 'agents', where: [['observed_models', 'includes', m]], expect: A.filter(a => a.observed_models.includes(m)).length }]
      }));
    }
    const rm = L.runs.filter(r => r.model);
    if (rm.length) {
      const g = ctx.call('counter', { items: rm.map(r => ({ m: r.model })), key: 'm' }).groups.sort((x, y) => y.count - x.count)[0];
      const share = g.count / rm.length;
      if (share >= P.monoShare && U.uniq(rm.map(r => r.model)).length >= 1) out.push(F({
        title: U.pct(g.count, rm.length) + '% of runs depend on a single model', severity: 'medium', basis: 'observed',
        claim: g.key + ' handles ' + g.count + ' of ' + rm.length + ' runs. A fault, price change or outage there hits nearly everything at once.', evidence: [{ t: 'model', id: g.key }], measure: { share: U.pct(g.count, rm.length) },
        why: 'If the agent and the thing checking it share a model, they can share the same blind spot.', fix: 'Use a different model family for review and verification steps, and keep a tested fallback.',
        recheck: { kind: 'ratio', num: { set: 'runs', where: [['model', '=', g.key]] }, den: { set: 'runs', where: [['model', 'nonempty']] }, expect: share, tol: 1e-9 }
      }));
    }
    return { findings: out, metrics: { approved_list: !!am, retire_dates: !!(L.prices && L.prices.retire) } };
  });

const SECTOR_RULES = {
  inventory: { text: 'Every agent has a recorded model', ref: 'Model inventory expectations, e.g. SR 11-7 style model risk guidance', fail: a => !a.stub && empty(a.model), where: [['stub', '!=', true], ['model', 'empty']], sev: 'medium', field: 'model' },
  validation: { text: 'Every agent has a recorded validation date', ref: 'Model validation expectations in financial and health settings', fail: a => !a.stub && empty(a.validated_at), where: [['stub', '!=', true], ['validated_at', 'empty']], sev: 'high', field: 'validated_at' },
  accountability: { text: 'Every agent has a named owner', ref: 'Accountability / deployer duties', fail: a => empty(a.owner), where: [['stub', '!=', true], ['owner', 'empty']], sev: 'medium', field: 'owner' },
  change: { text: 'Every agent runs the version that was approved', ref: 'Change control', fail: a => !a.stub && a.version_drift, where: [['version_drift', '=', true]], sev: 'high', field: 'version_drift' },
  monitoring: { text: 'Every active agent has recent activity records', ref: 'Ongoing monitoring', fail: a => a.status === 'active' && !a.stub && a.run_count === 0, where: [['status', '=', 'active'], ['stub', '!=', true], ['run_count', '=', 0]], sev: 'medium', field: 'run_count' }
};
const SECTOR_SETS = {
  financial: ['inventory', 'validation', 'monitoring', 'change', 'accountability'],
  healthcare: ['inventory', 'validation', 'monitoring', 'accountability'],
  legal: ['inventory', 'accountability', 'change'],
  public: ['inventory', 'accountability', 'monitoring'],
  general: ['inventory', 'accountability']
};
AF.W('sector_rules', 'govern', 'Check agents against a short, plain list of what regulators in the chosen sector tend to ask for. Antara\'s reading, not legal advice.', [], [needAgents, need('sector', true, L => !!(L.org && L.org.sector), 'Choose a sector so the right checks apply.', 'Profile box: sector')],
  ({ ledger: L }) => {
    const A = real(L), out = [], sector = SECTOR_SETS[L.org.sector] ? L.org.sector : 'general';
    const res = [];
    for (const id of SECTOR_SETS[sector]) {
      const r = SECTOR_RULES[id], failing = A.filter(r.fail), ok = A.length - failing.length;
      res.push({ rule: r.text, ok, total: A.length, ref: r.ref });
      if (failing.length) out.push(F({
        title: '"' + r.text + '" fails for ' + failing.length + ' of ' + A.length + ' agents', severity: r.sev, basis: 'observed',
        claim: failing.slice(0, 8).map(a => a.name).join(', ') + (failing.length > 8 ? ', and more' : '') + '. Reference point: ' + r.ref + '.', evidence: failing.slice(0, 10).map(a => ({ t: 'agent', id: a.id })), measure: { failing: failing.length, total: A.length },
        why: 'This is the kind of evidence a reviewer in this sector tends to ask for first.', fix: 'Record it for each agent. Check with your own legal or compliance adviser which rules apply to you and from when.',
        recheck: { kind: 'count', set: 'agents', where: r.where, expect: failing.length }
      }));
    }
    return { findings: out, metrics: { sector, rules: res, caveat: 'Antara reading of common expectations. Not legal advice. Dates for EU AI Act high-risk duties were moved by a provisional omnibus agreement; confirm formal adoption and your own classification.' } };
  });

AF.W('policy_drift', 'govern', 'Compare what was approved with what is running.', [], [needAgents, need('approved_versions', false, L => real(L).some(a => a.approved_version), 'Approved versions are needed to see drift.', 'estate.json: approved_version on each agent'), needRuns(false)],
  ({ ledger: L }) => {
    const A = real(L), out = [];
    const drift = A.filter(a => a.version_drift);
    for (const a of drift) {
      const n = AF.runsOf(L, a.id).filter(r => r.version && r.version !== a.approved_version).length;
      out.push(F({
        title: a.name + ' runs ' + a.versions_seen.filter(v => v !== a.approved_version).join(', ') + ' but ' + a.approved_version + ' was approved', severity: a.irreversible_tools.length ? 'high' : 'medium', basis: 'observed',
        claim: n + ' runs on a version that has no approval on record' + (a.irreversible_tools.length ? ', and the agent can ' + a.irreversible_tools.join(', ') : '') + '.', evidence: [{ t: 'agent', id: a.id }], measure: { runs: n },
        why: 'The approval covered one thing and something else is doing the work.', fix: 'Re-approve the running version or roll back.',
        recheck: { kind: 'count', set: 'runs', where: [['agent', '=', a.id], ['version', 'nonempty'], ['version', '!=', a.approved_version]], expect: n }
      }));
    }
    const ra = A.filter(a => a.approved === false && a.run_count > 0);
    if (ra.length) out.push(F({
      title: ra.length + ' agent' + (ra.length > 1 ? 's' : '') + ' running while marked not approved', severity: 'high', basis: 'observed',
      claim: ra.map(a => a.name).join(', ') + '.', evidence: ra.map(a => ({ t: 'agent', id: a.id })), measure: { count: ra.length },
      why: 'The register says no, the activity says yes.', fix: 'Approve with conditions or stop.',
      recheck: { kind: 'count', set: 'agents', where: [['approved', '=', false], ['run_count', '>', 0]], expect: ra.length }
    }));
    return { findings: out, metrics: { with_approved_version: A.filter(a => a.approved_version).length, drifted: drift.length } };
  });

AF.W('owner_chain', 'govern', 'Check every agent has a person accountable, that the person is still here, and that cost has an owner.', [], [needAgents, need('people', false, L => L.peopleKnown, 'Without a list of current staff the tool cannot tell if an owner has left.', 'people.json or people.csv with name and left date'), need('budget', false, L => !!L.policy.budgetOwners, 'Budget owners per department let the tool find spend nobody owns.', 'policy.json: budget_owners: { Claims: "name", ... }')],
  ({ ledger: L }) => {
    const A = real(L), out = [], P = L.policy;
    const none = A.filter(a => empty(a.owner));
    if (none.length) out.push(F({
      title: none.length + ' agent' + (none.length > 1 ? 's' : '') + ' with no named owner', severity: 'high', basis: 'declared',
      claim: none.slice(0, 10).map(a => a.name).join(', ') + (none.length > 10 ? ', and more' : '') + '.', evidence: none.slice(0, 10).map(a => ({ t: 'agent', id: a.id })), measure: { count: none.length },
      why: 'When something goes wrong, nobody is on the hook, so nobody fixes it.', fix: 'Name one person per agent. A team is not an owner.',
      recheck: { kind: 'count', set: 'agents', where: [['stub', '!=', true], ['owner', 'empty']], expect: none.length }
    }));
    const left = A.filter(a => a.owner_left);
    if (left.length) out.push(F({
      title: left.length + ' agent' + (left.length > 1 ? 's' : '') + ' owned by someone who has left', severity: 'high', basis: 'observed',
      claim: left.map(a => a.name + ' (' + a.owner + ')').join(', ') + '.', evidence: left.map(a => ({ t: 'agent', id: a.id })), measure: { count: left.length },
      why: 'Ownership decays when people move on. The agent keeps running with an owner who cannot act.', fix: 'Reassign today, and add a check to the leaver process.',
      recheck: { kind: 'count', set: 'agents', where: [['owner_left', '=', true]], expect: left.length }
    }));
    const zom = A.filter(a => a.zombie);
    if (zom.length) out.push(F({
      title: zom.length + ' agent' + (zom.length > 1 ? 's' : '') + ' marked active with no recent activity', severity: 'medium', basis: 'observed',
      claim: zom.map(a => a.name + (a.idle_days != null ? ' (' + a.idle_days + ' days)' : ' (never seen)')).join(', ') + '.', evidence: zom.map(a => ({ t: 'agent', id: a.id })), measure: { count: zom.length },
      why: 'Forgotten agents keep their access and their cost.', fix: 'Retire them or write down why they stay.',
      recheck: { kind: 'count', set: 'agents', where: [['zombie', '=', true]], expect: zom.length }
    }));
    if (P.budgetOwners) {
      const depts = U.uniq(A.map(a => a.dept).filter(Boolean)).filter(d => !P.budgetOwners[d]);
      if (depts.length) out.push(F({
        title: 'No budget owner for ' + depts.join(', '), severity: 'medium', basis: 'declared',
        claim: 'Agents exist in these departments but your budget owner list does not cover them.', evidence: [], measure: { departments: depts },
        why: 'Spend with no owner has no one to question it.', fix: 'Add a budget owner for each department.',
        recheck: { kind: 'count', set: 'agents', where: [['stub', '!=', true], ['dept', 'in', depts]], expect: A.filter(a => depts.includes(a.dept)).length }
      }));
    }
    return { findings: out, metrics: { no_owner: none.length, owner_left: left.length, zombie: zom.length, total: A.length } };
  });

AF.scoreDrill = (key, resp) => {
  const planted = new Map(key.items.map(i => [String(i.id), !!i.planted]));
  const by = new Map();
  let ps = 0, caught = 0, cs = 0, fa = 0;
  for (const r of resp) {
    const id = String(r.item_id), d = String(r.decision || '').toLowerCase();
    if (!planted.has(id)) continue;
    const rv = r.reviewer || 'unknown';
    if (!by.has(rv)) by.set(rv, { reviewer: rv, planted_seen: 0, caught: 0, clean_seen: 0, false_alarms: 0, secs: [] });
    const b = by.get(rv), c = d !== 'approve';
    if (planted.get(id)) { ps++; b.planted_seen++; if (c) { caught++; b.caught++; } } else { cs++; b.clean_seen++; if (c) { fa++; b.false_alarms++; } }
    const s = U.num(r.seconds); if (s != null) b.secs.push(s);
  }
  return { planted_seen: ps, caught, catch_rate: ps ? caught / ps : null, clean_seen: cs, false_alarms: fa, per_reviewer: Array.from(by.values()).map(b => ({ reviewer: b.reviewer, planted_seen: b.planted_seen, caught: b.caught, catch_rate: b.planted_seen ? b.caught / b.planted_seen : null, false_alarms: b.false_alarms, median_seconds: b.secs.length ? U.median(b.secs) : null })) };
};

AF.W('human_gate', 'govern', 'Test whether a person really approves irreversible actions, from the approval records, and optionally from a seeded-error drill.', ['counter'], [needRuns(true, 'Approval records come from activity records. Without them the human gate cannot be tested.'), need('timing', false, L => L.runs.some(r => r.approvalMs != null), 'Approval times let the tool see whether reviews are quick enough to be real.', 'approval_ms on each run, or approved_at minus requested_at')],
  ({ ledger: L }, ctx) => {
    const out = [], P = L.policy, R = L.runs;
    const irr = R.filter(r => r.irreversible), unappr = irr.filter(r => !r.approvedBy), appr = irr.filter(r => r.approvedBy);
    const inferred = irr.length && irr.filter(r => r.irrBasis === 'inferred').length / irr.length >= 0.5;
    const lat = appr.map(r => r.approvalMs).filter(v => v != null), fast = lat.filter(v => v < P.minReviewMs);
    const metrics = { irreversible: irr.length, approved: appr.length, unapproved: unappr.length, approval_coverage: irr.length ? U.pct(appr.length, irr.length) : null, timed: lat.length, median_ms: lat.length ? U.median(lat) : null, fast_share: lat.length ? U.pct(fast.length, lat.length) : null, min_review_ms: P.minReviewMs, irreversible_basis: inferred ? 'inferred from tool names' : 'recorded' };
    if (P.irreversibleRequiresApproval && unappr.length) {
      const g = ctx.call('counter', { items: unappr.map(r => ({ a: r.agent })), key: 'a' }).groups.sort((x, y) => y.count - x.count);
      out.push(F({
        title: unappr.length + ' of ' + irr.length + ' irreversible actions have no approval record', severity: 'high', basis: inferred ? 'inferred' : 'observed',
        claim: 'Worst: ' + g.slice(0, 4).map(x => x.key + ' (' + x.count + ')').join(', ') + '.' + (inferred ? ' Which actions are irreversible was judged from tool names such as send, refund, approve, update.' : ''),
        evidence: g.slice(0, 6).map(x => ({ t: 'agent', id: x.key })), measure: { unapproved: unappr.length, total: irr.length },
        why: 'Your policy says a person approves these. The records show they went through without one.', fix: 'Put a hard gate in front of each irreversible tool, and log who approved and when.',
        recheck: { kind: 'count', set: 'runs', where: [['irreversible', '=', true], ['approvedBy', 'empty']], expect: unappr.length }
      }));
    }
    if (lat.length >= 30 && fast.length / lat.length >= P.fastShareFlag) out.push(F({
      title: U.pct(fast.length, lat.length) + '% of approvals took under ' + (P.minReviewMs / 1000) + ' seconds', severity: 'medium', basis: 'observed',
      claim: fast.length + ' of ' + lat.length + ' timed approvals. Median ' + U.round(U.median(lat) / 1000, 1) + ' seconds. A fast approval is a signal, not proof the review was poor: some are trivial.', evidence: [], measure: { fast: fast.length, timed: lat.length },
      why: 'If most approvals are near-instant, the gate may be a click-through. This is where a seeded-error drill gives a direct answer.', fix: 'Run the drill, and show reviewers what they are approving.',
      recheck: { kind: 'ratio', num: { set: 'runs', where: [['irreversible', '=', true], ['approvalMs', '<', P.minReviewMs], ['approvalMs', 'nonempty']] }, den: { set: 'runs', where: [['irreversible', '=', true], ['approvalMs', 'nonempty']] }, expect: fast.length / lat.length, tol: 1e-9 }
    }));
    const byA = new Map();
    for (const r of appr) { if (!byA.has(r.approvedBy)) byA.set(r.approvedBy, []); byA.get(r.approvedBy).push(r); }
    const reviewers = [];
    for (const [who, rs] of byA) {
      const t = rs.map(r => r.approvalMs).filter(v => v != null), f = t.filter(v => v < P.minReviewMs).length;
      const days = U.groupBy(rs, r => U.day(r.t)), maxDay = Array.from(days.values()).reduce((m, x) => Math.max(m, x.length), 0);
      reviewers.push({ reviewer: who, approvals: rs.length, timed: t.length, fast_share: t.length ? U.pct(f, t.length) : null, max_per_day: maxDay });
      if (t.length >= 20 && f / t.length >= 0.8) out.push(F({
        title: who + ' approved ' + U.pct(f, t.length) + '% of timed requests in under ' + (P.minReviewMs / 1000) + ' seconds', severity: 'medium', basis: 'observed',
        claim: f + ' of ' + t.length + ' timed approvals by this reviewer. Could be well-practised or could be automatic. The records cannot tell which.', evidence: [{ t: 'person', id: who }], measure: { fast: f, timed: t.length },
        why: 'One reviewer carrying most of the load at speed is a typical sign of a gate that has stopped being a check.', fix: 'Sample this reviewer\'s approvals, and include them in the drill.',
        recheck: { kind: 'ratio', num: { set: 'runs', where: [['approvedBy', '=', who], ['irreversible', '=', true], ['approvalMs', '<', P.minReviewMs], ['approvalMs', 'nonempty']] }, den: { set: 'runs', where: [['approvedBy', '=', who], ['irreversible', '=', true], ['approvalMs', 'nonempty']] }, expect: f / t.length, tol: 1e-9 }
      }));
      if (maxDay > P.reviewerDailyMax) out.push(F({
        title: who + ' approved ' + maxDay + ' actions in one day', severity: 'medium', basis: 'observed', claim: 'Your limit for a single reviewer is ' + P.reviewerDailyMax + ' a day.', evidence: [{ t: 'person', id: who }], measure: { max_per_day: maxDay, limit: P.reviewerDailyMax },
        why: 'Past a certain volume nobody reads each one.', fix: 'Spread the load, or reduce what needs approval by tightening the scope of what agents can do alone.',
        recheck: { kind: 'max_per_day', approver: who, expect: maxDay }
      }));
    }
    metrics.reviewers = reviewers.sort((a, b) => b.approvals - a.approvals).slice(0, 10);
    if (L.drill.key && L.drill.responses) {
      const sc = AF.scoreDrill(L.drill.key, L.drill.responses);
      metrics.drill = { planted_seen: sc.planted_seen, caught: sc.caught, catch_rate: sc.catch_rate == null ? null : U.round(sc.catch_rate, 3), false_alarms: sc.false_alarms, per_reviewer: sc.per_reviewer };
      if (sc.planted_seen >= 10 && sc.catch_rate < 0.7) out.push(F({
        title: 'Reviewers caught ' + sc.caught + ' of ' + sc.planted_seen + ' planted errors (' + U.pct(sc.caught, sc.planted_seen) + '%)', severity: 'high', basis: 'observed',
        claim: 'In the drill, errors were planted in requests that looked normal. The rest were approved.', evidence: [], measure: { caught: sc.caught, planted: sc.planted_seen },
        why: 'This is the direct measure. Whatever the policy says, this is what the gate catches.', fix: 'Retrain on the missed kinds, change what reviewers see, and re-run the drill.',
        recheck: { kind: 'drill', expect: sc.catch_rate, tol: 1e-9 }
      }));
    }
    return { findings: out, metrics };
  });

/* ============================== ECONOMICS ============================== */

const pricedRuns = L => L.runs.filter(r => r.cost != null);
const staleBasis = L => L.pricesStale ? 'inferred' : 'observed';

AF.W('cost_per_run', 'economics', 'What a run actually costs, per agent, and where it is rising.', ['counter'], [needRuns(true), need('cost', true, L => pricedRuns(L).length > 0, 'Costs need token counts plus a price table, or costs recorded in the logs.', 'prices.json plus in_tokens / out_tokens on each run')],
  ({ ledger: L }, ctx) => {
    const out = [], pr = pricedRuns(L);
    const g = ctx.call('counter', { items: pr.map(r => ({ a: r.agent, c: r.cost })), key: 'a', sums: ['c'], quantiles: ['c'] });
    const rows = g.groups.map(x => ({ agent: x.key, runs: x.count, total: U.round(x.sums.c, 4), mean: U.round(x.q.c.mean, 5), median: U.round(x.q.c.median, 5), p95: U.round(x.q.c.p95, 5), monthly: L.window.days >= 14 ? U.round(x.sums.c / L.window.days * 30, 2) : null })).sort((a, b) => b.total - a.total);
    const t0 = L.window.first, span = L.window.last - L.window.first, c1 = t0 + span / 3, c2 = t0 + 2 * span / 3;
    for (const r of rows) {
      const rr = AF.runsOf(L, r.agent).filter(x => x.cost != null), early = rr.filter(x => x.t < c1), late = rr.filter(x => x.t >= c2);
      if (early.length >= 30 && late.length >= 30) {
        const me = U.mean(early.map(x => x.cost)), ml = U.mean(late.map(x => x.cost));
        if (me > 0 && ml / me >= 1.3) out.push(F({
          title: r.agent + ' now costs ' + U.round(ml / me, 2) + 'x per run what it did at the start of the window', severity: 'medium', basis: staleBasis(L),
          claim: 'Mean cost per run went from ' + money(me) + ' to ' + money(ml) + '. Could be longer inputs, more retries, or a model change. The logs show the cost, not the cause.', evidence: [{ t: 'agent', id: r.agent }], measure: { early: me, late: ml },
          why: 'A steady rise in cost per run is how a cheap agent becomes an expensive one without anyone deciding it.', fix: 'Check token counts and retry rates for this agent.',
          recheck: [{ kind: 'mean', set: 'runs', field: 'cost', where: [['agent', '=', r.agent], ['t', '<', c1]], expect: me, tol: 1e-9 }, { kind: 'mean', set: 'runs', field: 'cost', where: [['agent', '=', r.agent], ['t', '>=', c2]], expect: ml, tol: 1e-9 }]
        }));
      }
    }
    const bud = L.policy.monthlyBudget;
    if (bud && L.window.days >= 14) for (const r of rows) {
      const b = bud[r.agent]; if (b != null && r.monthly > b) out.push(F({
        title: r.agent + ' is running at ' + money(r.monthly) + ' a month against a budget of ' + money(b), severity: 'medium', basis: staleBasis(L),
        claim: 'Projected from ' + Math.round(L.window.days) + ' days of activity.', evidence: [{ t: 'agent', id: r.agent }], measure: { monthly: r.monthly, budget: b },
        why: 'Over budget with nobody having decided it.', fix: 'Raise the budget on the record, or cut usage.',
        recheck: { kind: 'sum', set: 'runs', field: 'cost', where: [['agent', '=', r.agent]], expect: r.total, tol: 1e-3 }
      }));
    }
    return { findings: out, metrics: { rows: rows.slice(0, 15), note: L.pricesStale ? 'Price table is older than your limit; figures are indicative.' : '' } };
  });

AF.W('token_waste', 'economics', 'Cost spent on runs that failed, retried or repeated the same input.', ['counter'], [needRuns(true), need('cost', true, L => pricedRuns(L).length > 0, 'Costs need token counts plus a price table, or costs recorded in the logs.', 'prices.json plus in_tokens / out_tokens')],
  ({ ledger: L }) => {
    const out = [], pr = pricedRuns(L), by = U.groupBy(pr, r => r.agent), rows = [];
    for (const [a, rr] of by) {
      const tot = U.sum(rr.map(r => r.cost)), bad = rr.filter(r => r.outcome === 'error' || r.outcome === 'retry'), w = U.sum(bad.map(r => r.cost));
      const seen = new Set(); let dup = 0, dupc = 0;
      for (const r of rr) if (r.inputHash) { const k = r.inputHash; if (seen.has(k)) { dup++; dupc += r.cost; } else seen.add(k); }
      rows.push({ agent: a, total: U.round(tot, 4), failed_retried: bad.length, wasted: U.round(w, 4), wasted_share: tot ? U.pct(w, tot) : 0, repeated_inputs: dup, repeated_cost: U.round(dupc, 4) });
      if (rr.length >= 30 && tot > 0 && w / tot >= 0.1) out.push(F({
        title: a + ': ' + U.pct(w, tot) + '% of spend went on failed or retried runs', severity: 'medium', basis: staleBasis(L),
        claim: bad.length + ' of ' + rr.length + ' runs failed or retried, costing ' + money(w) + ' of ' + money(tot) + '.', evidence: [{ t: 'agent', id: a }], measure: { wasted: w, total: tot },
        why: 'Money spent for no result, and usually a sign the agent is badly matched to its task or model.', fix: 'Fix the cause of the failures. Cap retries.',
        recheck: { kind: 'sum', set: 'runs', field: 'cost', where: [['agent', '=', a], ['outcome', 'in', ['error', 'retry']]], expect: w, tol: 1e-6 }
      }));
      if (dup >= 20 && dupc / tot >= 0.1) out.push(F({
        title: a + ' paid to answer the same input ' + dup + ' times', severity: 'low', basis: staleBasis(L),
        claim: money(dupc) + ' spent on repeats. A cache could return the earlier answer where that is safe.', evidence: [{ t: 'agent', id: a }], measure: { repeats: dup, cost: dupc },
        why: 'Identical questions answered from scratch every time.', fix: 'Cache results where the answer does not change.',
        recheck: { kind: 'dup_input_cost', agent: a, expect: dupc }
      }));
    }
    return { findings: out, metrics: { rows: rows.sort((a, b) => b.wasted - a.wasted).slice(0, 12) } };
  });

AF.W('model_fit', 'economics', 'Compare how big each agent\'s model is with how hard its job is. Raises candidates to test. Quality is not measured here.', ['counter'], [needAgents, needPrices, need('complexity', false, L => real(L).filter(a => a.complexity).length >= real(L).length * 0.5, 'Saying whether each agent\'s job is simple, standard or complex lets the tool compare the model with the task.', 'estate.json: complexity: "simple" | "standard" | "complex"')],
  ({ ledger: L }) => {
    const out = [], models = L.prices.models, A = real(L);
    const names = Object.keys(models), outs = names.map(n => models[n].out || 0).sort((a, b) => a - b);
    const tier = n => { const m = models[n]; if (!m) return null; if (m.tier) return m.tier; const o = m.out || 0; return o <= outs[Math.floor(outs.length / 3)] ? 'small' : (o <= outs[Math.floor(2 * outs.length / 3)] ? 'mid' : 'large'); };
    const small = names.filter(n => tier(n) === 'small').sort((a, b) => models[a].out - models[b].out)[0];
    const rows = [];
    for (const a of A) {
      if (!a.run_count || !a.complexity) continue;
      const rr = AF.runsOf(L, a.id).filter(r => r.model), main = rr.length ? U.groupBy(rr, r => r.model) : null;
      if (!main) continue;
      const top = Array.from(main.entries()).sort((x, y) => y[1].length - x[1].length)[0][0], t = tier(top);
      rows.push({ agent: a.id, complexity: a.complexity, model: top, tier: t });
      if (a.complexity === 'simple' && t === 'large' && small) {
        const cur = U.sum(rr.filter(r => r.model === top && r.cost != null).map(r => r.cost));
        const sm = models[small], alt = U.sum(rr.filter(r => r.model === top && r.cost != null).map(r => ((r.inTok || 0) * sm.in + (r.outTok || 0) * sm.out) / 1e6));
        if (cur - alt > 0) out.push(F({
          title: a.name + ' is a simple job on a large model', severity: 'low', basis: 'inferred',
          claim: 'Declared simple, running ' + top + '. On ' + small + ' the same tokens would cost about ' + money(alt) + ' instead of ' + money(cur) + ' in this window. Whether the smaller model is good enough is untested.', evidence: [{ t: 'agent', id: a.id }], measure: { now: cur, alt, to: small },
          why: 'Paying for capability the task may not need.', fix: 'Test the smaller model on a sample of real inputs and compare results before switching.',
          recheck: { kind: 'repriced_saving', agent: a.id, from_model: top, to_model: small, expect: cur - alt, tol: 1e-6 }
        }));
      }
      if (a.complexity === 'complex' && t === 'small') {
        const bad = rr.filter(r => r.outcome === 'error' || r.outcome === 'retry').length;
        if (rr.length >= 30 && bad / rr.length >= 0.15) out.push(F({
          title: a.name + ' is a complex job on a small model and fails often', severity: 'medium', basis: 'inferred',
          claim: 'Declared complex, running ' + top + '. ' + bad + ' of ' + rr.length + ' runs failed or retried (' + U.pct(bad, rr.length) + '%). The model may be too small for the job, or the failures may have another cause.', evidence: [{ t: 'agent', id: a.id }], measure: { failure_share: U.pct(bad, rr.length) },
          why: 'A cheap model that needs repeats can cost more than a bigger one that gets it right first time.', fix: 'Test one tier up on the same inputs and compare cost per successful run.',
          recheck: { kind: 'ratio', num: { set: 'runs', where: [['agent', '=', a.id], ['model', '=', top], ['outcome', 'in', ['error', 'retry']]] }, den: { set: 'runs', where: [['agent', '=', a.id], ['model', '=', top]] }, expect: bad / rr.length, tol: 1e-9 }
        }));
      }
    }
    return { findings: out, metrics: { rows } };
  });

AF.W('price_check', 'economics', 'Check the price table itself: its age, models it does not cover, and whether recorded costs agree with token counts.', [], [needPrices],
  ({ ledger: L }) => {
    const out = [], P = L.prices;
    if (L.pricesStale) out.push(F({
      title: 'Price table is ' + P.ageDays + ' days old, past your limit of ' + L.policy.maxPriceAgeDays, severity: 'high', basis: 'declared',
      claim: 'Table dated ' + P.as_of + (P.source ? ', source: ' + P.source : '') + '.', evidence: [], measure: { age: P.ageDays, limit: L.policy.maxPriceAgeDays },
      why: 'Prices change. Cost findings built on an old table can be wrong in either direction.', fix: 'Update the table from the providers\' own price pages and re-run.',
      recheck: { kind: 'ledger_value', path: 'prices.ageDays', op: '>', value: L.policy.maxPriceAgeDays }
    }));
    if (empty(P.source)) out.push(F({
      title: 'Price table says nothing about where the prices came from', severity: 'low', basis: 'declared', claim: 'No source field.', evidence: [], measure: {},
      why: 'Nobody can check a price with no source.', fix: 'Add the source and date for each price.', recheck: { kind: 'ledger_value', path: 'prices.source', op: 'empty' }
    }));
    const withModel = L.runs.filter(r => r.model), unpriced = withModel.filter(r => !r.priced && r.cost_obs == null);
    if (withModel.length && unpriced.length / withModel.length >= 0.1) {
      const names = U.uniq(unpriced.map(r => r.model));
      out.push(F({
        title: U.pct(unpriced.length, withModel.length) + '% of runs use models missing from the price table', severity: 'medium', basis: 'observed',
        claim: names.slice(0, 6).join(', ') + '. Their cost cannot be calculated, so every cost figure is understated.', evidence: names.slice(0, 6).map(n => ({ t: 'model', id: n })), measure: { runs: unpriced.length },
        why: 'Missing prices make spend look lower than it is.', fix: 'Add the missing models to the table.',
        recheck: { kind: 'ratio', num: { set: 'runs', where: [['model', 'nonempty'], ['priced', '=', false], ['cost_obs', 'empty']] }, den: { set: 'runs', where: [['model', 'nonempty']] }, expect: unpriced.length / withModel.length, tol: 1e-9 }
      }));
    }
    const both = L.runs.filter(r => r.cost_obs != null && r.cost_calc != null);
    if (both.length >= 30) {
      const off = both.filter(r => Math.abs(r.cost_calc - r.cost_obs) / Math.max(r.cost_obs, 1e-12) > 0.05);
      if (off.length / both.length >= 0.1) out.push(F({
        title: U.pct(off.length, both.length) + '% of runs record a cost that differs from the price table by over 5%', severity: 'medium', basis: 'observed',
        claim: 'Recorded costs and token-based costs disagree on ' + off.length + ' of ' + both.length + ' runs. Either the table is wrong, the logs are, or discounts apply that the table does not show.', evidence: [], measure: { off: off.length, compared: both.length },
        why: 'Two sources of cost that disagree means neither can be trusted yet.', fix: 'Reconcile against an actual invoice.', recheck: { kind: 'cost_mismatch_share', expect: off.length / both.length, tol: 1e-9 }
      }));
    }
    return { findings: out, metrics: { as_of: P.as_of, age_days: P.ageDays, stale: L.pricesStale, models: Object.keys(P.models).length } };
  });

AF.W('outcome_cost', 'economics', 'Cost per successful outcome, including the time people spend reviewing.', ['counter'], [needRuns(true), need('cost', true, L => pricedRuns(L).length > 0, 'Costs need token counts plus a price table, or costs recorded in the logs.', 'prices.json plus in_tokens / out_tokens'), need('review', false, L => L.policy.reviewMinutesPerApproval != null && L.policy.reviewCostPerHour != null, 'Review cost needs two numbers from you: minutes per approval, and cost per hour of a reviewer.', 'Policy box: review minutes per approval, review cost per hour')],
  ({ ledger: L }) => {
    const out = [], P = L.policy, by = U.groupBy(pricedRuns(L), r => r.agent), rows = [];
    const rev = P.reviewMinutesPerApproval != null && P.reviewCostPerHour != null;
    const heavy = [];
    for (const [a, rr] of by) {
      const ok = rr.filter(r => r.outcome === 'ok').length, mc = U.sum(rr.map(r => r.cost)), ap = rr.filter(r => r.approvedBy).length;
      const rc = rev ? ap * P.reviewMinutesPerApproval / 60 * P.reviewCostPerHour : null;
      rows.push({ agent: a, runs: rr.length, ok, model_cost: U.round(mc, 4), approvals: ap, review_cost: rc == null ? null : U.round(rc, 2), per_outcome: ok ? U.round((mc + (rc || 0)) / ok, 4) : null });
      if (rev && ap >= 20 && rc > mc) heavy.push({ a, mc, rc });
    }
    if (heavy.length) {
      const tm = U.sum(heavy.map(h => h.mc)), tr = U.sum(heavy.map(h => h.rc));
      out.push(F({
        title: 'For ' + heavy.length + ' agent' + (heavy.length > 1 ? 's' : '') + ', paying people to review costs more than the model does', severity: 'medium', basis: 'inferred',
        claim: 'Across them, model spend is ' + money(tm) + ' and review time is about ' + money(tr) + ' (' + P.reviewMinutesPerApproval + ' minutes per approval at ' + money(P.reviewCostPerHour) + ' an hour; your estimate, not measured). Largest: ' + heavy.slice().sort((x, y) => y.rc - x.rc).slice(0, 3).map(h => h.a + ' ' + money(h.rc)).join(', ') + '.',
        evidence: heavy.map(h => ({ t: 'agent', id: h.a })), measure: { model: tm, review: tr },
        why: 'The real price of an agent includes the people checking it. Counting only the model hides most of the cost, and it changes which business cases hold.', fix: 'Narrow review to the risky cases, or check the agent is worth running at all.',
        recheck: heavy.slice(0, 12).map(h => ({ kind: 'review_vs_model', agent: h.a, minutes: P.reviewMinutesPerApproval, rate: P.reviewCostPerHour, expect_model: h.mc, expect_review: h.rc, tol: 1e-6 }))
      }));
    }
    return { findings: out, metrics: { rows: rows.sort((a, b) => (b.model_cost + (b.review_cost || 0)) - (a.model_cost + (a.review_cost || 0))).slice(0, 15), review_included: rev } };
  });

const STOP = new Set('the a an and or of for to in on with from by at as is are be this that these those it its into over per each all any'.split(' '));
const toks = s => new Set(String(s || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter(w => w.length > 2 && !STOP.has(w)));
const jacc = (a, b) => { if (!a.size || !b.size) return 0; let i = 0; for (const x of a) if (b.has(x)) i++; return i / (a.size + b.size - i); };
AF.overlapScore = (a, b) => {
  const p = jacc(toks(a.purpose), toks(b.purpose));
  const ta = new Set(a.tools || []), tb = new Set(b.tools || []);
  const t = ta.size >= 2 && tb.size >= 2 ? jacc(ta, tb) : 0;
  return Math.max(p, t >= 0.6 ? t : 0);
};

AF.W('overlap_finder', 'economics', 'Find agents that appear to do the same job, so duplicates are caught before each one grows its own cost and risk.', [], [needAgents],
  ({ ledger: L }) => {
    const A = real(L).filter(a => !a.shadow), out = [], pairs = [], th = L.policy.overlapThreshold;
    for (let i = 0; i < A.length; i++) for (let j = i + 1; j < A.length; j++) {
      const s = AF.overlapScore(A[i], A[j]); if (s >= th) pairs.push({ a: A[i], b: A[j], s });
    }
    pairs.sort((x, y) => y.s - x.s);
    for (const p of pairs.slice(0, 12)) {
      const cost = id => U.sum(AF.runsOf(L, id).filter(r => r.cost != null).map(r => r.cost));
      const diff = (p.a.dept && p.b.dept && p.a.dept !== p.b.dept) || (p.a.platform && p.b.platform && p.a.platform !== p.b.platform);
      out.push(F({
        title: p.a.name + ' and ' + p.b.name + ' look like the same job', severity: diff ? 'medium' : 'low', basis: 'inferred',
        claim: 'Purpose wording overlaps ' + U.round(p.s * 100, 0) + '%' + (diff ? ' and they sit in different ' + (p.a.dept !== p.b.dept ? 'departments' : 'platforms') : '') + '. Together they ran ' + (p.a.run_count + p.b.run_count) + ' times and cost ' + money(cost(p.a.id) + cost(p.b.id)) + ' in the window. This is a guess from descriptions, so a person needs to confirm.',
        evidence: [{ t: 'agent', id: p.a.id }, { t: 'agent', id: p.b.id }], measure: { score: U.round(p.s, 3) },
        why: 'Two agents doing one job means two owners, two budgets and two sets of risk, and usually one of them has a business case that does not hold.', fix: 'Confirm whether they are duplicates. If so, keep the better one and retire the other.',
        recheck: { kind: 'overlap', a: p.a.id, b: p.b.id, expect: p.s, tol: 1e-9 }
      }));
    }
    return { findings: out, metrics: { pairs_found: pairs.length, threshold: th } };
  });

AF.W('case_vs_actual', 'economics', 'Set each agent\'s original business case against what is happening, and say whether it is on course to pay back, and if not, why.', ['counter'], [needAgents, needRuns(true, 'Actual volume and cost come from activity records.'), need('cases', false, L => L.cases.length > 0, 'No business cases were supplied. The tool compares actuals only against a case, and an agent with no case has nothing to be judged against.', 'cases.json: [{ id, agent_ids, claimed_benefit_per_month, assumed_runs_per_month, assumed_cost_per_run, payback_months, start, owner, source: "original" | "reconstructed" }]'), need('outcomes', false, L => L.outcomes.length > 0, 'Benefit is the one thing the logs cannot show. Without outcome figures from you, payback can only be judged on the cost side.', 'outcomes.json: [{ case_id, month: "2026-09", benefit }]')],
  ({ ledger: L }) => {
    const out = [], A = real(L), days = L.window.days, P = L.policy, rows = [];
    const nocase = A.filter(a => !a.shadow && !a.has_case);
    if (nocase.length) out.push(F({
      title: nocase.length + ' of ' + A.filter(a => !a.shadow).length + ' agents have no business case on record', severity: nocase.length > 3 ? 'high' : 'medium', basis: 'declared',
      claim: nocase.slice(0, 10).map(a => a.name).join(', ') + (nocase.length > 10 ? ', and more' : '') + '.', evidence: nocase.slice(0, 10).map(a => ({ t: 'agent', id: a.id })), measure: { count: nocase.length },
      why: 'Without a stated reason and a number to aim for, nobody can say if the agent is worth its cost, and nobody will ever switch it off.', fix: 'Write one down per agent: what it should save or earn, at what cost, by when, owned by whom.',
      recheck: { kind: 'count', set: 'agents', where: [['stub', '!=', true], ['shadow', '!=', true], ['has_case', '!=', true]], expect: nocase.length }
    }));
    for (const c of L.cases) {
      const ags = c.agent_ids, rr = ags.reduce((acc, id) => acc.concat(AF.runsOf(L, id)), []), pr = rr.filter(r => r.cost != null);
      const tot = U.sum(pr.map(r => r.cost)), enough = days >= 14;
      const runsPM = enough ? rr.length / days * 30 : null, costPM = enough ? tot / days * 30 : null, cpr = pr.length ? tot / pr.length : null;
      const volRatio = runsPM != null && c.runs_pm ? runsPM / c.runs_pm : null, costRatio = cpr != null && c.cost_per_run ? cpr / c.cost_per_run : null;
      const startMs = U.ms(c.start), elapsed = startMs != null && L.asOf != null ? (L.asOf - startMs) / (30.44 * 86400000) : null;
      const oc = L.outcomes.filter(o => o.case_id === c.id || (o.agent && ags.includes(o.agent)));
      const reasons = [];
      if (volRatio != null && volRatio < P.volumeShort) reasons.push('volume is ' + U.round(volRatio * 100, 0) + '% of what the case assumed');
      if (costRatio != null && costRatio > P.costHigh) reasons.push('cost per run is ' + U.round(costRatio, 1) + 'x the case');
      const owners = ags.map(id => A.find(a => a.id === id)).filter(Boolean);
      if (owners.some(a => a.owner_left)) reasons.push('the owner has left');
      if (owners.length && owners.every(a => a.idle_days != null && a.idle_days > P.inactiveDays)) reasons.push('the agent has been idle for over ' + P.inactiveDays + ' days');
      const taken = [];
      for (const a of owners) for (const b of A) if (b.id !== a.id && !ags.includes(b.id) && b.run_count > a.run_count && AF.overlapScore(a, b) >= P.overlapThreshold) taken.push(b.name);
      if (taken.length) reasons.push('a similar agent (' + U.uniq(taken).join(', ') + ') is taking more of the work');
      if (!oc.length) reasons.push('benefit has not been measured, so payback cannot be shown');
      let verdict = 'cannot_tell', basis = 'declared', detail = '';
      const benefitPM = oc.length ? U.mean(oc.slice().sort((a, b) => String(a.month).localeCompare(String(b.month))).slice(-3).map(o => o.benefit || 0)) : null;
      if (oc.length && elapsed != null && costPM != null && c.payback_months) {
        const months = U.uniq(oc.map(o => o.month)).length, avgAll = U.sum(oc.map(o => o.benefit || 0)) / months;
        const extrap = months < Math.floor(elapsed);
        const cumB = extrap ? avgAll * elapsed : U.sum(oc.map(o => o.benefit || 0));
        if (extrap) { basis = 'inferred'; reasons.push('benefit figures cover ' + months + ' of ' + Math.floor(elapsed) + ' months, so earlier months are assumed at the same rate'); }
        const cum = cumB - costPM * elapsed - (c.build_cost || 0);
        if (elapsed >= c.payback_months) { verdict = cum >= 0 ? 'on_track' : 'behind'; detail = 'After ' + U.round(elapsed, 1) + ' months (payback target ' + c.payback_months + ') net position is ' + money(cum) + '.'; }
        else { const net = benefitPM - costPM; if (net <= 0) { verdict = 'behind'; detail = 'Monthly benefit ' + money(benefitPM) + ' does not cover monthly cost ' + money(costPM) + ', so it never pays back at this rate.'; } else { const needM = Math.max(0, -cum) / net, proj = elapsed + needM; verdict = proj <= c.payback_months * 1.1 ? 'on_track' : 'behind'; detail = 'At the current run-rate, payback lands around month ' + U.round(proj, 1) + ' against a target of ' + c.payback_months + '.'; } }
      } else if (!oc.length && volRatio != null && c.benefit_pm && costPM != null) {
        const scaled = c.benefit_pm * volRatio, net = scaled - costPM;
        detail = 'No benefit figures. If benefit scales with volume, monthly benefit would be about ' + money(scaled) + ' against cost ' + money(costPM) + ' (net ' + money(net) + '). That scaling is an assumption.';
        if (net <= 0) { verdict = 'behind'; basis = 'inferred'; }
      }
      rows.push({ case: c.id, name: c.name, source: c.source, agents: ags, assumed_runs_pm: c.runs_pm, actual_runs_pm: runsPM == null ? null : U.round(runsPM, 0), assumed_cost_per_run: c.cost_per_run, actual_cost_per_run: cpr == null ? null : U.round(cpr, 5), verdict, reasons });
      const recheck = [{ kind: 'count', set: 'runs', where: [['agent', 'in', ags]], expect: rr.length }, { kind: 'sum', set: 'runs', field: 'cost', where: [['agent', 'in', ags]], expect: tot, tol: 1e-6 }];
      const cap = c.source === 'reconstructed' ? ' This case was reconstructed afterwards rather than taken from the original approval, so it is a yardstick, not a promise.' : '';
      if (verdict === 'behind') out.push(F({
        title: 'Business case "' + c.name + '" is behind', severity: c.source === 'reconstructed' ? 'medium' : 'high', basis,
        claim: (reasons.length ? 'Why: ' + reasons.join('; ') + '. ' : '') + detail + cap, evidence: ags.map(id => ({ t: 'agent', id })).concat([{ t: 'case', id: c.id }]), measure: { volume_ratio: volRatio, cost_ratio: costRatio },
        why: 'The reason this agent was approved is not being met, and the gap has a cause that can be named.', fix: 'Decide: fix the cause, restate the case honestly, or switch it off.', recheck
      }));
      else if (verdict === 'on_track') out.push(F({
        title: 'Business case "' + c.name + '" is on track', severity: 'info', basis,
        claim: detail + (reasons.length ? ' Note: ' + reasons.join('; ') + '.' : '') + cap, evidence: ags.map(id => ({ t: 'agent', id })).concat([{ t: 'case', id: c.id }]), measure: { volume_ratio: volRatio, cost_ratio: costRatio },
        why: 'A case that holds up on the figures given.', fix: 'Keep recording the benefit monthly so it stays provable.', recheck
      }));
      else if (verdict === 'cannot_tell') out.push(F({
        title: 'Business case "' + c.name + '": payback cannot be shown', severity: (volRatio != null && volRatio < P.volumeShort) || (costRatio != null && costRatio > P.costHigh) ? 'medium' : 'low', basis,
        claim: (reasons.length ? reasons.join('; ') + '. ' : '') + detail + cap, evidence: ags.map(id => ({ t: 'agent', id })).concat([{ t: 'case', id: c.id }]), measure: { volume_ratio: volRatio, cost_ratio: costRatio },
        why: 'The cost side is visible, the benefit side is not. "Cannot tell" is the honest answer, and it is also the answer most organisations are in.', fix: 'Start recording the benefit this case promised, monthly.', recheck
      }));
    }
    return { findings: out, metrics: { cases: L.cases.length, rows, without_case: nocase.length } };
  });

/* these workers price tokens, so a stale table makes them refuse */
for (const id of ['spend_usage', 'cost_per_run', 'token_waste', 'model_fit', 'outcome_cost', 'case_vs_actual']) AF.REG[id].usesPrices = true;

/* ============================== LEADS ============================== */

const MODULES = {
  discover: { label: 'Soundings', blurb: 'What is actually running, on which models, at what spend.', workers: ['ai_inventory', 'model_finder', 'spend_usage', 'coverage_gaps'] },
  secure: { label: 'Sentinel', blurb: 'How an attacker, or an honest mistake, could travel through the estate.', workers: ['attack_paths', 'injection_paths', 'access_keys', 'trace_integrity', 'blast_radius'] },
  govern: { label: 'Keel', blurb: 'Whether the structure, links, models, owners and human gates match the rules.', workers: ['pyramid_review', 'link_rules', 'model_register', 'sector_rules', 'policy_drift', 'owner_chain', 'human_gate'] },
  economics: { label: 'Reckoning', blurb: 'What it costs, whether it is the right model, and whether each agent pays back.', workers: ['cost_per_run', 'token_waste', 'model_fit', 'price_check', 'outcome_cost', 'overlap_finder', 'case_vs_actual'] }
};
AF.MODULES = MODULES;
AF.WORKER_META = id => { const r = AF.REG[id]; return { id, purpose: r.purpose, module: r.module, needs: r.needs.map(n => ({ key: n.key, critical: n.critical, why: n.why, hint: n.hint })) }; };

for (const [m, def] of Object.entries(MODULES)) {
  AF.define({
    id: m + '_lead', tier: 'lead', module: m, purpose: def.blurb, may_call: def.workers,
    fn: ({ ledger: L, workers, params }, ctx) => {
      const run = {}, requests = [];
      const sel = workers && workers.length ? def.workers.filter(w => workers.includes(w)) : def.workers;
      for (const w of def.workers) {
        if (!sel.includes(w)) { run[w] = { status: 'not selected', findings: [], metrics: {} }; continue; }
        const spec = AF.REG[w], missing = spec.needs.filter(n => !n.test(L));
        const crit = missing.filter(n => n.critical);
        const reqs = missing.map(n => ({ worker: w, key: n.key, critical: n.critical, why: n.why, hint: n.hint }));
        requests.push(...reqs);
        if (crit.length) { run[w] = { status: 'blocked', reason: crit.map(n => n.why).join(' '), findings: [], metrics: {}, requests: reqs }; continue; }
        if (spec.usesPrices && L.pricesStale && !(params && params.acceptStalePrices) && L.runs.some(r => r.cost_obs == null && r.cost_calc != null)) {
          const rq = { worker: w, key: 'fresh prices', critical: true, why: 'The price table is ' + L.prices.ageDays + ' days old, past the limit of ' + L.policy.maxPriceAgeDays + '. This worker refuses to put numbers on an old table.', hint: 'Update prices.json, or tick "use stale prices anyway" to run with a warning.' };
          requests.push(rq); run[w] = { status: 'refused', reason: rq.why, findings: [], metrics: {}, requests: [rq] }; continue;
        }
        const res = ctx.call(w, { ledger: L, params: params || {} });
        if (res && res.error) { run[w] = { status: 'error', reason: res.error, findings: [], metrics: {}, requests: reqs }; continue; }
        run[w] = { status: missing.length ? 'partial' : 'complete', findings: res.findings.map((f, i) => Object.assign(f, { id: w + '-' + (i + 1), worker: w, module: m })), metrics: res.metrics || {}, requests: reqs };
      }
      return { module: m, workers: run, requests };
    }
  });
}

})(AF);

/* ---- verify_report.js ---- */
(function(AF){
/* Verifier, beliefs, report writer, seeded-error drill, supervisor. */
'use strict';
const U = AF.U, esc = U.esc;

/* ========== verifier ==========
   Sees only the frozen evidence and each finding's declarative recheck. It never runs a worker.
   It recomputes the number from the records with its own small query engine. */

const isEmpty = x => x == null || x === '' || (Array.isArray(x) && x.length === 0);
const cmp = (rec, c) => {
  const f = c[0], op = c[1], v = c[2], x = rec[f];
  switch (op) {
    case '=': return x === v;
    case '!=': return x !== v;
    case '>': return x != null && x > v;
    case '>=': return x != null && x >= v;
    case '<': return x != null && x < v;
    case '<=': return x != null && x <= v;
    case 'in': return Array.isArray(v) && v.includes(x);
    case 'notin': return Array.isArray(v) && !v.includes(x);
    case 'includes': case 'contains':
      if (Array.isArray(x)) return x.includes(v);
      return typeof x === 'string' && x.toLowerCase().includes(String(v).toLowerCase());
    case 'empty': return isEmpty(x);
    case 'nonempty': return !isEmpty(x);
    default: throw new Error('unknown op ' + op);
  }
};
const sel = (L, set, where) => {
  const pool = ({ runs: L.runs, agents: L.agents, links: L.links, expenses: L.expenses, cases: L.cases, extensions: L.extensions })[set];
  if (!pool) throw new Error('unknown set ' + set);
  return pool.filter(r => (where || []).every(c => cmp(r, c)));
};
const near = (a, b, tol) => { if (a == null || b == null) return false; const t = tol == null ? 1e-9 : tol; return Math.abs(a - b) <= t + Math.abs(b) * 1e-9; };
const bfs = (L, from) => {
  const adj = new Map(); for (const l of L.links) { if (!adj.has(l.from)) adj.set(l.from, []); adj.get(l.from).push(l.to); }
  const d = new Map([[from, 0]]), q = [from]; let back = false;
  for (let i = 0; i < q.length; i++) for (const n of (adj.get(q[i]) || [])) { if (n === from) back = true; if (!d.has(n)) { d.set(n, d.get(q[i]) + 1); q.push(n); } }
  return { d, back };
};
const words = s => { const stop = new Set('the a an and or of for to in on with from by at as is are be this that these those it its into over per each all any'.split(' ')); return new Set(String(s || '').toLowerCase().split(/[^a-z0-9]+/).filter(w => w.length > 2 && !stop.has(w))); };
const jac = (x, y) => { if (!x.size || !y.size) return 0; let n = 0; x.forEach(w => { if (y.has(w)) n++; }); return n / (x.size + y.size - n); };
const selOk = (s, a) => { if (!s || s === '*') return true; const i = s.indexOf(':'), k = s.slice(0, i), v = s.slice(i + 1); return k === 'tier' ? a.tier === v : k === 'agent' ? a.id === U.slug(v) : k === 'dept' ? U.slug(a.dept) === U.slug(v) : k === 'external' ? !!a.external : false; };

const RECHECK = {
  count: (L, r) => { const n = sel(L, r.set, r.where).length; return { value: n, ok: n === r.expect }; },
  sum: (L, r) => { const v = sel(L, r.set, r.where).reduce((s, x) => s + (typeof x[r.field] === 'number' ? x[r.field] : 0), 0); return { value: v, ok: near(v, r.expect, r.tol) }; },
  mean: (L, r) => { const a = sel(L, r.set, r.where).map(x => x[r.field]).filter(x => typeof x === 'number'); const v = a.length ? a.reduce((s, x) => s + x, 0) / a.length : null; return { value: v, ok: near(v, r.expect, r.tol) }; },
  ratio: (L, r) => { const n = sel(L, r.num.set, r.num.where).length, d = sel(L, r.den.set, r.den.where).length; const v = d ? n / d : null; return { value: v, ok: near(v, r.expect, r.tol) }; },
  distinct: (L, r) => { const v = new Set(sel(L, r.set, r.where).map(x => x[r.field])).size; return { value: v, ok: v === r.expect }; },
  distinct_gap: (L) => { const s = L.runs.filter(x => x.span).map(x => x.trace + '/' + x.span); return { value: s.length - new Set(s).size, ok: true, check: (e) => s.length - new Set(s).size === e }; },
  path: (L, r) => { const x = bfs(L, r.from); const v = r.from !== r.to && x.d.has(r.to); return { value: v, ok: v === r.expect }; },
  cycle: (L, r) => { const v = bfs(L, r.from).back; return { value: v, ok: v === true }; },
  reach_count: (L, r) => { const v = bfs(L, r.from).d.size - 1; return { value: v, ok: v === r.expect }; },
  depth_from: (L, r) => { const v = Array.from(bfs(L, r.from).d.values()).reduce((m, x) => Math.max(m, x), 0); return { value: v, ok: v === r.expect }; },
  overlap: (L, r) => { const a = L.agents.find(x => x.id === r.a), b = L.agents.find(x => x.id === r.b); if (!a || !b) return { value: null, ok: false }; const p = jac(words(a.purpose), words(b.purpose)); const ta = new Set(a.tools || []), tb = new Set(b.tools || []); const t = ta.size >= 2 && tb.size >= 2 ? jac(ta, tb) : 0; const v = Math.max(p, t >= 0.6 ? t : 0); return { value: v, ok: near(v, r.expect, r.tol) }; },
  unused_share: (L, r) => { let d = 0, u = 0; for (const a of L.agents) { if (a.stub || !a.run_count) continue; const used = new Set(L.runs.filter(x => x.agent === a.id).map(x => x.tool).filter(Boolean)); for (const t of a.tools || []) { d++; if (!used.has(t)) u++; } } const v = d ? u / d : null; return { value: v, ok: near(v, r.expect, 1e-9) }; },
  ledger_value: (L, r) => { const v = r.path.split('.').reduce((o, k) => (o == null ? o : o[k]), L); const ok = r.op === '>' ? v > r.value : r.op === 'empty' ? isEmpty(v) : false; return { value: v, ok }; },
  drill: (L, r) => { if (!L.drill.key || !L.drill.responses) return { value: null, ok: false }; const key = new Map((L.drill.key.key || []).map(k => [String(k.id), !!k.planted])); let p = 0, c = 0; for (const x of L.drill.responses) { const id = String(x.item_id); if (!key.has(id) || !key.get(id)) continue; p++; if (String(x.decision || '').toLowerCase() !== 'approve') c++; } const v = p ? c / p : null; return { value: v, ok: near(v, r.expect, r.tol) }; },
  dup_input_cost: (L, r) => { const seen = new Set(); let s = 0; for (const x of L.runs) { if (x.agent !== r.agent || x.cost == null || !x.inputHash) continue; if (seen.has(x.inputHash)) s += x.cost; else seen.add(x.inputHash); } return { value: s, ok: near(s, r.expect, 1e-6) }; },
  repriced_saving: (L, r) => { const m = L.prices.models, f = m[r.from_model], t = m[r.to_model]; if (!f || !t) return { value: null, ok: false }; let cur = 0, alt = 0; for (const x of L.runs) { if (x.agent !== r.agent || x.model !== r.from_model || x.cost == null) continue; cur += x.cost; alt += ((x.inTok || 0) * t.in + (x.outTok || 0) * t.out) / 1e6; } return { value: cur - alt, ok: near(cur - alt, r.expect, r.tol) }; },
  cost_mismatch_share: (L, r) => { const b = L.runs.filter(x => x.cost_obs != null && x.cost_calc != null); const o = b.filter(x => Math.abs(x.cost_calc - x.cost_obs) / Math.max(x.cost_obs, 1e-12) > 0.05).length; const v = b.length ? o / b.length : null; return { value: v, ok: near(v, r.expect, r.tol) }; },
  review_vs_model: (L, r) => { const rr = L.runs.filter(x => x.agent === r.agent && x.cost != null); const m = rr.reduce((s, x) => s + x.cost, 0), ap = rr.filter(x => x.approvedBy).length; const rv = ap * r.minutes / 60 * r.rate; return { value: [m, rv], ok: near(m, r.expect_model, r.tol) && near(rv, r.expect_review, r.tol) && rv > m }; },
  max_per_day: (L, r) => { const d = new Map(); for (const x of L.runs) if (x.approvedBy === r.approver && x.irreversible) { const k = Math.floor(x.t / 86400000); d.set(k, (d.get(k) || 0) + 1); } const v = d.size ? Array.from(d.values()).reduce((m, x) => Math.max(m, x), 0) : 0; return { value: v, ok: v === r.expect }; },
  links_denied: (L, r) => { const am = new Map(L.agents.map(a => [a.id, a])); let n = 0; for (const l of L.links) { const f = am.get(l.from), t = am.get(l.to); if (!f || !t) continue; for (const q of r.rules) if (selOk(q.from, f) && selOk(q.to, t)) { if (q.allow === false) n++; break; } } return { value: n, ok: n === r.expect }; }
};

AF.define({
  id: 'verifier', tier: 'lead', module: 'verify', purpose: 'Recompute every finding from the evidence alone. Reject what does not reproduce.',
  reads: ['frozen ledger', 'findings'], writes: ['verdicts'],
  fn: ({ ledger: L, findings }) => {
    const out = {};
    for (const f of findings) {
      if (!f.recheck) { out[f.id] = f.severity === 'info' ? { status: 'unverifiable', detail: 'informational, no number to recheck' } : { status: 'rejected', detail: 'no recheck supplied' }; continue; }
      const list = Array.isArray(f.recheck) ? f.recheck : [f.recheck];
      let ok = true, details = [];
      for (const r of list) {
        try {
          if (!RECHECK[r.kind]) { ok = false; details.push('unknown recheck ' + r.kind); continue; }
          const res = RECHECK[r.kind](L, r);
          const good = res.check ? res.check(r.expect) : res.ok;
          if (!good) ok = false;
          details.push(r.kind + ': recomputed ' + (typeof res.value === 'number' ? U.round(res.value, 6) : JSON.stringify(res.value)) + ' vs claimed ' + (typeof r.expect === 'number' ? U.round(r.expect, 6) : JSON.stringify(r.expect)));
        } catch (e) { ok = false; details.push('recheck error: ' + e.message); }
      }
      out[f.id] = { status: ok ? 'confirmed' : 'rejected', detail: details.join(' | ') };
    }
    return { verdicts: out };
  }
});

/* ========== beliefs: what an organisation tends to say, tested against what the records show ========== */

const SAY = { yes: 'We do this', no: 'We do not', unsure: 'Not sure' };
AF.BELIEFS = [
  { id: 'owner', text: 'Every agent has a named owner who is still here', worker: 'owner_chain' },
  { id: 'register', text: 'We have a complete register of our agents', worker: 'ai_inventory' },
  { id: 'gate', text: 'A person approves every irreversible action', worker: 'human_gate' },
  { id: 'review', text: 'Our reviewers actually catch mistakes', worker: 'human_gate' },
  { id: 'reconstruct', text: 'We can reconstruct what any agent did, and which version did it', worker: 'trace_integrity' },
  { id: 'access', text: 'Each agent has only the access it needs', worker: 'access_keys' },
  { id: 'control', text: 'We know what agents cost and the models in use are controlled', worker: 'model_register' },
  { id: 'case', text: 'Every agent has a business case and is paying back', worker: 'case_vs_actual' },
  { id: 'version', text: 'Agents run the version that was approved', worker: 'policy_drift' },
  { id: 'structure', text: 'Our agent structure fits our size and risk', worker: 'pyramid_review' },
  { id: 'links', text: 'Agent-to-agent communication follows our rules', worker: 'link_rules' }
];

AF.evalBeliefs = (R, confirmed, L, said) => {
  const wk = id => R[id] && (R[id].status === 'complete' || R[id].status === 'partial') ? R[id] : null;
  const why = id => { const r = R[id]; return !r ? 'not run' : r.status === 'not selected' ? 'not selected for this run' : (r.reason || r.status); };
  const hasF = (w, fn) => (confirmed[w] || []).some(fn);
  const T = { yes: 'supported', no: 'not supported', cannot: 'cannot tell' };
  const res = {};
  const set = (id, v, reason, refs) => { res[id] = { verdict: v, reason, refs: refs || [] }; };
  let w;
  w = wk('owner_chain'); if (!w) set('owner', T.cannot, 'Owner check ' + why('owner_chain') + '.');
  else if (w.metrics.no_owner || w.metrics.owner_left) set('owner', T.no, w.metrics.no_owner + ' agents have no owner and ' + w.metrics.owner_left + ' have an owner who has left.', ['owner_chain']);
  else if (!L.peopleKnown) set('owner', T.cannot, 'Every agent has an owner on paper. Without a staff list the tool cannot tell if they are still here.', ['owner_chain']);
  else set('owner', T.yes, 'All ' + w.metrics.total + ' agents have a named owner who is still here.', ['owner_chain']);

  w = wk('ai_inventory'); if (!w) set('register', T.cannot, 'Inventory check ' + why('ai_inventory') + '.');
  else if (w.metrics.shadow) set('register', T.no, w.metrics.shadow + ' agent(s) are running that no register lists.', ['ai_inventory']);
  else if (!L.runs.length) set('register', T.cannot, 'Without activity records the tool cannot find agents missing from the register.', ['ai_inventory']);
  else set('register', T.yes, 'Every agent seen in activity is on a register. Agents outside all your sources would still be invisible here.', ['ai_inventory']);

  w = wk('human_gate'); if (!w) { set('gate', T.cannot, 'Human gate check ' + why('human_gate') + '.'); set('review', T.cannot, 'Human gate check ' + why('human_gate') + '.'); }
  else {
    const m = w.metrics;
    if (!m.irreversible) set('gate', T.cannot, 'No irreversible actions found in the records, or they are not recorded as such.', ['human_gate']);
    else if (m.unapproved) set('gate', T.no, m.unapproved + ' of ' + m.irreversible + ' irreversible actions have no approval record.', ['human_gate']);
    else set('gate', T.yes, 'All ' + m.irreversible + ' irreversible actions carry an approval record.', ['human_gate']);
    if (m.drill && m.drill.planted_seen >= 10) set('review', m.drill.catch_rate >= 0.7 ? T.yes : T.no, 'In the drill reviewers caught ' + m.drill.caught + ' of ' + m.drill.planted_seen + ' planted errors.', ['human_gate']);
    else if (m.timed >= 30 && (m.fast_share >= L.policy.fastShareFlag * 100 || hasF('human_gate', f => /approved .* in under/.test(f.title)))) set('review', T.no, 'Many approvals are near-instant. That is a signal, not proof. Run the seeded-error drill for a direct answer.', ['human_gate']);
    else set('review', T.cannot, 'Only a seeded-error drill can show whether mistakes are caught. Approval speed alone cannot.', ['human_gate']);
  }

  w = wk('trace_integrity'); if (!w) set('reconstruct', T.cannot, 'Trace check ' + why('trace_integrity') + '.');
  else { const m = w.metrics, irrBad = m.irreversible_without_version || 0, lo = Math.min(m.with_trace, m.with_version);
    if (irrBad) set('reconstruct', T.no, irrBad + ' irreversible actions cannot be tied to an agent version.', ['trace_integrity']);
    else set('reconstruct', lo >= 95 ? T.yes : lo < 70 ? T.no : T.cannot, m.with_trace + '% of runs have a trace id and ' + m.with_version + '% record the version.', ['trace_integrity']); }

  w = wk('access_keys'); if (!w) set('access', T.cannot, 'Access check ' + why('access_keys') + '.');
  else if ((confirmed.access_keys || []).some(f => f.severity === 'high') || (w.metrics.declared_tools && w.metrics.unused_tools / w.metrics.declared_tools >= 0.3)) set('access', T.no, 'Shared or ownerless credentials, idle agents with live keys, or a large share of unused access.', ['access_keys']);
  else if (w.metrics.declared_tools == null) set('access', T.cannot, 'Not enough activity history to say which access is unused.', ['access_keys']);
  else set('access', T.yes, 'No shared credentials or idle live keys found, and most declared access is used.', ['access_keys']);

  const mr = wk('model_register'), pc = wk('price_check');
  if (!mr || !L.runs.length) set('control', T.cannot, 'Model register check ' + (mr ? 'needs activity records' : why('model_register')) + '.');
  else if (hasF('model_register', f => /not approved|retired|already retired/.test(f.title)) || (pc && hasF('price_check', f => /old|missing from the price table/.test(f.title)))) set('control', T.no, 'Models outside the approved list, models near retirement, or an out-of-date or incomplete price table.', ['model_register', 'price_check']);
  else if (!mr.metrics.approved_list) set('control', T.cannot, 'No approved-model list was supplied, so "controlled" cannot be tested.', ['model_register']);
  else set('control', T.yes, 'Models in use match the approved list and the price table is current.', ['model_register']);

  w = wk('case_vs_actual'); if (!w) set('case', T.cannot, 'Business case check ' + why('case_vs_actual') + '.');
  else {
    const rows = w.metrics.rows, behind = rows.filter(r => r.verdict === 'behind').length, ct = rows.filter(r => r.verdict === 'cannot_tell').length;
    if (w.metrics.without_case) set('case', T.no, w.metrics.without_case + ' agents have no business case' + (behind ? ' and ' + behind + ' case(s) are behind' : '') + '.', ['case_vs_actual']);
    else if (behind) set('case', T.no, behind + ' of ' + rows.length + ' business cases are behind.', ['case_vs_actual']);
    else if (!rows.length || ct) set('case', T.cannot, ct + ' case(s) cannot be judged because benefit has not been measured.', ['case_vs_actual']);
    else set('case', T.yes, 'All ' + rows.length + ' cases are on track on the figures given.', ['case_vs_actual']);
  }

  w = wk('policy_drift'); if (!w) set('version', T.cannot, 'Version check ' + why('policy_drift') + '.');
  else if (!w.metrics.with_approved_version) set('version', T.cannot, 'No approved versions were supplied.', ['policy_drift']);
  else if (w.metrics.drifted || hasF('policy_drift', f => /not approved/.test(f.title))) set('version', T.no, w.metrics.drifted + ' agent(s) run a version other than the approved one.', ['policy_drift']);
  else set('version', T.yes, 'Running versions match the approved ones for the ' + w.metrics.with_approved_version + ' agents that have an approved version on record.', ['policy_drift']);

  w = wk('pyramid_review'); if (!w) set('structure', T.cannot, 'Structure check ' + why('pyramid_review') + '.');
  else if ((confirmed.pyramid_review || []).some(f => f.severity !== 'low')) set('structure', T.no, 'The hierarchy breaks your limits or leaves workers unsupervised.', ['pyramid_review']);
  else if (!w.metrics.band) set('structure', T.cannot, 'Organisation size and sector were not given, so fit to size cannot be judged.', ['pyramid_review']);
  else set('structure', T.yes, 'No structural limits broken. Fit to size is Antara guidance, a heuristic.', ['pyramid_review']);

  w = wk('link_rules'); if (!w) set('links', T.cannot, 'Link check ' + why('link_rules') + '.');
  else if (w.metrics.observed_only || hasF('link_rules', f => /forbid/.test(f.title))) set('links', T.no, w.metrics.observed_only + ' link(s) in use were never declared' + (hasF('link_rules', f => /forbid/.test(f.title)) ? ', and some break your rules' : '') + '.', ['link_rules']);
  else if (!w.metrics.rules) set('links', T.cannot, 'No link rules were supplied, so only undeclared links could be checked, and none were found.', ['link_rules']);
  else set('links', T.yes, 'Links in use are declared and follow your rules.', ['link_rules']);

  return AF.BELIEFS.map(b => Object.assign({}, b, res[b.id], { said: (said && said[b.id]) || 'unasked', gap: !!(said && said[b.id] === 'yes' && res[b.id].verdict === 'not supported') }));
};

/* ========== report writer ========== */

const SEV = { high: 3, medium: 2, low: 1, info: 0 };
const CSS = `:root{--bg:#fbfaf7;--fg:#1d1d1b;--mut:#6a6a64;--line:#dedbd2;--card:#fff;--hi:#b3261e;--me:#9a6700;--lo:#2d6a4f;--in:#51606d;--acc:#1f3a5f}
@media(prefers-color-scheme:dark){:root{--bg:#141413;--fg:#ecebe6;--mut:#a3a29a;--line:#33332f;--card:#1c1c1a;--hi:#ff8a80;--me:#e5b84d;--lo:#7fd1a3;--in:#9fb0bf;--acc:#9ec1ee}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.55 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.w{max-width:1040px;margin:0 auto;padding:28px 18px 80px}h1{font-size:26px;margin:0 0 4px}h2{font-size:19px;margin:34px 0 10px;border-bottom:1px solid var(--line);padding-bottom:6px}h3{font-size:15.5px;margin:18px 0 6px}
.mut{color:var(--mut)}.small{font-size:13px}table{border-collapse:collapse;width:100%;font-size:13.5px;margin:8px 0}th,td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top}th{color:var(--mut);font-weight:600}
.kpis{display:flex;flex-wrap:wrap;gap:10px;margin:14px 0}.kpi{flex:1 1 150px;background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px}.kpi b{display:block;font-size:22px}
.f{background:var(--card);border:1px solid var(--line);border-left-width:4px;border-radius:8px;padding:10px 14px;margin:10px 0}.f.high{border-left-color:var(--hi)}.f.medium{border-left-color:var(--me)}.f.low{border-left-color:var(--lo)}.f.info{border-left-color:var(--in)}
.f h4{margin:0 0 4px;font-size:15px}.chip{display:inline-block;font-size:11.5px;border:1px solid var(--line);border-radius:99px;padding:0 8px;margin-right:6px;color:var(--mut)}.chip.hi{color:var(--hi);border-color:var(--hi)}.chip.me{color:var(--me);border-color:var(--me)}.chip.ok{color:var(--lo);border-color:var(--lo)}
.v-supported{color:var(--lo);font-weight:600}.v-not{color:var(--hi);font-weight:600}.v-cant{color:var(--me);font-weight:600}.gap{background:rgba(179,38,30,.08)}
.lab{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--mut)}code{font:12.5px ui-monospace,Menlo,Consolas,monospace;word-break:break-all}.box{border:1px solid var(--line);border-radius:8px;padding:10px 14px;background:var(--card)}
@media print{body{background:#fff;color:#000}.f,.kpi,.box{break-inside:avoid}}`;

const sevChip = s => '<span class="chip ' + (s === 'high' ? 'hi' : s === 'medium' ? 'me' : '') + '">' + s + '</span>';
const vcls = v => v === 'supported' ? 'v-supported' : v === 'not supported' ? 'v-not' : 'v-cant';
const fmt = v => typeof v === 'number' ? (Number.isInteger(v) ? String(v) : String(U.round(v, 4))) : v == null ? '' : typeof v === 'object' ? esc(JSON.stringify(v)) : esc(v);
function metricsHtml(m) {
  if (!m) return '';
  let h = '';
  const scal = Object.keys(m).filter(k => !Array.isArray(m[k]) && (m[k] == null || typeof m[k] !== 'object'));
  if (scal.length) h += '<p class="small mut">' + scal.map(k => esc(k.replace(/_/g, ' ')) + ': <b>' + fmt(m[k]) + '</b>').join(' &nbsp;·&nbsp; ') + '</p>';
  for (const k of Object.keys(m)) if (Array.isArray(m[k]) && m[k].length && typeof m[k][0] === 'object') {
    const cols = Object.keys(m[k][0]).filter(c => typeof m[k][0][c] !== 'object' || m[k][0][c] === null);
    h += '<div class="lab">' + esc(k.replace(/_/g, ' ')) + '</div><table><tr>' + cols.map(c => '<th>' + esc(c.replace(/_/g, ' ')) + '</th>').join('') + '</tr>' + m[k].slice(0, 12).map(r => '<tr>' + cols.map(c => '<td>' + fmt(r[c]) + '</td>').join('') + '</tr>').join('') + '</table>';
  }
  return h;
}

AF.define({
  id: 'writer', tier: 'lead', module: 'report', purpose: 'Turn verified results into a report. No model writes any sentence; wording is fixed templates plus the numbers.',
  reads: ['verified results'], writes: ['report'],
  fn: ({ ledger: L, results, verdicts, said, meta, modules }) => {
    const all = [];
    for (const m of Object.keys(results)) for (const w of Object.keys(results[m].workers)) for (const f of results[m].workers[w].findings) all.push(f);
    const conf = all.filter(f => verdicts[f.id].status === 'confirmed' || verdicts[f.id].status === 'unverifiable'), rej = all.filter(f => verdicts[f.id].status === 'rejected');
    const confirmed = {}; for (const f of conf) (confirmed[f.worker] = confirmed[f.worker] || []).push(f);
    const R = {}; for (const m of Object.keys(results)) Object.assign(R, results[m].workers);
    const beliefs = AF.evalBeliefs(R, confirmed, L, said);
    const sc = s => conf.filter(f => f.severity === s).length;
    const reqs = []; const seen = new Set();
    for (const m of Object.keys(results)) for (const r of results[m].requests) { const k = r.key + '|' + r.why; if (!seen.has(k)) { seen.add(k); reqs.push(Object.assign({ workers: [r.worker] }, r)); } else reqs.find(x => x.key + '|' + x.why === k).workers.push(r.worker); }
    reqs.sort((a, b) => (b.critical ? 1 : 0) - (a.critical ? 1 : 0));
    const nGap = beliefs.filter(b => b.gap).length;
    let h = '<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(AF.NAME) + ' report</title><style>' + CSS + '</style></head><body><div class="w">';
    h += '<div class="lab">' + esc(AF.NAME) + ' · ' + esc(AF.NAME_NOTE) + ' · version ' + AF.VERSION + '</div><h1>' + esc((L.org && L.org.name) || 'Agent estate') + ': what you believe against what the records show</h1>';
    h += '<p class="mut">Evidence as of ' + (L.asOf != null ? U.iso(L.asOf) : 'unknown date') + ' · ' + L.agents.filter(a => !a.stub).length + ' agents · ' + L.runs.length + ' recorded runs' + (L.window.days ? ' over ' + Math.round(L.window.days) + ' days' : '') + ' · scope: ' + ((meta && meta.evidenceOnly) ? 'evidence summary only, no checks run' : (meta && meta.scope ? meta.scope.map(x => AF.MODULES[x.module].label + (x.checks.length < x.total ? ' (' + x.checks.length + ' of ' + x.total + ' checks: ' + x.checks.map(c => c.replace(/_/g, ' ')).join(', ') + ')' : ' (all ' + x.total + ' checks)')).join('; ') : modules.map(m => AF.MODULES[m].label).join(', '))) + '</p>';
    if (meta && meta.sample) h += '<div class="box"><b>Synthetic sample.</b> Every name, number and price in this report is invented to show how the tool works. Nothing here describes a real organisation.</div>';
    h += '<div class="kpis"><div class="kpi"><b>' + conf.filter(f => f.severity !== 'info').length + '</b>verified findings (' + sc('high') + ' high, ' + sc('medium') + ' medium, ' + sc('low') + ' low)</div><div class="kpi"><b>' + nGap + '</b>belief gaps (you said yes, records say no)</div><div class="kpi"><b>' + beliefs.filter(b => b.verdict === 'cannot tell').length + '</b>beliefs the evidence cannot settle</div><div class="kpi"><b>' + rej.length + '</b>findings rejected by the verifier</div><div class="kpi"><b>' + reqs.filter(r => r.critical).length + '</b>pieces of evidence needed to finish</div></div>';

    h += '<h2>1. Belief against evidence</h2><p class="small mut">Each row is something organisations commonly say. "You said" is what was ticked before the run. The right-hand column is what the records show. <b>Cannot tell</b> is a result, not a gap in the report: it means the records you gave cannot settle it.</p>';
    h += '<table><tr><th>Statement</th><th>You said</th><th>Evidence says</th><th>Why</th></tr>' + beliefs.map(b => '<tr class="' + (b.gap ? 'gap' : '') + '"><td>' + esc(b.text) + '</td><td>' + esc(SAY[b.said] || 'not asked') + '</td><td class="' + vcls(b.verdict) + '">' + esc(b.verdict) + (b.gap ? ' ⚠' : '') + '</td><td class="small">' + esc(b.reason) + '</td></tr>').join('') + '</table>';

    for (const m of modules) {
      const mr = results[m]; if (!mr) continue;
      h += '<h2>' + AF.MODULES[m].label + '</h2><p class="mut small">' + esc(AF.MODULES[m].blurb) + '</p>';
      h += '<table><tr><th>Check</th><th>Status</th><th>Verified findings</th></tr>' + Object.keys(mr.workers).map(w => { const x = mr.workers[w]; return '<tr><td>' + esc(w.replace(/_/g, ' ')) + '<div class="small mut">' + esc(AF.REG[w].purpose) + '</div></td><td>' + esc(x.status) + (x.reason ? '<div class="small mut">' + esc(x.reason) + '</div>' : '') + '</td><td>' + conf.filter(f => f.worker === w && f.severity !== 'info').length + '</td></tr>'; }).join('') + '</table>';
      for (const w of Object.keys(mr.workers)) {
        const x = mr.workers[w]; if (x.status === 'not selected') continue;
        const fs = conf.filter(f => f.worker === w).sort((a, b) => SEV[b.severity] - SEV[a.severity]);
        if (!fs.length && !Object.keys(x.metrics || {}).length) continue;
        h += '<h3>' + esc(w.replace(/_/g, ' ')) + '</h3>';
        for (const f of fs) h += '<div class="f ' + f.severity + '"><h4>' + esc(f.title) + '</h4>' + sevChip(f.severity) + '<span class="chip">' + esc(f.basis) + '</span>' + (verdicts[f.id].status === 'confirmed' ? '<span class="chip ok">recomputed by verifier</span>' : '<span class="chip">informational</span>') +
          '<p>' + esc(f.claim) + '</p><p class="small"><b>Why it matters.</b> ' + esc(f.why) + '</p><p class="small"><b>What to do.</b> ' + esc(f.fix) + '</p>' + (f.evidence.length ? '<p class="small mut">Evidence: ' + f.evidence.slice(0, 8).map(e => esc(e.t + ' ' + e.id)).join(', ') + (f.evidence.length > 8 ? ', …' : '') + '</p>' : '') + '</div>';
        h += metricsHtml(x.metrics);
      }
    }

    if (rej.length) h += '<h2>Findings the verifier rejected</h2><p class="small mut">A worker made a claim and the independent recheck did not reproduce it. These are kept visible on purpose, and are left out of every count above.</p><table><tr><th>Worker</th><th>Claim</th><th>Recheck</th></tr>' + rej.map(f => '<tr><td>' + esc(f.worker) + '</td><td>' + esc(f.title) + '</td><td class="small">' + esc(verdicts[f.id].detail) + '</td></tr>').join('') + '</table>';

    h += '<h2>Evidence needed to finish the picture</h2>';
    if (!reqs.length) h += '<p>Nothing further is needed for the checks that were run.</p>';
    else h += '<p class="small mut">These are the things the tool could not find. Each one blocks or weakens the checks listed. Providing them turns "cannot tell" into an answer.</p><table><tr><th></th><th>What is missing</th><th>How to provide it</th><th>Affects</th></tr>' + reqs.map(r => '<tr><td>' + (r.critical ? '<span class="chip hi">blocks</span>' : '<span class="chip me">weakens</span>') + '</td><td>' + esc(r.why) + '</td><td class="small">' + esc(r.hint) + '</td><td class="small">' + esc(U.uniq(r.workers).join(', ').replace(/_/g, ' ')) + '</td></tr>').join('') + '</table>';

    h += '<h2>How this report was made, and what it cannot see</h2><div class="box small">' +
      '<p><b>No AI model wrote or scored anything here.</b> The agents named below are code modules in this one file, arranged as orchestrator, workers and task agents. Every number is arithmetic on the records you supplied. Every sentence is a fixed template filled with those numbers.</p>' +
      '<p><b>Verification.</b> Each finding carries a declarative recheck. A separate verifier recomputes it from the same records using its own small query engine and rejects what does not match. It catches logic errors in the checks. It does not catch errors in how the files were read, because both share that step.</p>' +
      '<p><b>Limits.</b> The tool sees only what you gave it. Agents and links outside those files are invisible. Facts marked <i>declared</i> come from a person or a document and are not independently confirmed. Facts marked <i>inferred</i> are judgements from patterns (for example which tools are irreversible, or which agents overlap) and need a person to confirm. Sector and structure guidance is Antara\'s heuristic reading, not legal advice and not a standard. Business-case benefit is only as good as the outcome figures supplied.</p>' +
      '<p><b>Self-governance.</b> The tool applies its own rules to itself: read-only authority for every agent, calls only one tier down, depth cap ' + AF.HARD_DEPTH + ', fan-out cap ' + AF.HARD_FANOUT + ', a hard call budget, and a hash-chained log of every call. Chain head when this report was written: <code>' + esc(meta.head) + '</code> after ' + meta.calls + ' calls.</p></div>';
    h += '<h3>Evidence received</h3><table><tr><th>File</th><th>Read as</th><th>Records</th><th>How known</th><th>SHA-256</th></tr>' + L.sources.map(s => '<tr><td>' + esc(s.name) + '</td><td>' + esc(s.kind) + (s.note ? '<div class="small mut">' + esc(s.note) + '</div>' : '') + '</td><td>' + s.records + '</td><td>' + esc(s.evidence) + '</td><td><code>' + esc(s.hash.slice(0, 16)) + '…</code></td></tr>').join('') + '</table>';
    h += '<p class="small mut">Agents that made up this run: ' + Object.values(AF.REG).filter(a => a.tier !== 'supervisor').map(a => esc(a.id) + ' (' + a.tier + ')').join(', ') + '.</p></div></body></html>';
    return { html: h, beliefs, counts: { high: sc('high'), medium: sc('medium'), low: sc('low'), rejected: rej.length, gaps: nGap, requests: reqs.length }, requests: reqs };
  }
});

/* ========== seeded-error drill ========== */

AF.drill = {
  generate: (L, o) => {
    o = o || {}; const n = o.n || 20, rate = o.errorRate == null ? 0.3 : o.errorRate, rnd = U.prng(o.seed || 7);
    const combos = []; const seen = new Set();
    for (const r of L.runs) if (r.irreversible && r.tool && r.agent && !seen.has(r.agent + '/' + r.tool)) { seen.add(r.agent + '/' + r.tool); combos.push({ agent: r.agent, tool: r.tool }); }
    if (!combos.length) combos.push({ agent: 'example-agent', tool: 'issue_refund' }, { agent: 'example-agent', tool: 'send_email' }, { agent: 'example-agent', tool: 'update_record' });
    const pick = a => a[Math.floor(rnd() * a.length)], int = (lo, hi) => lo + Math.floor(rnd() * (hi - lo + 1));
    const items = [], key = [];
    for (let i = 0; i < n; i++) {
      const c = pick(combos), planted = rnd() < rate, id = 'D-' + String(i + 1).padStart(3, '0');
      let text, kind = null;
      if (/(refund|pay|payment|transfer|invoice|approve)/i.test(c.tool)) {
        const T = int(120, 900), lim = 500, okR = int(20, Math.min(T, lim) - 10);
        if (!planted) text = 'Request to ' + c.tool + ': £' + okR + ' on an order of £' + T + '. Approval limit £' + lim + '. Customer verified by order number.';
        else { kind = pick(['over_total', 'over_limit', 'unverified', 'duplicate']); text = kind === 'over_total' ? 'Request to ' + c.tool + ': £' + (T + int(40, 200)) + ' on an order of £' + T + '. Approval limit £' + lim + '. Customer verified by order number.' : kind === 'over_limit' ? 'Request to ' + c.tool + ': £' + (lim + int(100, 900)) + ' on an order of £' + (lim + 1500) + '. Approval limit £' + lim + '. Customer verified by order number.' : kind === 'unverified' ? 'Request to ' + c.tool + ': £' + okR + ' on an order of £' + T + '. Approval limit £' + lim + '. Customer NOT verified: email address does not match the account.' : 'Request to ' + c.tool + ': £' + okR + ' on an order of £' + T + '. Approval limit £' + lim + '. Customer verified. The same amount was refunded on this order two days ago.'; }
      } else if (/(send|email|publish|post|reply)/i.test(c.tool)) {
        if (!planted) text = 'Request to ' + c.tool + ': reply to the customer who wrote in, from their own address. Draft contains order status only.';
        else { kind = pick(['wrong_recipient', 'internal_notes', 'bulk']); text = kind === 'wrong_recipient' ? 'Request to ' + c.tool + ': reply to a customer. The draft quotes order details that belong to a different customer.' : kind === 'internal_notes' ? 'Request to ' + c.tool + ': reply to the customer from their own address. The draft includes the internal note "customer likely to churn, offer 30% if pushed".' : 'Request to ' + c.tool + ': one draft to ' + int(300, 900) + ' recipients taken from the full customer list instead of the one thread.'; }
      } else {
        if (!planted) text = 'Request to ' + c.tool + ': change 1 record in this team\'s own queue to "closed", after the handler confirmed it.';
        else { kind = pick(['bulk', 'wrong_scope', 'no_confirmation']); text = kind === 'bulk' ? 'Request to ' + c.tool + ': change ' + int(2000, 5000) + ' records to "closed" in one go.' : kind === 'wrong_scope' ? 'Request to ' + c.tool + ': change 1 record to "closed". The record belongs to a different department.' : 'Request to ' + c.tool + ': change 1 record to "closed". No handler confirmation is attached.'; }
      }
      items.push({ id, agent: c.agent, action: c.tool, text }); key.push({ id, planted, kind });
    }
    const csv = 'item_id,agent,action,request\n' + items.map(x => [x.id, x.agent, x.action, '"' + x.text.replace(/"/g, '""') + '"'].join(',')).join('\n') + '\n';
    return { items, key, csv, keyJson: JSON.stringify({ version: 1, note: 'SYNTHETIC drill. Keep this key away from reviewers.', items, key }, null, 1), responseTemplate: 'item_id,reviewer,decision,seconds\n' + items.map(x => x.id + ',,,').join('\n') + '\n' };
  }
};
/* scoring reads the key list */
const _score = AF.scoreDrill;
AF.scoreDrill = (keyDoc, resp) => _score({ items: (keyDoc.key || keyDoc.items) }, resp);

/* ========== supervisor ========== */

AF.define({ id: 'supervisor', tier: 'supervisor', module: 'core', purpose: 'Plan the run, enforce limits, collect results.', may_call: ['intake', 'discover_lead', 'secure_lead', 'govern_lead', 'economics_lead', 'verifier', 'writer'] });

AF.run = (input) => {
  input = input || {};
  const prob = AF.checkRegistry(); if (prob.length) throw new Error('registry invalid: ' + prob.join('; '));
  const gate = new AF.Gate(input.caps);
  const modules = input.evidenceOnly ? [] : (input.modules && input.modules.length ? input.modules : Object.keys(AF.MODULES)).filter(m => AF.MODULES[m]);
  const ordered = Object.keys(AF.MODULES).filter(m => modules.includes(m));
  const intake = gate.call('supervisor', 'intake', { files: input.files || [], overrides: input.overrides || {} });
  if (!intake || intake.error) throw new Error('intake failed: ' + (intake && intake.error));
  const L = U.deepFreeze(intake.ledger);
  const results = {}, findings = [];
  for (const m of ordered) {
    const r = gate.call('supervisor', m + '_lead', { ledger: L, workers: input.workers && input.workers[m], params: input.params || {} });
    if (r.error) throw new Error(m + ' lead failed: ' + r.error);
    results[m] = r;
    for (const w of Object.keys(r.workers)) findings.push(...r.workers[w].findings);
  }
  const ver = gate.call('supervisor', 'verifier', { ledger: L, findings });
  const scope = ordered.map(m => { const all = AF.MODULES[m].workers, pick = (input.workers && input.workers[m] && input.workers[m].length) ? input.workers[m].filter(w => all.includes(w)) : all; return { module: m, checks: pick, total: all.length }; });
  const meta = { head: gate.prev, calls: gate.calls, sample: !!input.sample, scope, evidenceOnly: !!input.evidenceOnly };
  const rep = gate.call('supervisor', 'writer', { ledger: L, results, verdicts: ver.verdicts, said: input.said || {}, meta, modules: ordered });
  return { ledger: L, results, verdicts: ver.verdicts, findings, beliefs: rep.beliefs, counts: rep.counts, requests: rep.requests, html: rep.html, trace: gate.trace, denied: gate.denied, head: gate.prev, calls: gate.calls, modules: ordered };
};

AF.exportJson = run => JSON.stringify({
  product: AF.NAME + ' (' + AF.NAME_NOTE + ')', version: AF.VERSION, head: run.head, calls: run.calls, modules: run.modules,
  counts: run.counts, beliefs: run.beliefs.map(b => ({ id: b.id, text: b.text, said: b.said, verdict: b.verdict, reason: b.reason })),
  findings: run.findings.map(f => Object.assign({}, f, { verification: run.verdicts[f.id] })), requests: run.requests,
  sources: run.ledger.sources, chain: run.trace
}, null, 1);

})(AF);

/* ---- sample.js ---- */
(function(AF){
/* Synthetic sample: an invented organisation with known problems planted, so the tool can be shown and tested.
   Nothing here is real. Model names and prices are made up. */
'use strict';
const U = AF.U;

AF.sample = {
  planted: [
    'shadow agent ops-scratch-bot runs and sends email with no register entry',
    'claims-updater declares demo-mid-1 but runs demo-large-1',
    'claims-updater runs version 1.4, approved 1.2',
    'demo-legacy-0 retires within 90 days and 3 agents use it',
    'support-refund-agent: about 6% of refunds have no approval record',
    'reviewer sam approves most refunds in under 2 seconds',
    'marketing-reply-writer: public input, sends email, no approvals, owner has left, orphan, not approved',
    'bank-api-prod credential shared by three agents',
    'zombie-forecaster idle for about 70 days and holds bank-api-prod, owner has left',
    'old-lead-scorer registered, never seen, holds a live credential',
    'chain of 4 hops from finance-orchestrator to pdf-signer',
    'ops-scratch-bot and marketing-reply-writer log no version or trace id on irreversible actions',
    'claims-triage (public input) reaches invoice-approver through an undeclared link',
    'invoice-approver calls finance-orchestrator (worker to orchestrator forbidden, creates a loop)',
    'kyc-checker links to an external supplier agent',
    'support-reply-writer and marketing-reply-writer do the same job',
    'claims-summariser: simple job on a large model, volume far below its case, cost per run far above',
    'kyc-checker: complex job on a small model with high retry rate',
    'claims-updater cost per run rises over the window',
    'data-cleaner and kyc-checker use models not approved for high risk',
    'invoice-approver and most others have no business case',
    'notetaker duplicates in expenses (otter, fireflies)'
  ],
  build: () => {
    const rnd = U.prng(20261031);
    const pick = a => a[Math.floor(rnd() * a.length)];
    const gauss = () => { let u = 0, v = 0; while (u === 0) u = rnd(); while (v === 0) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
    const START = Date.UTC(2026, 7, 2), DAYS = 90, ASOF = '2026-10-31';
    const nm = id => id.replace(/-/g, ' ').replace(/^./, c => c.toUpperCase());
    const A = (id, o) => Object.assign({ id, name: nm(id), tier: 'worker', status: 'active', complexity: 'standard', risk: 'medium', validated_at: '2026-06-05', known_security: true, approved: true }, o);
    const agents = [
      A('claims-orchestrator', { tier: 'orchestrator', dept: 'Claims', owner: 'Priya Nair', model: 'demo-large-1', tools: ['route_case'], version: '2.0', approved_version: '2.0', risk: 'high', purpose: 'route incoming claims to the right specialist agent' }),
      A('finance-orchestrator', { tier: 'orchestrator', dept: 'Finance', owner: 'Dev Patel', model: 'demo-large-1', tools: ['route_case'], version: '2.1', approved_version: '2.1', risk: 'high', purpose: 'coordinate month end finance tasks' }),
      A('support-orchestrator', { tier: 'orchestrator', dept: 'Customer Service', owner: 'Maya Ortiz', model: 'demo-large-1', tools: ['route_case'], version: '1.3', approved_version: '1.3', purpose: 'route customer enquiries to specialist agents' }),
      A('claims-triage', { parent: 'claims-orchestrator', dept: 'Claims', owner: 'Priya Nair', model: 'demo-mid-1', tools: ['read_email', 'search_claims'], inputs: 'public', version: '1.0', approved_version: '1.0', risk: 'high', credentials: ['crm-reader'], purpose: 'read incoming claim emails and sort by urgency' }),
      A('claims-updater', { parent: 'claims-orchestrator', dept: 'Claims', owner: 'Priya Nair', model: 'demo-mid-1', tools: ['update_claim', 'send_email', 'delete_draft'], version: '1.4', approved_version: '1.2', risk: 'high', credentials: ['crm-admin', 'mail-send'], purpose: 'update claim records and send decisions to claimants' }),
      A('claims-summariser', { parent: 'claims-orchestrator', dept: 'Claims', owner: 'Priya Nair', model: 'demo-large-1', tools: ['read_file'], version: '1.0', approved_version: '1.0', risk: 'low', complexity: 'simple', purpose: 'summarise claim documents for case handlers' }),
      A('kyc-checker', { parent: 'claims-orchestrator', dept: 'Claims', owner: 'Priya Nair', model: 'demo-small-1', tools: ['fetch_registry', 'search_web'], version: '1.0', approved_version: '1.0', risk: 'high', complexity: 'complex', purpose: 'check customer identity against external registries' }),
      A('invoice-approver', { parent: 'finance-orchestrator', dept: 'Finance', owner: 'Dev Patel', model: 'demo-large-1', tools: ['read_invoice', 'approve_payment'], version: '3.0', approved_version: '3.0', risk: 'high', credentials: ['bank-api-prod'], purpose: 'check supplier invoices against orders and approve payment' }),
      A('invoice-summariser', { parent: 'finance-orchestrator', dept: 'Finance', owner: 'Dev Patel', model: 'demo-mid-1', tools: ['read_invoice'], version: '1.0', approved_version: '1.0', risk: 'low', complexity: 'simple', purpose: 'summarise invoice documents for finance handlers' }),
      A('legacy-reporter', { parent: 'finance-orchestrator', dept: 'Finance', owner: 'Dev Patel', model: 'demo-legacy-0', tools: ['read_ledger'], version: '1.0', approved_version: '1.0', credentials: ['bank-api-prod'], purpose: 'compile monthly management reports' }),
      A('report-assembler', { tier: 'task', parent: 'legacy-reporter', dept: 'Finance', owner: 'Dev Patel', model: 'demo-legacy-0', tools: ['read_ledger'], version: '1.0', approved_version: '1.0', purpose: 'assemble report sections from ledger extracts' }),
      A('pdf-renderer', { tier: 'task', parent: 'report-assembler', dept: 'Finance', owner: 'Dev Patel', model: 'demo-mid-1', tools: [], version: '1.0', approved_version: '1.0', risk: 'low', complexity: 'simple', purpose: 'render finished report sections to a pdf file' }),
      A('pdf-signer', { tier: 'task', parent: 'pdf-renderer', dept: 'Finance', owner: 'Dev Patel', model: 'demo-mid-1', tools: ['sign_document'], version: '1.0', approved_version: '1.0', purpose: 'apply the company signature to released reports' }),
      A('data-cleaner', { parent: 'finance-orchestrator', dept: 'Finance', owner: 'Dev Patel', model: 'demo-legacy-0', tools: ['read_ledger', 'update_ledger'], version: '1.0', approved_version: '1.0', risk: 'high', credentials: ['ledger-write'], purpose: 'fix duplicate and malformed ledger entries' }),
      A('zombie-forecaster', { parent: 'finance-orchestrator', dept: 'Finance', owner: 'Tom Brandt', model: 'demo-mid-1', tools: ['read_ledger'], version: '0.9', approved_version: '0.9', credentials: ['bank-api-prod'], purpose: 'forecast quarterly cash position' }),
      A('support-refund-agent', { parent: 'support-orchestrator', dept: 'Customer Service', owner: 'Maya Ortiz', model: 'demo-large-1', tools: ['read_ticket', 'issue_refund'], inputs: 'public', version: '1.1', approved_version: '1.1', risk: 'high', credentials: ['stripe-prod'], purpose: 'check refund requests against policy and issue refunds' }),
      A('support-reply-writer', { parent: 'support-orchestrator', dept: 'Customer Service', owner: 'Maya Ortiz', model: 'demo-mid-1', tools: ['read_ticket', 'send_email'], version: '1.0', approved_version: '1.0', purpose: 'draft customer reply emails from enquiries' }),
      A('marketing-reply-writer', { dept: 'Marketing', owner: 'J Lee', platform: 'n8n', model: 'demo-mid-1', tools: ['read_enquiry', 'send_email'], inputs: 'public', version: '0.5', approved_version: null, known_security: false, approved: false, purpose: 'draft customer reply emails from enquiries' }),
      A('old-lead-scorer', { dept: 'Marketing', owner: 'J Lee', platform: 'n8n', model: 'demo-small-1', tools: ['read_crm'], credentials: ['crm-reader'], known_security: false, purpose: 'rank marketing leads by likelihood to buy' })
    ];
    const estate = {
      org: { name: 'Northgate Mutual (synthetic)', size: 180, sector: 'financial', domain: 'general', as_of: ASOF },
      agents,
      links: [{ from: 'kyc-checker', to: 'supplier-verify-agent', kind: 'calls', external: true }],
      tools: []
    };
    const prices = { as_of: '2026-10-15', source: 'SYNTHETIC SAMPLE, not real prices', currency: 'GBP per million tokens', models: { 'demo-large-1': { in: 10, out: 30, tier: 'large' }, 'demo-mid-1': { in: 3, out: 9, tier: 'mid' }, 'demo-small-1': { in: 0.5, out: 1.5, tier: 'small' }, 'demo-legacy-0': { in: 4, out: 12, tier: 'mid' } }, retire: { 'demo-legacy-0': '2027-01-20' } };
    const policy = { policy: { max_depth: 3, max_fanout: 8, irreversible_requires_approval: true, min_review_ms: 4000, mono_share: 0.45, max_price_age_days: 90, link_rules: [{ from: 'tier:worker', to: 'tier:orchestrator', allow: false }], approved_models: { low: ['demo-small-1', 'demo-mid-1', 'demo-large-1', 'demo-legacy-0'], medium: ['demo-mid-1', 'demo-large-1', 'demo-legacy-0'], high: ['demo-large-1', 'demo-mid-1'] }, monthly_budget: { 'claims-updater': 40 }, budget_owners: { Claims: 'Priya Nair', Finance: 'Dev Patel', 'Customer Service': 'Maya Ortiz' }, review_minutes_per_approval: 2, review_cost_per_hour: 45 } };
    const cases = { cases: [
      { id: 'case-triage', name: 'Claims triage', agent_ids: ['claims-triage'], claimed_benefit_per_month: 1200, assumed_runs_per_month: 300, assumed_cost_per_run: 0.02, payback_months: 6, start: '2026-02-01', owner: 'Priya Nair', build_cost: 2000, source: 'original' },
      { id: 'case-summariser', name: 'Claim summaries', agent_ids: ['claims-summariser'], claimed_benefit_per_month: 2500, assumed_runs_per_month: 400, assumed_cost_per_run: 0.01, payback_months: 6, start: '2026-03-01', owner: 'Priya Nair', build_cost: 3000, source: 'original' },
      { id: 'case-refunds', name: 'Automated refunds', agent_ids: ['support-refund-agent'], claimed_benefit_per_month: 1800, assumed_runs_per_month: 600, assumed_cost_per_run: 0.05, payback_months: 9, start: '2026-01-15', owner: 'Maya Ortiz', build_cost: 6000, source: 'reconstructed' }
    ] };
    const outcomes = { outcomes: [
      { case_id: 'case-triage', month: '2026-08', benefit: 1100 }, { case_id: 'case-triage', month: '2026-09', benefit: 1150 }, { case_id: 'case-triage', month: '2026-10', benefit: 1050 },
      { case_id: 'case-refunds', month: '2026-08', benefit: 380 }, { case_id: 'case-refunds', month: '2026-09', benefit: 410 }, { case_id: 'case-refunds', month: '2026-10', benefit: 395 }
    ] };
    const people = { people: [{ name: 'Priya Nair' }, { name: 'Dev Patel' }, { name: 'Maya Ortiz' }, { name: 'Tom Brandt', left: '2026-07-15' }, { name: 'J Lee', left: '2026-09-01' }] };

    /* ---------- runs ---------- */
    const runs = []; let sp = 0;
    const ago = d => d; // readability
    const byId = Object.fromEntries(agents.map(a => [a.id, a]));
    const TOK = { 'claims-orchestrator': [900, 200], 'finance-orchestrator': [900, 200], 'support-orchestrator': [800, 150], 'claims-triage': [1500, 200], 'claims-updater': [1800, 400], 'claims-summariser': [3000, 600], 'kyc-checker': [1200, 300], 'invoice-approver': [2200, 300], 'invoice-summariser': [1600, 250], 'legacy-reporter': [2500, 500], 'report-assembler': [1500, 400], 'pdf-renderer': [600, 100], 'pdf-signer': [300, 50], 'data-cleaner': [1400, 300], 'zombie-forecaster': [2000, 400], 'support-refund-agent': [1300, 200], 'support-reply-writer': [1000, 350], 'marketing-reply-writer': [900, 350], 'ops-scratch-bot': [500, 200], 'old-lead-scorer': [500, 100] };
    const MODEL_USED = { 'claims-updater': 'demo-large-1' }; // declared mid, runs large
    const VER_USED = { 'claims-updater': '1.4' };
    const APPR = { 'support-refund-agent': { p: 0.94, who: [['sam', 0.7, 1500], ['lena', 0.2, 16000], ['omar', 0.1, 22000]] }, 'invoice-approver': { p: 1, who: [['dev.patel', 0.6, 21000], ['fin.lead', 0.4, 18000]] }, 'claims-updater': { p: 1, who: [['priya', 0.7, 30000], ['assistant1', 0.3, 26000]] }, 'support-reply-writer': { p: 0.97, who: [['lena', 0.6, 14000], ['omar', 0.4, 12000]] }, 'data-cleaner': { p: 1, who: [['dev.patel', 1, 25000]] }, 'pdf-signer': { p: 1, who: [['dev.patel', 1, 20000]] }, 'marketing-reply-writer': { p: 0, who: [] }, 'ops-scratch-bot': { p: 0, who: [] } };
    const IRR_TOOL = { 'claims-updater': () => pick(['update_claim', 'send_email']), 'invoice-approver': () => 'approve_payment', 'support-refund-agent': () => 'issue_refund', 'support-reply-writer': () => 'send_email', 'data-cleaner': () => 'update_ledger', 'pdf-signer': () => 'sign_document', 'marketing-reply-writer': () => 'send_email', 'ops-scratch-bot': () => 'send_email' };
    const SAFE_TOOL = { 'claims-orchestrator': 'route_case', 'finance-orchestrator': 'route_case', 'support-orchestrator': 'route_case', 'claims-triage': () => pick(['read_email', 'search_claims']), 'claims-summariser': 'read_file', 'kyc-checker': () => pick(['fetch_registry', 'search_web']), 'invoice-summariser': 'read_invoice', 'legacy-reporter': 'read_ledger', 'report-assembler': 'read_ledger', 'pdf-renderer': 'render_pdf', 'zombie-forecaster': 'read_ledger', 'old-lead-scorer': 'read_crm' };
    const ts = (day, frac) => new Date(START + (day + frac) * 86400000).toISOString();
    const mk = (agent, day, trace, parentSpan, extra) => {
      const a = byId[agent] || { model: 'demo-small-1', version: '0.1' };
      const t = TOK[agent] || [800, 200];
      let k = 1; // cost drift for claims-updater in the last third
      if (agent === 'claims-updater' && day >= 60) k = 1.7;
      const inT = Math.max(50, Math.round((t[0] * k) * (1 + 0.25 * gauss()))), outT = Math.max(20, Math.round(t[1] * k * (1 + 0.25 * gauss())));
      const span = 'sp' + (++sp);
      let tool, irr = false;
      if (IRR_TOOL[agent] && (agent !== 'claims-updater' || rnd() < 0.9) && !(extra && extra.safe)) { tool = IRR_TOOL[agent](); irr = true; }
      else { const s = SAFE_TOOL[agent]; tool = typeof s === 'function' ? s() : (s || 'read_file'); }
      const r = { ts: ts(day, 0.3 + rnd() * 0.4), agent, model: MODEL_USED[agent] || a.model || 'demo-small-1', version: VER_USED[agent] || a.version || '1.0', in_tokens: inT, out_tokens: outT, outcome: 'ok', trace_id: trace, span_id: span, parent_span: parentSpan || undefined, tool };
      if (agent === 'kyc-checker') r.outcome = rnd() < 0.22 ? (rnd() < 0.5 ? 'retry' : 'error') : 'ok';
      else if (agent === 'claims-triage') r.outcome = rnd() < 0.03 ? 'error' : 'ok';
      else r.outcome = rnd() < 0.02 ? 'error' : 'ok';
      if (agent === 'support-reply-writer') r.input_hash = 'h' + Math.floor(rnd() * 40);
      if (irr) {
        const ap = APPR[agent];
        if (ap && rnd() < ap.p) {
          let x = rnd(), who = ap.who[0];
          for (const w of ap.who) { if (x < w[1]) { who = w; break; } x -= w[1]; }
          r.approved_by = who[0]; r.approval_ms = Math.max(400, Math.round(who[2] * (1 + 0.5 * gauss())));
        }
      }
      runs.push(r); return r;
    };
    const CHILD = {
      'claims-orchestrator': [['claims-triage', 0.5], ['claims-updater', 0.25], ['claims-summariser', 0.2], ['kyc-checker', 0.1]],
      'finance-orchestrator': [['invoice-approver', 0.3], ['invoice-summariser', 0.3], ['legacy-reporter', 0.2], ['data-cleaner', 0.2]],
      'support-orchestrator': [['support-refund-agent', 0.3], ['support-reply-writer', 0.7]]
    };
    const FLOWS = { 'claims-orchestrator': 20, 'finance-orchestrator': 8, 'support-orchestrator': 25 };
    for (let d = 0; d < DAYS; d++) {
      for (const o of Object.keys(FLOWS)) {
        const n = Math.max(0, Math.round(FLOWS[o] * (0.8 + rnd() * 0.4) * (new Date(START + d * 86400000).getUTCDay() % 6 === 0 ? 0.3 : 1)));
        for (let i = 0; i < n; i++) {
          const tr = 't' + d + '-' + o.slice(0, 3) + i;
          const root = mk(o, d, tr, null);
          const picks = rnd() < 0.5 ? 1 : 2; const chosen = new Set();
          for (let j = 0; j < picks; j++) { let x = rnd(), c = CHILD[o][0][0]; for (const q of CHILD[o]) { if (x < q[1]) { c = q[0]; break; } x -= q[1]; } chosen.add(c); }
          for (const c of chosen) {
            const cr = mk(c, d, tr, root.span_id);
            if (c === 'legacy-reporter') {
              const a1 = mk('report-assembler', d, tr, cr.span_id), a2 = mk('pdf-renderer', d, tr, a1.span_id); mk('pdf-signer', d, tr, a2.span_id);
            }
            if (c === 'claims-triage' && rnd() < 0.04) mk('invoice-approver', d, tr, cr.span_id);
            if (c === 'invoice-approver' && rnd() < 0.06) mk('finance-orchestrator', d, tr, cr.span_id, { safe: true });
          }
        }
      }
      if (d < 20) for (let i = 0; i < 2; i++) mk('zombie-forecaster', d, 'z' + d + '-' + i, null);
      const nm2 = Math.round(3 * (0.5 + rnd())); for (let i = 0; i < nm2; i++) mk('marketing-reply-writer', d, 'm' + d + '-' + i, null);
      if (rnd() < 0.5) mk('ops-scratch-bot', d, 'o' + d, null);
    }
    /* the shadow bot has no estate record: give it a version and model in runs */
    for (const r of runs) if (r.agent === 'ops-scratch-bot' || r.agent === 'marketing-reply-writer') { if (r.agent === 'ops-scratch-bot') r.model = 'demo-small-1'; delete r.version; delete r.trace_id; }
    runs.sort((a, b) => a.ts < b.ts ? -1 : 1);
    const expenses = 'Date,Cardholder,Department,Description,Amount,Payment method\n' + [
      ['04/09/2026', 'marketing1@northgate.example', 'Marketing', 'OPENAI *CHATGPT SUBSCR SAN FRANCISCO', '£20.00'],
      ['04/09/2026', 'marketing2@northgate.example', 'Marketing', 'OPENAI *CHATGPT SUBSCR SAN FRANCISCO', '£20.00'],
      ['05/09/2026', 'claims1@northgate.example', 'Claims', 'OTTER.AI PRO MONTHLY', '£16.99'],
      ['06/09/2026', 'marketing3@northgate.example', 'Marketing', 'FIREFLIES.AI BUSINESS', '£19.00'],
      ['06/09/2026', 'finance1@northgate.example', 'Finance', 'FIREFLIES.AI BUSINESS', '£19.00'],
      ['08/09/2026', 'finance2@northgate.example', 'Finance', 'GRAMMARLY PREMIUM', '£12.00']
    ].map(r => r.map(c => /,/.test(c) ? '"' + c + '"' : c).join(',') + ',Corporate card').join('\n') + '\n';
    const extensions = 'Extension,Users,Permissions,Department\nMerlin ChatGPT Assistant,2,Read and change all your data on all websites,Finance\nOtter.ai Meeting Notetaker,5,Read and change your data on meeting sites,Claims\nColorZilla,9,Read and change all your data on all websites,Marketing\n';
    const files = [
      { name: 'estate.json', text: JSON.stringify(estate) },
      { name: 'runs.jsonl', text: runs.map(r => JSON.stringify(r)).join('\n') },
      { name: 'prices.json', text: JSON.stringify(prices) },
      { name: 'policy.json', text: JSON.stringify(policy) },
      { name: 'cases.json', text: JSON.stringify(cases) },
      { name: 'outcomes.json', text: JSON.stringify(outcomes) },
      { name: 'people.json', text: JSON.stringify(people) },
      { name: 'expenses.csv', text: expenses },
      { name: 'extensions.csv', text: extensions }
    ];
    return { files, said: { owner: 'yes', register: 'yes', gate: 'yes', review: 'yes', reconstruct: 'yes', access: 'yes', control: 'yes', case: 'yes', version: 'yes', structure: 'yes', links: 'yes' } };
  }
};

})(AF);

module.exports = AF;
