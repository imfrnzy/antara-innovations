# Antara North Star agent installer for Windows.
# Run from an elevated PowerShell (or deploy through Intune as a script running as SYSTEM):
#   powershell -ExecutionPolicy Bypass -File install.ps1 -Token <enrolment-token>
param([Parameter(Mandatory=$true)][string]$Token)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$dest = if ($isAdmin) { Join-Path $env:ProgramFiles 'AntaraNorthStar' } else { Join-Path $env:LOCALAPPDATA 'AntaraNorthStar\agent' }
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item (Join-Path $here 'app\*.js') $dest -Force
$node = $null
$bundled = Join-Path $here 'runtime\win-x64\node.exe'
if (Test-Path $bundled) { Copy-Item $bundled (Join-Path $dest 'node.exe') -Force; $node = Join-Path $dest 'node.exe' }
else { $cmd = Get-Command node -ErrorAction SilentlyContinue; if ($cmd) { $node = $cmd.Source } }
if (-not $node) { Write-Error 'No Node.js found and none in this package. Use the full Windows package.'; exit 1 }
$agent = Join-Path $dest 'agent.js'
& $node $agent enrol $Token; if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $node $agent install;      if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $node $agent run
Write-Host 'Done. The agent scans once a day.'
