#!/bin/sh
# Antara North Star agent installer for Mac and Linux.
# Usage:  sudo ./install.sh <enrolment-token>        (whole computer, all users, runs daily)
#         ./install.sh <enrolment-token>             (this user only)
set -e
TOKEN="$1"
[ -z "$TOKEN" ] && { echo "Usage: ./install.sh <enrolment-token>"; exit 2; }
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ "$(id -u)" = "0" ]; then DEST="/opt/antara-north-star"; else DEST="$HOME/.antara-north-star"; fi
mkdir -p "$DEST"
cp "$HERE"/app/*.js "$DEST/"
# Node: use the one shipped in this package, else the one on this computer.
NODE=""
case "$(uname -s)-$(uname -m)" in
  Linux-x86_64) RT=linux-x64;; Darwin-arm64) RT=mac-arm64;; Darwin-x86_64) RT=mac-x64;; *) RT=none;;
esac
if [ -x "$HERE/runtime/$RT/node" ]; then mkdir -p "$DEST/runtime"; cp "$HERE/runtime/$RT/node" "$DEST/runtime/node"; chmod +x "$DEST/runtime/node"; NODE="$DEST/runtime/node"
elif command -v node >/dev/null 2>&1; then NODE="$(command -v node)"
else echo "No Node.js found and none in this package. Use the full package, or install Node 18 or newer."; exit 1; fi
"$NODE" "$DEST/agent.js" enrol "$TOKEN"
"$NODE" "$DEST/agent.js" install
echo "First scan now..."
"$NODE" "$DEST/agent.js" run
echo "Done. The agent scans once a day. To remove it: $NODE $DEST/agent.js uninstall"
